# LIMITATIONS_AND_CLAIMS.md

## Allowed claims

- R0-bis v1.0.2 executed successfully with dcor enabled.
- Pair-level train/test splitting was used.
- Baseline module redundancy was detected.
- Nonlinear dependence was detected.
- `lexical_drift` was selected as the minimal conservative tribunal under clean-self controls.
- Full baseline pipeline did not materially outperform the selected minimal tribunal under the tested clean-self samples.

## Disallowed claims

- Do not claim final SAS validation.
- Do not claim production-grade hallucination detection.
- Do not claim that `lexical_drift` is universally sufficient.
- Do not claim robustness under external clean controls until R0.5 is executed.
- Do not count redundant baseline modules as independent R1 votes.

## Core limitation

The negative class is clean-self:

```text
source = A_clean
response = A_clean
```

This can inflate drift-based performance. External clean controls are required next.
