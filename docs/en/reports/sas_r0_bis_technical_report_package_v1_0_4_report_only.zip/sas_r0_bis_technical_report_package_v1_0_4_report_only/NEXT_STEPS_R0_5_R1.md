# NEXT_STEPS_R0_5_R1.md

## Immediate freeze

1. Preserve this package and its SHA-256.
2. Send the package to Claude / Gemini / DeepSeek for report-level audit.
3. Do not overwrite R0-bis outputs.

## R0.5 external-clean

Create clean equivalent responses:

```text
source = A_clean
response = C_clean_equivalent
label = 0
```

Requirements:

- semantically equivalent;
- lexically distinct;
- no hallucinated response leakage;
- pair-level split preserved;
- report F1 drop against self-clean.

Acceptance bands:

```text
F1 >= 0.95  -> strong
0.90-0.95   -> calibration required
0.85-0.90   -> identity-dependence warning
< 0.85      -> redesign before R1
```

## R1

Integrate real SAS modules and cluster dependent modules before voting:

- sas_tda_score
- sas_nig_score
- source_target_guard_score
- e9_contradiction_score
- e10_grounding_score
- e11_temporal_score
- e12_topic_shift_score
- flow_coherence / structural_flow
- kappa_equivalence_scan
- module_observability
- evidence_bundle
- certify_endpoint
- multimetric_auditor
- temporal_consistency_score
- interaction_isi_bridge
- category_conditioned_tribunal

R1 validation should use nested cross-validation or a locked validation protocol.
