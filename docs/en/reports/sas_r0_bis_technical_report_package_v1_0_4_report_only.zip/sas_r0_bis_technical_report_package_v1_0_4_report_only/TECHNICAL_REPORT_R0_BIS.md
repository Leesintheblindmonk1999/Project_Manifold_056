# R0-bis Nonlinear Dependence and Redundancy Audit for SAS/κD-0.56

**Package version:** `v1.0.4-report-only`  
**Execution script:** `r0_bis_correlation_audit.py v1.0.2`  
**Execution date in outputs:** `2026-06-11`  
**Report generated:** `2026-06-11T22:18:49.487136+00:00`  
**Project:** SAS / Project Manifold 0.56  
**Architect:** Gonzalo Emir Durante  
**Reference R0:** `https://zenodo.org/records/20647532`  
**R0 public artifact SHA-256:** `b1c4b2eddc7b887f8721f3f193b5d1263e4822f13efd08f8b20ae95389dd36fe`  

## 1. Executive finding

R0-bis `v1.0.2` executed successfully over three stratified clean-self samples:

| Sample | Records | Train | Test | Selected minimal module | Selected test F1 | Full test F1 |
|---:|---:|---:|---:|---|---:|---:|
| 2,400 | 2,400 | 1,800 | 600 | `lexical_drift` | 1.000000 | 1.000000 |
| 6,000 | 6,000 | 4,500 | 1,500 | `lexical_drift` | 0.999333 | 0.999333 |
| 12,000 | 12,000 | 9,000 | 3,000 | `lexical_drift` | 1.000000 | 0.999667 |

The main R0-bis result is not that `lexical_drift` is universally sufficient. The correct interpretation is narrower and stronger:

> Under `clean_strategy=self`, baseline drift modules exhibit substantial redundancy. A conservative dependence-aware selector consistently chose `lexical_drift` as the minimal tribunal across 2.4k, 6k, and 12k samples, while full-pipeline performance provided no material held-out advantage.

## 2. Execution integrity

The execution was completed with:

```text
--sample-size all
--seed 42
--require-dcor
```

No `error_report.json` was present after execution.

The frozen outputs ZIP was:

```text
sas_r0_bis_v1_0_2_outputs_20260611_191232.zip
```

SHA-256:

```text
F1F27BAAB03DD848214070BCC5DEB0CE2F8881F1879EC7ACE3D8743482F5C3B2
```

Distance Correlation was active. For the 12k run, Distance Correlation was stratified-subsampled from 9,000 train records to 5,000 for O(N²) memory safety, while Pearson/Spearman/NMI used the full train split.

## 3. Dependence classification results

| Sample | independent | partial_dependence | redundant_linear | nonlinear_dependence | borderline_dependence |
|---:|---:|---:|---:|---:|---:|
| 2,400 | 6 | 5 | 3 | 1 | 0 |
| 6,000 | 6 | 4 | 3 | 2 | 0 |
| 12,000 | 5 | 4 | 3 | 2 | 1 |

The stable finding is that 3 module pairs are linearly redundant across all tested sample sizes. Additionally, nonlinear dependence appears in 1–2 pairs depending on scale, supporting the R0-bis premise that Pearson alone is insufficient for R1 vote independence.

## 4. Minimal tribunal selection

The selected minimal tribunal was stable:

```text
sample_strat_2400  -> lexical_drift
sample_strat_6000  -> lexical_drift
sample_strat_12000 -> lexical_drift
```

Blocked modules:

| Sample | Blocked modules |
|---:|---|
| 2,400 | density_delta, entity_drift, length_delta, numeric_invariant_loss |
| 6,000 | density_delta, entity_drift, length_delta, numeric_invariant_loss |
| 12,000 | density_delta, entity_drift, length_delta, negation_shift, numeric_invariant_loss |

This indicates that the v1.0.2 conservative blocking logic is active: partially dependent, nonlinear dependent, redundant, and borderline pairs are not counted as independent votes.

## 5. Held-out test validation

| Sample | Selected F1 | Full F1 | Selected FP/FN | Full FP/FN |
|---:|---:|---:|---|---|
| 2,400 | 1.000000 | 1.000000 | FP=0, FN=0 | FP=0, FN=0 |
| 6,000 | 0.999333 | 0.999333 | FP=0, FN=1 | FP=0, FN=1 |
| 12,000 | 1.000000 | 0.999667 | FP=0, FN=0 | FP=0, FN=1 |

In the 12k run, the selected minimal tribunal slightly outperformed the full baseline pipeline on the held-out split (1.000000 vs 0.999667; a difference of one false negative over 3,000 held-out records). This should not be overclaimed. The correct interpretation is that, under self-clean controls, the full baseline module set can add redundancy or marginal noise without improving held-out F1.

## 6. Strongest redundant/dependent pairs at 12k

From `pairwise_dependence.csv` at 12k:

| Pair | Pearson abs | Distance Corr | NMI | Classification |
|---|---:|---:|---:|---|
| entity_drift ↔ lexical_drift | 0.967005 | 0.974625 | 0.302834 | redundant_linear |
| length_delta ↔ lexical_drift | 0.923308 | 0.934779 | 0.337823 | redundant_linear |
| entity_drift ↔ length_delta | 0.874608 | 0.902337 | 0.225139 | redundant_linear |
| density_delta ↔ entity_drift | 0.593918 | 0.749954 | 0.206752 | nonlinear_dependence |
| density_delta ↔ length_delta | 0.575665 | 0.707559 | 0.193308 | nonlinear_dependence |
| lexical_drift ↔ negation_shift | 0.566097 | 0.582583 | 0.119073 | borderline_dependence |

This directly supports the R1 rule: baseline drift modules must not be treated as independent votes merely because they are separate functions.

## 7. Methodological boundaries

This R0-bis report is valid as a **nonlinear dependence and redundancy audit under clean-self controls**.

It is not:

- final SAS production validation;
- proof that `lexical_drift` is sufficient outside self-clean controls;
- evidence that external paraphrase controls will preserve the same F1;
- R1 tribunal validation with real SAS modules.

The key limitation remains:

```text
clean_strategy = self
source = A_clean
response = A_clean
```

This can inflate drift-based separation. The next scientific stress test is R0.5:

```text
source = A_clean
response = C_clean_equivalent
label = 0
```

## 8. R0-bis conclusion

R0-bis confirms that:

1. The v1.0.2 pipeline runs reproducibly with dcor enabled.
2. Pair-level split and conservative dependence blocking are active.
3. Baseline modules contain stable linear redundancy.
4. Nonlinear dependence exists and must be accounted for.
5. The minimal tribunal selected under clean-self is consistently `lexical_drift`.
6. The full baseline pipeline does not materially outperform the minimal tribunal.
7. R1 must use dependence-aware module clustering and must not count `entity_drift` and `length_delta` as independent votes alongside `lexical_drift`, as they form a linear-redundant cluster with it.

## 9. Next phase

Recommended next sequence:

```text
R0-bis report freeze -> R0.5 external-clean design -> real SAS module registry -> R1 nested/locked validation
```

For R0.5, the acceptance bands remain:

```text
F1 >= 0.95  -> strong robustness candidate
0.90-0.95   -> usable but requires calibration
0.85-0.90   -> identity-dependence warning
< 0.85      -> redesign before R1
```
