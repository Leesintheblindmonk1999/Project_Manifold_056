# FINDING_R0_BIS_RESULT

## Finding

R0-bis `v1.0.2` successfully executed over stratified clean-self samples of 2,400, 6,000, and 12,000 records using `--require-dcor`.

## Evidence

- No `error_report.json` was produced.
- The execution completed all three sample sizes.
- The output package was frozen as `sas_r0_bis_v1_0_2_outputs_20260611_191232.zip`.
- Output ZIP SHA-256:

```text
F1F27BAAB03DD848214070BCC5DEB0CE2F8881F1879EC7ACE3D8743482F5C3B2
```

## Key result

Across all tested sample sizes, the minimal tribunal selected was:

```text
lexical_drift
```

Held-out test F1:

```text
2.4k:  selected 1.000000; full 1.000000
6k:    selected 0.999333; full 0.999333
12k:   selected 1.000000; full 0.999667
```

## Dependence finding

The audit found stable redundancy and nonlinear dependence among baseline modules.

At 12k:

```text
independent: 5
partial_dependence: 4
redundant_linear: 3
nonlinear_dependence: 2
borderline_dependence: 1
```

## Methodological interpretation

This is evidence for nonlinear-dependence-aware redundancy control under `clean_strategy=self`.

It is not final R1 validation.

## Next action

Proceed to R0.5 external-clean robustness audit and then integrate real SAS modules into an R1 tribunal that treats redundant modules as evidence clusters, not independent votes.


## v1.0.4 report-only correction

This report-only patch clarifies that `entity_drift` and `length_delta` should not be counted as independent votes alongside `lexical_drift`, because they form a linear-redundant cluster with it. The correction does not modify code, outputs, JSON files, CSV files, or the frozen R0-bis execution ZIP.
