# CHANGELOG v1.0.4 report-only

Generated: 2026-06-12T04:56:37.842523+00:00

Scope: report-only correction. No code, JSON, CSV, execution outputs, or frozen R0-bis output ZIP were modified.

## Corrections

1. Corrected the conclusion point 7 in `TECHNICAL_REPORT_R0_BIS.md`.

Corrected interpretation:

```text
entity_drift and length_delta must not be counted as independent votes alongside lexical_drift,
because they form a linear-redundant cluster with it.
```

2. Added precision to the 12k held-out result:

```text
selected minimal tribunal: F1 1.000000
full baseline pipeline:    F1 0.999667
difference: one false negative over 3,000 held-out records
```

## Invariant artifact

Frozen R0-bis outputs ZIP SHA-256:

```text
F1F27BAAB03DD848214070BCC5DEB0CE2F8881F1879EC7ACE3D8743482F5C3B2
```
