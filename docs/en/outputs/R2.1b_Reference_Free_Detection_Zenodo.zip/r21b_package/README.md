# R2.1-b — Toward Reference-Free Code Hallucination Detection

**Standard:** SAS (Symbiotic Autoprotection System) / Omni-Scanner Semantic
**Author:** Gonzalo Emir Durante
**TAD Registry:** EX-2026-18792778
**Extends:** R2.1 (DOI 10.5281/zenodo.21365707)

---

## What This Is

R2.1 validated code hallucination detection **when a reference implementation is available**. It explicitly left open the harder problem: detecting a fabricated import, function, or module in freshly generated code with **no reference available**. This deposit documents the first three phases of work on the narrowest tractable slice of that problem: **verifying whether an imported Python module name corresponds to a real package**, using only the module name itself.

Full methodology, all three phases, and the full discussion (including an unplanned finding about active defensive package-squatting) are in `paper/R2.1b_Reference_Free_Detection.pdf`. **Read Section 6 ("Limitations and Scope") before reusing any result from this deposit.**

---

## Scope Disclaimer

This work validates **import-name existence only**. It does **not** validate:
- whether a specific function/class/method referenced from a real module actually exists;
- any language other than Python;
- version-specific package availability;
- call-level or argument-level hallucination.

It is a validated component for one narrow sub-problem, not a general hallucination detector.

---

## Findings Summary — Positive and Negative, Equal Weight

| Phase | Result | Status |
|---|---|---|
| Phase 1 — static KB (stdlib + top-200 PyPI) | 397 entries; found 59/200 packages have a PyPI name that differs from their import name | Foundation, with a documented naming-mismatch limitation |
| Phase 2 — validation vs. Slopsquatting corpus (raw) | Precision 5.25%, Recall 90.73% | **Negative** — static whitelist not usable in production |
| Phase 2 — ground-truth noise correction | 28/302 (9.3%) of ground truth found to be benchmark noise (same package-name/import-name conflation, on the *external* dataset's side); corrected Recall = 100% | Documented data-quality finding |
| Phase 3 — live PyPI check | Precision 100.00% (0 FP), Recall 61.68% | **Mixed** — precision solved; recall figure investigated further |
| Phase 3 — recall investigation | 21/24 remaining false-negative names are real PyPI packages first published 2026-02-19 to 2026-02-21, described as "Benign slopsquatting research package" | **Unplanned finding** — evidence of active defensive squatting; the 61.68% recall figure is a lower bound, not the method's true ceiling (see paper Section 4.4) |

---

## Repository Contents

```
paper/
  R2.1b_paper.md                          Source (Markdown)
  R2.1b_Reference_Free_Detection.pdf      Full report — read this first

code/
  build_api_kb.py                         Phase 1: builds the static knowledge base
  validate_import.py                      Phase 1: three-tier validator (VERIFIED/KNOWN/UNKNOWN)
  eval_slopsquatting.py                   Phase 2: raw evaluation against Slopsquatting
  clean_slopsquatting_ground_truth.py     Phase 2: ground-truth noise correction
  pypi_live_check.py                      Phase 3: live PyPI registry checker
  eval_live_pypi.py                       Phase 3: full evaluation against corrected corpus

data/
  api_kb.json                             Phase 1 output (217 stdlib + 180 PyPI top-200 entries)
  top_pypi_packages_snapshot_20260701.json  Raw snapshot used to build the KB (source: hugovk/top-pypi-packages; included because the live source changes continuously)
  slopsquatting_original.jsonl            Original Trend Micro corpus, unmodified (MIT license, github.com/trendmicro/slopsquatting)
  slopsquatting_corrected.jsonl           Same corpus with corrected ground truth (noise-flagged entries documented per row)
  pypi_cache.json                         Cache of live PyPI responses obtained during this evaluation (for exact reproducibility without re-querying)
  SHA256SUMS.txt                          Integrity hashes for all files in this directory
```

---

## Reproducing the Results

```bash
pip install requests  # or rely on stdlib urllib, already used by the scripts

cd code

# Phase 1 (optional — api_kb.json is already included)
python build_api_kb.py --top-pypi-json ../data/top_pypi_packages_snapshot_20260701.json --out ../data/api_kb.json --top-n 200

# Phase 2
cp ../data/api_kb.json ../data/slopsquatting_corrected.jsonl .
python eval_slopsquatting.py
python clean_slopsquatting_ground_truth.py

# Phase 3 (network access required unless reusing the included cache)
cp ../data/pypi_cache.json .
python eval_live_pypi.py
```

**Note on Phase 3 reproducibility:** re-running against live network access will re-verify against PyPI's *current* state. Because Section 4.3/4.4 of the paper documents that the registry itself has changed since this evaluation was run (defensive package registrations), a fresh run may show a different — likely higher — recall figure than reported here, without indicating anything wrong with either run. This is expected, not a reproducibility failure.

---

## Integrity

See `data/SHA256SUMS.txt` for individual file hashes. SHA-256 of the complete ZIP deposit is provided as a separate `.sha256` file alongside the ZIP itself (not bundled inside it).

---

## Citation

```text
Durante, G. E. (2026). SAS / κD=0.56 — R2.1-b: Toward Reference-Free Code
Hallucination Detection. [Zenodo DOI to be assigned at upload].
```

Extends R2.1 (DOI 10.5281/zenodo.21365707) and the SAS standard (DOI 10.5281/zenodo.19702379).
