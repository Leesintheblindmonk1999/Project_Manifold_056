import json
import sys
sys.path.insert(0, ".")
from validate_import import validate_import

with open("api_kb.json") as f:
    kb = json.load(f)

with open("slopsquatting.jsonl") as f:
    rows = [json.loads(l) for l in f if l.strip()]

pairs = []  # (module_name, ground_truth_hallucinated)
for row in rows:
    notfound = set(row["modulenotfound"])
    for m in row["modules"]:
        pairs.append((m, 1 if m in notfound else 0))

print(f"Total ocurrencias evaluadas: {len(pairs)}")
print(f"Alucinadas (ground truth): {sum(p[1] for p in pairs)}")
print()

tp = fp = tn = fn = 0
verdict_counts = {"VERIFIED": 0, "KNOWN": 0, "UNKNOWN": 0}
examples_fp = []  # sistema dice UNKNOWN (predicho alucinado) pero es real
examples_fn = []  # sistema dice VERIFIED/KNOWN pero es alucinado de verdad

for module, label in pairs:
    result = validate_import(module, kb)
    verdict = result["verdict"]
    verdict_counts[verdict] += 1
    predicted_hallucinated = 1 if verdict == "UNKNOWN" else 0

    if predicted_hallucinated == 1 and label == 1:
        tp += 1
    elif predicted_hallucinated == 1 and label == 0:
        fp += 1
        if len(examples_fp) < 15:
            examples_fp.append(module)
    elif predicted_hallucinated == 0 and label == 0:
        tn += 1
    else:
        fn += 1
        if len(examples_fn) < 15:
            examples_fn.append(module)

precision = tp / (tp + fp) if (tp + fp) else 0
recall = tp / (tp + fn) if (tp + fn) else 0
f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0

print("=== Distribución de veredictos ===")
print(verdict_counts)
print()
print("=== Matriz de confusión (UNKNOWN = predicción de alucinación) ===")
print(f"TP={tp}  FP={fp}")
print(f"FN={fn}  TN={tn}")
print()
print(f"Precision: {precision:.4f}")
print(f"Recall:    {recall:.4f}")
print(f"F1:        {f1:.4f}")
print()
print("=== Ejemplos de FALSO POSITIVO (real, pero UNKNOWN para nosotros) ===")
print(examples_fp)
print()
print("=== Ejemplos de FALSO NEGATIVO (alucinado, pero VERIFIED/KNOWN para nosotros) ===")
print(examples_fn)
