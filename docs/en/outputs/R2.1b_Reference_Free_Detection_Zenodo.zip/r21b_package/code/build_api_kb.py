"""
build_api_kb.py — Fase 1 de R2.1-b

Construye una base de conocimiento mínima de módulos Python "válidos",
para poder distinguir más adelante (Fase 2/3) entre un import real y uno
inventado por un LLM.

Fuentes:
  1. sys.stdlib_module_names — módulos estándar de Python. Gratis, viene
     con el intérprete, cero mantenimiento, 100% confiable.
  2. Top 200 paquetes de PyPI por descargas (30 días), tomado del dataset
     público y real de hugovk/top-pypi-packages (actualizado periódicamente
     por ese proyecto vía ClickHouse/BigQuery sobre los logs oficiales de
     descarga de PyPI). NO es una lista armada a mano.

HALLAZGO IMPORTANTE (léelo antes de usar el JSON de salida):
El nombre de un paquete en PyPI no siempre coincide con el nombre del
módulo que se importa. De los 200 paquetes más descargados, 59 tienen
guion en el nombre de PyPI, y de esos, la mayoría sigue el patrón simple
guion→guion_bajo (ej. "typing-extensions" -> "typing_extensions"), pero un
subconjunto real y no despreciable usa un nombre de import completamente
distinto o un namespace con puntos (ej. "scikit-learn" -> "sklearn",
"pillow" -> "PIL", "protobuf" -> "google.protobuf"). Si no se corrige esto,
el validador de Fase 1 marcaría "UNKNOWN" en casos extremadamente comunes,
lo cual arruinaría la utilidad de la base de conocimiento desde el día uno.

Este script resuelve eso con una tabla de excepciones explícita
(`IRREGULAR_IMPORT_NAMES` más abajo). Esa tabla es best-effort, basada en
conocimiento del ecosistema Python, NO fue verificada instalando cada uno
de los 200 paquetes uno por uno. Antes de confiar en ella para producción,
recomiendo un spot-check manual, en particular en los paquetes menos
conocidos (jaraco-*, opentelemetry-*, azure-*).

Uso:
    python build_api_kb.py --top-pypi-json top_pypi.json --out api_kb.json --top-n 200

Si no tenés el JSON de top-pypi-packages localmente, el script intenta
descargarlo de la fuente pública (requiere red):
    https://raw.githubusercontent.com/hugovk/top-pypi-packages/main/top-pypi-packages-30-days.min.json
"""

import argparse
import json
import sys
import urllib.request
from pathlib import Path
from typing import Dict, Optional

TOP_PYPI_URL = "https://raw.githubusercontent.com/hugovk/top-pypi-packages/main/top-pypi-packages-30-days.min.json"

# ─────────────────────────────────────────────────────────────────────────
# Excepciones conocidas: nombre de paquete en PyPI -> nombre real de import.
# Best-effort, no exhaustiva. Cubre los casos irregulares encontrados en el
# top-200 al momento de escribir este script (2026-07). Si el top-200
# cambia con el tiempo, esta tabla puede necesitar entradas nuevas -- por
# eso NO se pretende que sea un sistema de actualización automática
# (explícitamente fuera de alcance de la Fase 1, por pedido).
# ─────────────────────────────────────────────────────────────────────────
IRREGULAR_IMPORT_NAMES: Dict[str, str] = {
    "scikit-learn": "sklearn",
    "beautifulsoup4": "bs4",
    "pyyaml": "yaml",
    "pillow": "PIL",
    "protobuf": "google.protobuf",
    "pyjwt": "jwt",
    "python-dateutil": "dateutil",
    "python-dotenv": "dotenv",
    "gitpython": "git",
    "psycopg2-binary": "psycopg2",
    "pyopenssl": "OpenSSL",
    "python-multipart": "multipart",
    "google-auth": "google.auth",
    "google-api-core": "google.api_core",
    "google-cloud-storage": "google.cloud.storage",
    "google-cloud-core": "google.cloud",
    "google-genai": "google.genai",
    "googleapis-common-protos": "google.api",  # namespace multi-paquete, aproximado
    "azure-identity": "azure.identity",
    "azure-core": "azure.core",
    "jaraco-classes": "jaraco.classes",
    "jaraco-functools": "jaraco.functools",
    "jaraco-context": "jaraco.context",
    "opentelemetry-sdk": "opentelemetry.sdk",
    "opentelemetry-api": "opentelemetry",
    "opentelemetry-semantic-conventions": "opentelemetry.semconv",
    "opentelemetry-instrumentation": "opentelemetry.instrumentation",
    "opentelemetry-proto": "opentelemetry.proto",
    "opentelemetry-exporter-otlp-proto-http": "opentelemetry.exporter.otlp.proto.http",
    "opentelemetry-exporter-otlp-proto-grpc": "opentelemetry.exporter.otlp.proto.grpc",
    "opentelemetry-exporter-otlp-proto-common": "opentelemetry.exporter.otlp.proto.common",
    "grpcio-status": "grpc_status",
    "grpcio-tools": "grpc_tools",
    "websocket-client": "websocket",
    "requests-oauthlib": "requests_oauthlib",
    "requests-toolbelt": "requests_toolbelt",
    "pyasn1-modules": "pyasn1_modules",
    "pydantic-ai-slim": "pydantic_ai",
    "pydantic-core": "pydantic_core",
    "pydantic-settings": "pydantic_settings",
    "markdown-it-py": "markdown_it",
    "rpds-py": "rpds",
    "more-itertools": "more_itertools",
    "email-validator": "email_validator",
    "docstring-parser": "docstring_parser",
    "importlib-metadata": "importlib_metadata",
    "jsonschema-specifications": "jsonschema_specifications",
    "typing-inspection": "typing_inspection",
    "typing-extensions": "typing_extensions",
    "annotated-types": "annotated_types",
    "et-xmlfile": "et_xmlfile",
    "hf-xet": "hf_xet",
    # Paquetes que NO exponen módulo Python importable directamente
    # (herramientas de CLI / metadatos de build) -- se documentan igual
    # para que el validador no los reporte como error de mapeo, pero se
    # marcan con import_name=None para indicar "no aplica".
    "awscli": None,
    "trove-classifiers": None,
    "hatchling": None,
    "python-discovery": None,
}


def load_stdlib_modules() -> list:
    """
    sys.stdlib_module_names existe desde Python 3.10. Si corrés esto con
    una versión anterior, hay que actualizar Python o usar una lista
    congelada -- no se intenta adivinar la stdlib de versiones viejas.
    """
    if not hasattr(sys, "stdlib_module_names"):
        raise RuntimeError(
            "sys.stdlib_module_names no existe en esta versión de Python "
            f"({sys.version}). Requiere Python 3.10+."
        )
    # Excluir módulos internos que empiezan con "_" (implementación interna,
    # no pensados para importarse directamente en código de usuario) salvo
    # un puñado de excepciones de uso común.
    keep_underscore = {"_thread", "_socket", "_ssl", "_ast", "_collections_abc"}
    return sorted(
        m for m in sys.stdlib_module_names
        if not m.startswith("_") or m in keep_underscore
    )


def load_top_pypi_data(json_path: Optional[str]) -> dict:
    if json_path and Path(json_path).exists():
        with open(json_path, "r", encoding="utf-8") as f:
            return json.load(f)

    print(f"No se encontró un JSON local, descargando de: {TOP_PYPI_URL}", file=sys.stderr)
    with urllib.request.urlopen(TOP_PYPI_URL, timeout=30) as response:
        return json.loads(response.read().decode("utf-8"))


def normalize_default(pypi_name: str) -> str:
    """Transformación por defecto para paquetes SIN entrada en
    IRREGULAR_IMPORT_NAMES: guion -> guion_bajo, minúsculas. Cubre
    correctamente la mayoría de los 59 paquetes con guion detectados."""
    return pypi_name.lower().replace("-", "_")


def build_kb(top_pypi_json: dict, top_n: int) -> dict:
    kb = {}

    for module in load_stdlib_modules():
        kb[module] = {"source": "stdlib", "version": None}

    rows = sorted(top_pypi_json["rows"], key=lambda r: -r["download_count"])[:top_n]
    unmapped_irregular = []

    for row in rows:
        pypi_name = row["project"]
        if pypi_name in IRREGULAR_IMPORT_NAMES:
            import_name = IRREGULAR_IMPORT_NAMES[pypi_name]
            if import_name is None:
                continue  # paquete sin módulo importable (CLI/build tool)
        else:
            import_name = normalize_default(pypi_name)

        # Para namespaces con punto (ej. "google.cloud.storage"), el
        # validador de Fase 1 va a resolver contra el primer componente
        # ("google") -- ver validate_import.py. Igual guardamos el nombre
        # completo acá como referencia.
        top_level = import_name.split(".")[0]

        if top_level not in kb:
            kb[top_level] = {
                "source": "pypi_top200",
                "version": None,
                "pypi_package": pypi_name,
                "full_import_path": import_name if import_name != top_level else None,
            }

    return kb, unmapped_irregular


def main():
    parser = argparse.ArgumentParser(description="Construye la base de conocimiento mínima de módulos Python (Fase 1, R2.1-b).")
    parser.add_argument("--top-pypi-json", default=None, help="Ruta local al JSON de top-pypi-packages. Si no se pasa, se descarga.")
    parser.add_argument("--out", default="api_kb.json")
    parser.add_argument("--top-n", type=int, default=200)
    args = parser.parse_args()

    top_pypi_data = load_top_pypi_data(args.top_pypi_json)
    kb, _ = build_kb(top_pypi_data, args.top_n)

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(kb, f, indent=2, sort_keys=True, ensure_ascii=False)

    n_stdlib = sum(1 for v in kb.values() if v["source"] == "stdlib")
    n_pypi = sum(1 for v in kb.values() if v["source"] == "pypi_top200")
    print(f"Base de conocimiento generada: {args.out}")
    print(f"  Módulos stdlib: {n_stdlib}")
    print(f"  Módulos pypi_top200 (top {args.top_n} solicitado): {n_pypi}")
    print(f"  Total: {len(kb)}")


if __name__ == "__main__":
    main()
