"""
clean_slopsquatting_ground_truth.py — Fase 2, limpieza de ground truth

Corrige 28 entradas de `modulenotfound` en el dataset de Trend Micro que
son ruido metodológico (no alucinaciones reales), del mismo tipo que ya
documentamos en R2.1 con los asserts rotos de MBPP: el checker original
parece testear "¿pip install <string literal> funciona?", que falla para
nombres de import legítimos cuyo paquete de PyPI se llama distinto
(yaml/PyYAML, opentelemetry/opentelemetry-api) o que son stdlib sin
paquete de PyPI (json), o notación de submódulo moderna (redis.asyncio).

Genera:
  - slopsquatting_corrected.jsonl: mismo dataset, con un campo nuevo
    `modulenotfound_corrected` (ground truth limpio) y `noise_removed`
    (qué se sacó de esa fila y por qué).
  - Métricas finales, recalculadas contra el ground truth corregido.
"""

import json
import sys
sys.path.insert(0, ".")
from validate_import import validate_import

NOISE_ENTRIES = {
    "yaml": "Nombre de import correcto; el paquete de PyPI se llama PyYAML, no 'yaml'.",
    "json": "Módulo de la biblioteca estándar; no es un paquete de PyPI instalable.",
    "opentelemetry": "Paquete base real; el nombre de PyPI es 'opentelemetry-api', no 'opentelemetry'.",
    "redis.asyncio": "Submódulo válido del paquete 'redis' moderno (soporte async nativo).",
}

with open("api_kb.json") as f:
    kb = json.load(f)

with open("slopsquatting.jsonl") as f:
    rows = [json.loads(l) for l in f if l.strip()]

corrected_rows = []
total_removed = 0

for row in rows:
    original_notfound = row["modulenotfound"]
    corrected_notfound = [m for m in original_notfound if m not in NOISE_ENTRIES]
    removed = [m for m in original_notfound if m in NOISE_ENTRIES]
    total_removed += len(removed)

    new_row = dict(row)
    new_row["modulenotfound_corrected"] = corrected_notfound
    new_row["modulenotfound_corrected_count"] = len(corrected_notfound)
    new_row["noise_removed"] = removed
    corrected_rows.append(new_row)

with open("slopsquatting_corrected.jsonl", "w", encoding="utf-8") as f:
    for row in corrected_rows:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")

print(f"Entradas de ruido removidas del ground truth: {total_removed}")
print(f"Dataset corregido guardado en: slopsquatting_corrected.jsonl")
print()

# ── Métricas finales, contra el ground truth corregido ──────────────────
pairs = []
for row in corrected_rows:
    corrected_notfound = set(row["modulenotfound_corrected"])
    for m in row["modules"]:
        pairs.append((m, 1 if m in corrected_notfound else 0))

tp = fp = tn = fn = 0
for module, label in pairs:
    verdict = validate_import(module, kb)["verdict"]
    predicted_hallucinated = 1 if verdict == "UNKNOWN" else 0
    if predicted_hallucinated == 1 and label == 1:
        tp += 1
    elif predicted_hallucinated == 1 and label == 0:
        fp += 1
    elif predicted_hallucinated == 0 and label == 0:
        tn += 1
    else:
        fn += 1

precision = tp / (tp + fp) if (tp + fp) else 0
recall = tp / (tp + fn) if (tp + fn) else 0
f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0

print("=== Métricas finales, ground truth corregido (Fase 2) ===")
print(f"TP={tp}  FP={fp}")
print(f"FN={fn}  TN={tn}")
print(f"Precision: {precision:.4f}")
print(f"Recall:    {recall:.4f}")
print(f"F1:        {f1:.4f}")
