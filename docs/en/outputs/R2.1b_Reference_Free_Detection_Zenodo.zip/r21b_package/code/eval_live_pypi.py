import json
import sys
sys.path.insert(0, ".")
from pypi_live_check import check_module_live, build_reverse_irregular_map, _load_cache, _save_cache

with open("api_kb.json") as f:
    kb = json.load(f)

with open("slopsquatting_corrected.jsonl") as f:
    rows = [json.loads(l) for l in f if l.strip()]

_load_cache()
reverse_irregular = build_reverse_irregular_map("api_kb.json")

# Cache de veredictos por nombre único, para no repetir llamadas de red
# ademas del cache de PyPI que ya tiene pypi_live_check.py internamente.
verdict_cache = {}

def get_verdict(module_name):
    if module_name not in verdict_cache:
        result = check_module_live(module_name, kb, reverse_irregular)
        verdict_cache[module_name] = result["verdict"]
    return verdict_cache[module_name]

pairs = []
for row in rows:
    corrected_notfound = set(row["modulenotfound_corrected"])
    for m in row["modules"]:
        pairs.append((m, 1 if m in corrected_notfound else 0))

print(f"Total ocurrencias: {len(pairs)}")

tp = fp = tn = fn = 0
network_errors = 0
fp_examples = []
fn_examples = []

for module, label in pairs:
    verdict = get_verdict(module)

    if verdict == "NETWORK_ERROR":
        network_errors += 1
        continue  # no se cuenta como acierto ni error, se excluye explícitamente

    predicted_hallucinated = 1 if verdict == "UNKNOWN" else 0

    if predicted_hallucinated == 1 and label == 1:
        tp += 1
    elif predicted_hallucinated == 1 and label == 0:
        fp += 1
        if len(fp_examples) < 20:
            fp_examples.append(module)
    elif predicted_hallucinated == 0 and label == 0:
        tn += 1
    else:
        fn += 1
        if len(fn_examples) < 20:
            fn_examples.append(module)

_save_cache()

precision = tp / (tp + fp) if (tp + fp) else 0
recall = tp / (tp + fn) if (tp + fn) else 0
f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0

print()
print("=== Fase 3 — resultado con chequeo en vivo contra PyPI ===")
print(f"TP={tp}  FP={fp}")
print(f"FN={fn}  TN={tn}")
print(f"Errores de red (excluidos): {network_errors}")
print()
print(f"Precision: {precision:.4f}")
print(f"Recall:    {recall:.4f}")
print(f"F1:        {f1:.4f}")
print()
print("=== Falsos positivos restantes (hasta 20) ===")
print(fp_examples)
print()
print("=== Falsos negativos restantes (hasta 20) ===")
print(fn_examples)
