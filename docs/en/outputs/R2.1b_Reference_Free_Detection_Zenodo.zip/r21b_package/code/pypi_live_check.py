"""
pypi_live_check.py — Fase 3 de R2.1-b

Reemplaza el whitelist estático de top-200 (Fase 1) por una consulta en
vivo a la API real de PyPI, para resolver el problema de precisión
detectado en Fase 2 (5.25%): la cola larga de paquetes legítimos pero
poco descargados (litestar, strawberry-graphql, piccolo, etc.) quedaba
fuera de cualquier top-N estático, sin importar cuán grande.

DISEÑO CLAVE (aprendido en Fase 2, no es un detalle menor):
Consultar el string literal contra PyPI NO alcanza. Es el mismo error
que cometió el ground truth de Trend Micro: `pip install yaml` falla
(404 en la API) aunque `import yaml` sea código perfectamente válido,
porque el paquete de PyPI se llama `PyYAML`, no `yaml`. Por eso este
checker prueba, en orden, varios nombres candidatos antes de concluir
que algo no existe:

  1. stdlib -- ni siquiera se consulta PyPI (los módulos estándar no son
     paquetes de PyPI; consultarlos daría 404 y sería un falso "no existe").
  2. Mapeo inverso de IRREGULAR_IMPORT_NAMES (de Fase 1) -- si conocemos
     que "yaml" viene de "pyyaml", probamos ese nombre primero.
  3. El string literal, tal cual.
  4. Transformaciones comunes guion_bajo<->guion (la convención de PyPI
     favorece guiones, la de import en Python favorece guion_bajo).

Si CUALQUIERA de esos candidatos devuelve 200 en
`https://pypi.org/pypi/<candidato>/json`, se clasifica como EXISTS.
Si todos fallan (404 en todos), se clasifica como NOT_FOUND.
Errores de red se distinguen explícitamente (NETWORK_ERROR), para no
confundir "no pude verificar" con "no existe".

Cache local en JSON (pypi_cache.json) para no volver a consultar el mismo
nombre dos veces -- con 7,956 ocurrencias y muchos nombres repetidos, esto
reduce drásticamente el número de requests reales.

Rate limiting: pausa mínima entre requests NO cacheados, y un User-Agent
identificable, por buena práctica hacia la infraestructura pública de PyPI
(no hay garantía de que esto sea indefinidamente aceptable a gran escala;
para un uso recurrente o de mayor volumen, contactar a PyPI o usar un
mirror/index local sería lo correcto).

Uso:
    python pypi_live_check.py --kb api_kb.json "yaml"
    python pypi_live_check.py --kb api_kb.json "totally_fake_pkg_9000"
"""

import argparse
import json
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Optional

PYPI_JSON_URL = "https://pypi.org/pypi/{name}/json"
USER_AGENT = "SAS-R2.1b-research (contact: duranteg2@gmail.com)"
REQUEST_TIMEOUT = 6
MIN_DELAY_BETWEEN_REQUESTS = 0.15  # segundos, cortesía hacia la infra de PyPI

_cache_path = Path("pypi_cache.json")
_cache = {}
_last_request_time = [0.0]


def _load_cache():
    global _cache
    if _cache_path.exists():
        with open(_cache_path, "r", encoding="utf-8") as f:
            _cache = json.load(f)


def _save_cache():
    with open(_cache_path, "w", encoding="utf-8") as f:
        json.dump(_cache, f, indent=2, sort_keys=True)


def _check_single_name_live(pypi_name: str) -> str:
    """Devuelve 'EXISTS', 'NOT_FOUND', o 'NETWORK_ERROR' para un nombre puntual."""
    key = pypi_name.lower()
    if key in _cache:
        return _cache[key]

    # Rate limiting simple
    elapsed = time.time() - _last_request_time[0]
    if elapsed < MIN_DELAY_BETWEEN_REQUESTS:
        time.sleep(MIN_DELAY_BETWEEN_REQUESTS - elapsed)

    url = PYPI_JSON_URL.format(name=pypi_name)
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            _last_request_time[0] = time.time()
            result = "EXISTS" if resp.status == 200 else "NOT_FOUND"
    except urllib.error.HTTPError as e:
        _last_request_time[0] = time.time()
        result = "NOT_FOUND" if e.code == 404 else "NETWORK_ERROR"
    except (urllib.error.URLError, TimeoutError):
        _last_request_time[0] = time.time()
        result = "NETWORK_ERROR"

    _cache[key] = result
    return result


def _candidate_names(module_name: str, reverse_irregular: dict) -> list:
    """Genera la lista ordenada de nombres de PyPI a probar para un módulo dado."""
    top_level = module_name.split(".")[0]
    candidates = []

    if top_level in reverse_irregular:
        candidates.append(reverse_irregular[top_level])

    # Probar el string completo tal cual PRIMERO -- cubre paquetes de PyPI
    # que usan un punto literal como parte de su propio nombre (ej. la
    # familia "aws-cdk.core", "aws-cdk.aws-ec2" de AWS CDK v1), que no es
    # lo mismo que la notación de import con puntos de Python.
    if module_name != top_level:
        candidates.append(module_name)

    candidates.append(top_level)

    if "_" in top_level:
        candidates.append(top_level.replace("_", "-"))
    if "-" in top_level:
        candidates.append(top_level.replace("-", "_"))

    # Dedup preservando orden
    seen = set()
    ordered = []
    for c in candidates:
        if c not in seen:
            seen.add(c)
            ordered.append(c)
    return ordered


def check_module_live(module_name: str, kb: dict, reverse_irregular: dict) -> dict:
    """
    Punto de entrada principal. Devuelve un dict con veredicto y detalle,
    combinando: stdlib (sin red) -> candidatos en vivo contra PyPI.
    """
    top_level = module_name.split(".")[0]
    kb_entry = kb.get(top_level)

    if kb_entry is not None and kb_entry.get("source") == "stdlib":
        return {
            "module": module_name,
            "verdict": "VERIFIED",
            "detail": "Módulo de la biblioteca estándar (no se consulta PyPI).",
            "candidates_tried": [],
        }

    candidates = _candidate_names(module_name, reverse_irregular)
    tried = []
    for candidate in candidates:
        result = _check_single_name_live(candidate)
        tried.append((candidate, result))
        if result == "EXISTS":
            return {
                "module": module_name,
                "verdict": "EXISTS_LIVE",
                "detail": f"Encontrado en PyPI como '{candidate}'.",
                "candidates_tried": tried,
            }

    if any(r == "NETWORK_ERROR" for _, r in tried):
        return {
            "module": module_name,
            "verdict": "NETWORK_ERROR",
            "detail": "No se pudo confirmar ni descartar por error de red -- no tratar como alucinación.",
            "candidates_tried": tried,
        }

    return {
        "module": module_name,
        "verdict": "UNKNOWN",
        "detail": f"Ningún candidato encontrado en PyPI: {[c for c, _ in tried]}.",
        "candidates_tried": tried,
    }


def build_reverse_irregular_map(kb_path: str) -> dict:
    """
    Reconstruye el mapeo inverso (import_name -> pypi_name) a partir de
    IRREGULAR_IMPORT_NAMES en build_api_kb.py, importándolo directamente
    para no duplicar la tabla en dos archivos.
    """
    from build_api_kb import IRREGULAR_IMPORT_NAMES
    reverse = {}
    for pypi_name, import_name in IRREGULAR_IMPORT_NAMES.items():
        if import_name is None:
            continue
        top_level = import_name.split(".")[0]
        reverse.setdefault(top_level, pypi_name)
    return reverse


def main():
    parser = argparse.ArgumentParser(description="Chequeo en vivo de existencia en PyPI (Fase 3, R2.1-b).")
    parser.add_argument("module", nargs="?", help="Nombre de módulo a validar")
    parser.add_argument("--kb", default="api_kb.json")
    args = parser.parse_args()

    _load_cache()
    with open(args.kb, "r", encoding="utf-8") as f:
        kb = json.load(f)
    reverse_irregular = build_reverse_irregular_map(args.kb)

    if args.module:
        result = check_module_live(args.module, kb, reverse_irregular)
        print(json.dumps(result, ensure_ascii=False, indent=2))

    _save_cache()


if __name__ == "__main__":
    main()
