"""
validate_import.py — Fase 1 de R2.1-b

Dado un import (como string: "import pandas", "from sklearn import svm",
o simplemente "pandas"), devuelve un veredicto de tres niveles contra la
base de conocimiento generada por build_api_kb.py.

REINTERPRETACIÓN DE LOS 3 NIVELES (importante, léelo):
El pedido original definía "KNOWN" y "VERIFIED" como dos categorías que
en la práctica siempre iban a coincidir (ambas significaban "está en la
base de conocimiento", que solo contiene stdlib + top-200 PyPI). Eso deja
un sistema de 2 niveles reales, no 3. Para que los 3 niveles aporten algo
distinto, se reinterpretaron así:

  VERIFIED -> está en sys.stdlib_module_names. Máxima confianza: viene
              con el intérprete, no depende de un ranking externo.
  KNOWN    -> está en el top-200 de PyPI por descargas. Confianza alta
              pero no absoluta: depende de un ranking de terceros que
              puede quedar desactualizado.
  UNKNOWN  -> no está en ninguna de las dos fuentes. IMPORTANTE: esto NO
              significa "alucinado". Significa "no verificable con esta
              base de conocimiento mínima" -- puede ser un paquete real
              pero menos popular, un módulo interno del propio proyecto,
              o sí, una alucinación. Fase 1 no tiene forma de distinguir
              esos tres casos; eso queda para una fase posterior con una
              base de conocimiento más amplia o una consulta en vivo al
              índice de PyPI.

Si no estás de acuerdo con esta reinterpretación, avisame y lo ajustamos
antes de construir nada sobre esto en Fase 2/3.

Uso:
    python validate_import.py --kb api_kb.json "import pandas"
    python validate_import.py --kb api_kb.json "from sklearn import svm"
    python validate_import.py --kb api_kb.json "totally_fake_package_123"

    # Modo batch, un import por línea desde un archivo:
    python validate_import.py --kb api_kb.json --batch imports.txt
"""

import argparse
import json
import re
import sys
from typing import Optional

IMPORT_RE = re.compile(
    r"^\s*(?:from\s+([\w.]+)\s+import|import\s+([\w.]+))"
)


def extract_module_name(import_statement: str) -> Optional[str]:
    """
    Extrae el nombre de módulo de un statement `import X` / `from X import Y`.
    Si no matchea ninguna de esas dos formas, asume que el string ya es
    directamente un nombre de módulo (ej. "pandas").
    """
    match = IMPORT_RE.match(import_statement)
    if match:
        module = match.group(1) or match.group(2)
        return module
    stripped = import_statement.strip()
    if stripped and re.match(r"^[\w.]+$", stripped):
        return stripped
    return None


def validate_import(module_name: str, kb: dict) -> dict:
    """
    Devuelve {"module": ..., "top_level": ..., "verdict": ..., "detail": ...}
    Resuelve namespaces con punto (ej. "google.cloud.storage") contra el
    primer componente ("google"), porque es el nivel al que build_api_kb.py
    guarda las entradas de paquetes con import de múltiples niveles.
    """
    top_level = module_name.split(".")[0]
    entry = kb.get(top_level)

    if entry is None:
        return {
            "module": module_name,
            "top_level": top_level,
            "verdict": "UNKNOWN",
            "detail": "No encontrado en stdlib ni en el top-200 de PyPI. No implica alucinación -- ver docstring del script.",
        }

    if entry["source"] == "stdlib":
        return {
            "module": module_name,
            "top_level": top_level,
            "verdict": "VERIFIED",
            "detail": "Módulo de la biblioteca estándar de Python.",
        }

    # source == "pypi_top200"
    detail = f"Top-200 PyPI por descargas (paquete: {entry.get('pypi_package', top_level)})."
    return {
        "module": module_name,
        "top_level": top_level,
        "verdict": "KNOWN",
        "detail": detail,
    }


def main():
    parser = argparse.ArgumentParser(description="Valida imports contra la base de conocimiento de Fase 1 (R2.1-b).")
    parser.add_argument("statement", nargs="?", help="Import statement o nombre de módulo, ej. 'import pandas'")
    parser.add_argument("--kb", default="api_kb.json")
    parser.add_argument("--batch", default=None, help="Archivo con un import statement por línea")
    args = parser.parse_args()

    with open(args.kb, "r", encoding="utf-8") as f:
        kb = json.load(f)

    def process(stmt: str):
        module = extract_module_name(stmt)
        if module is None:
            print(json.dumps({"input": stmt, "verdict": "PARSE_ERROR", "detail": "No se pudo extraer un nombre de módulo."}))
            return
        result = validate_import(module, kb)
        result["input"] = stmt
        print(json.dumps(result, ensure_ascii=False))

    if args.batch:
        with open(args.batch, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    process(line)
    elif args.statement:
        process(args.statement)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
