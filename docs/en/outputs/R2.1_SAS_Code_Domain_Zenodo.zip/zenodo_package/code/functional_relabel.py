r"""
functional_relabel.py

Re-etiqueta el corpus CodeHallucinationDetection usando EJECUCION REAL
contra los asserts de meta['test'], en vez de confiar en la columna
'hallucinated' del dataset (que, verificado en 462 filas sin una sola
excepcion, es simplemente "reply != answer" a nivel de texto -- NO mide
si el codigo generado funciona).

Compatibilidad: escrito para correr en Windows sin dependencias POSIX
(no usa el modulo `resource`, no usa fork, no usa señales tipo SIGALRM).
El aislamiento es vía subprocess con timeout, que funciona igual en
Windows/Linux/Mac desde Python 3.3+.

IMPORTANTE SOBRE EL NIVEL DE AISLAMIENTO (leer antes de correr en escala):
Este script ejecuta cada `reply` en un PROCESO SEPARADO con timeout, lo
cual te protege de: loops infinitos, crashes que tiren abajo el proceso
principal, y que un fallo en una fila corte el resto del batch. NO es un
sandbox de seguridad completo: el codigo SI tiene acceso al filesystem y
red de tu máquina Windows durante los segundos que corre. Esto es
aceptable para este corpus especifico (completions de LLM sobre
problemas benignos de MBPP/HumanEval, no input adversarial), pero:
  - No corras esto como Administrador.
  - Si mas adelante procesas código de origen menos confiable, migrá a
    un contenedor Docker con `--network none` y filesystem de solo
    lectura (Docker Desktop con backend WSL2 en Windows) en vez de este
    script directo.

Uso (PowerShell o cmd):
    pip install datasets --user
    python functional_relabel.py --dataset_dir "C:\ruta\a\line_diff_dsc6_gen" --out resultados.csv

Podés pasar --dataset_dir varias veces para procesar varios splits/modelos
en una sola corrida (se concatenan y se marca de qué carpeta vino cada fila).
"""

import argparse
import csv
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from collections import Counter

TIMEOUT_SECONDS = 8  # margen amplio para problemas MBPP/HumanEval, que son cortos

CODE_FENCE_RE = re.compile(r"```(?:python)?\s*\n?(.*?)```", re.DOTALL)


def extract_code(raw_text: str) -> str:
    """
    Extrae el código Python de un bloque markdown ```python ... ```.
    Si no encuentra fences, devuelve el texto tal cual (fallback), porque
    algunas filas pueden no tener el fence de cierre si el modelo cortó
    la generación a mitad de camino -- eso en sí mismo es información
    útil (lo vamos a ver como SyntaxError/timeout más abajo, no lo
    descartamos silenciosamente).
    """
    match = CODE_FENCE_RE.search(raw_text)
    if match:
        return match.group(1).strip()
    return raw_text.strip()


def build_test_script(code: str, asserts: list) -> str:
    """
    Combina el código generado con los asserts reales del dataset en un
    único script ejecutable. Cada assert se envuelve para poder distinguir
    fallo de lógica (AssertionError) de fallo estructural (NameError,
    ImportError, TypeError por firma incorrecta, etc.) -- esa distinción
    es la que de verdad importa para "alucinación" vs "bug menor".
    """
    lines = [
        "import sys",
        "results = []",
        "",
        code,
        "",
    ]
    for i, assertion in enumerate(asserts):
        lines.append(f"try:")
        lines.append(f"    assert {_strip_leading_assert(assertion)}")
        lines.append(f"    results.append(('PASS', {i}))")
        lines.append(f"except AssertionError:")
        lines.append(f"    results.append(('FAIL_ASSERTION', {i}))")
        lines.append(f"except Exception as e:")
        lines.append(f"    results.append(('ERROR:' + type(e).__name__, {i}))")
    lines.append("")
    lines.append("for r in results:")
    lines.append("    print(r[0])")
    return "\n".join(lines)


def _strip_leading_assert(assertion: str) -> str:
    """meta['test'] trae strings como 'assert foo(1)==2' -- sacamos el
    'assert ' inicial porque ya lo agregamos nosotros al envolver en try."""
    s = assertion.strip()
    if s.startswith("assert "):
        return s[len("assert "):]
    return s


def run_in_subprocess(script_text: str) -> str:
    """
    Corre `script_text` en un intérprete Python nuevo, con timeout.
    Devuelve una categoría agregada: PASS_ALL, FAIL_ASSERTION, ERROR,
    TIMEOUT, o SYNTAX_ERROR.
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        script_path = Path(tmpdir) / "candidate.py"
        script_path.write_text(script_text, encoding="utf-8")

        try:
            result = subprocess.run(
                [sys.executable, str(script_path)],
                cwd=tmpdir,             # limita referencias relativas a un dir vacío y temporal
                capture_output=True,
                text=True,
                timeout=TIMEOUT_SECONDS,
            )
        except subprocess.TimeoutExpired:
            return "TIMEOUT"

        if result.returncode != 0:
            # SyntaxError u otro fallo antes de llegar a imprimir resultados
            if "SyntaxError" in result.stderr:
                return "SYNTAX_ERROR"
            return "ERROR:PROCESS_CRASH"

        lines = [l.strip() for l in result.stdout.splitlines() if l.strip()]
        if not lines:
            return "ERROR:NO_OUTPUT"

        if all(l == "PASS" for l in lines):
            return "PASS_ALL"
        if any(l.startswith("ERROR:") for l in lines):
            # devolvemos el primer tipo de error concreto encontrado (NameError, ImportError, etc.)
            for l in lines:
                if l.startswith("ERROR:"):
                    return l
        return "FAIL_ASSERTION"


def process_dataset_dir(dataset_dir: str, writer: csv.DictWriter, counters: Counter):
    from datasets import load_from_disk

    dd = load_from_disk(dataset_dir)
    split_names = list(dd.keys())

    for split in split_names:
        ds = dd[split]
        for row in ds:
            meta = row.get("meta") or {}
            asserts = meta.get("test")
            if not asserts:
                counters["skipped_no_test"] += 1
                continue

            # Chequeo de referencia: ¿el propio ground truth (`answer`) pasa
            # su propio test? Si no, el problema es del benchmark (asserts
            # mal formados, firma inconsistente con el prompt) y no se le
            # puede atribuir nada al modelo ni a κD -- se excluye.
            answer_code = extract_code(row["answer"])
            answer_script = build_test_script(answer_code, asserts)
            answer_outcome = run_in_subprocess(answer_script)
            answer_passes = (answer_outcome == "PASS_ALL")

            if not answer_passes:
                counters["excluded_benchmark_noise"] += 1
                writer.writerow({
                    "source_dir": dataset_dir,
                    "split": split,
                    "idx": row.get("idx"),
                    "model": row.get("model"),
                    "dataset": row.get("dataset"),
                    "task_id": row.get("task_id"),
                    "original_hallucinated_label": row.get("hallucinated"),
                    "functional_outcome": f"EXCLUDED_ANSWER_FAILS:{answer_outcome}",
                    "functional_hallucination": "",
                })
                continue

            code = extract_code(row["reply"])
            script_text = build_test_script(code, asserts)
            outcome = run_in_subprocess(script_text)

            functional_hallucination = 0 if outcome == "PASS_ALL" else 1

            writer.writerow({
                "source_dir": dataset_dir,
                "split": split,
                "idx": row.get("idx"),
                "model": row.get("model"),
                "dataset": row.get("dataset"),
                "task_id": row.get("task_id"),
                "original_hallucinated_label": row.get("hallucinated"),
                "functional_outcome": outcome,
                "functional_hallucination": functional_hallucination,
            })

            counters["total_evaluated"] += 1
            counters[f"outcome:{outcome}"] += 1
            counters[f"orig={row.get('hallucinated')}_func={functional_hallucination}"] += 1


def main():
    parser = argparse.ArgumentParser(description="Re-etiqueta CodeHallucinationDetection por ejecución real.")
    parser.add_argument("--dataset_dir", action="append", required=True,
                         help="Carpeta de un dataset HuggingFace guardado con save_to_disk (ej. line_diff_dsc6_gen). Repetible.")
    parser.add_argument("--out", default="functional_relabel_results.csv")
    args = parser.parse_args()

    fieldnames = ["source_dir", "split", "idx", "model", "dataset", "task_id",
                  "original_hallucinated_label", "functional_outcome", "functional_hallucination"]

    counters = Counter()
    start = time.time()

    with open(args.out, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for dataset_dir in args.dataset_dir:
            print(f"Procesando {dataset_dir} ...")
            process_dataset_dir(dataset_dir, writer, counters)

    elapsed = time.time() - start
    print(f"\nListo en {elapsed:.1f}s. Resultados en: {args.out}\n")
    print("=== Resumen ===")
    for k in sorted(counters):
        print(f"  {k}: {counters[k]}")

    # Tabla de contingencia rápida: etiqueta original (diff) vs funcional (ejecución)
    print("\n=== Contingencia original vs funcional (0=no-halluc, 1=halluc) ===")
    for orig in (0, 1):
        for func in (0, 1):
            key = f"orig={orig}_func={func}"
            print(f"  original={orig}, funcional={func}: {counters.get(key, 0)}")


if __name__ == "__main__":
    main()
