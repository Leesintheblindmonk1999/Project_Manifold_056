"""
validate_r21.py — Reproduces the headline results of the R2.1 report.

This script is self-contained and re-derives everything from the public
source dataset; it does not depend on any pre-computed CSV. Requires the
`datapaf/CodeHallucinationDetection` dataset variants to be downloaded
locally first (see README.md, Section "Reproducing the corpus").

Usage:
    python validate_r21.py --data_root /path/to/CodeHallucinationDetection/datasets/data

Produces (printed to stdout):
    1. Functional relabeling summary (corpus construction, Section 2 of the paper)
    2. AST structural comparison AUC, with and without length-confound control
       (Section 4 of the paper)
    3. TDA internal-coherence AUC (Section 3 of the paper)
"""

import argparse
import sys
import os

import numpy as np
from sklearn.metrics import roc_auc_score
from datasets import load_from_disk

from functional_relabel import extract_code, build_test_script, run_in_subprocess
from core.code_ast_diff import code_diff_isi
from core.code_tda_attestation import CodeTDAAttestator

DIRS = [
    "line_diff_dsc6_gen",
    "line_diff_dsc6_instruct_dataset",
    "line_diff_dsc_instruct_dataset",
    "line_diff_cl7_instruct_dataset",
    "line_diff_dsc33_instruct_dataset",
    "line_diff_l38b_instruct_dataset",
    # line_diff_dsc6_repair intentionally excluded: 0% of rows carry
    # executable unit tests in `meta.test`, so it cannot be used to
    # construct a functional ground truth (see paper, Section 2.1).
]


def build_corpus(data_root: str):
    """Rebuilds the 1,596-row execution-verified corpus from scratch."""
    rows = []
    excluded_noise = 0
    skipped_no_test = 0

    for d in DIRS:
        path = os.path.join(data_root, d)
        dd = load_from_disk(path)
        for split in dd.keys():
            for row in dd[split]:
                meta = row.get("meta") or {}
                asserts = meta.get("test")
                if not asserts:
                    skipped_no_test += 1
                    continue

                answer_code = extract_code(row["answer"])
                answer_outcome = run_in_subprocess(build_test_script(answer_code, asserts))
                if answer_outcome != "PASS_ALL":
                    excluded_noise += 1
                    continue  # reference itself fails -> benchmark noise, not model's fault

                reply_code = extract_code(row["reply"])
                outcome = run_in_subprocess(build_test_script(reply_code, asserts))
                label = 0 if outcome == "PASS_ALL" else 1

                rows.append({"answer": answer_code, "reply": reply_code, "label": label})

    print(f"Corpus construction summary:")
    print(f"  Rows skipped (no executable test in meta.test): {skipped_no_test}")
    print(f"  Rows excluded (reference answer fails its own test -- benchmark noise): {excluded_noise}")
    print(f"  Rows in final corpus: {len(rows)}")
    labels = [r["label"] for r in rows]
    print(f"  Label distribution: {labels.count(0)} not-hallucinated / {labels.count(1)} hallucinated")
    print()
    return rows


def run_ast_diff_experiment(rows):
    print("=" * 70)
    print("Experiment: AST structural comparison (Section 4 of the paper)")
    print("=" * 70)

    labels, scores, len_diffs = [], [], []
    for r in rows:
        score = code_diff_isi(r["answer"], r["reply"])
        labels.append(r["label"])
        scores.append(score)
        len_diffs.append(abs(len(r["reply"]) - len(r["answer"])))

    labels = np.array(labels)
    scores = np.array(scores)
    len_diffs = np.array(len_diffs)

    auc_raw = roc_auc_score(labels, -scores)
    print(f"AUC (raw, full corpus, n={len(labels)}): {auc_raw:.4f}")

    auc_len = roc_auc_score(labels, len_diffs)
    print(f"AUC (length-difference-only baseline, for comparison): {auc_len:.4f}")

    mask = len_diffs <= 15
    auc_controlled = roc_auc_score(labels[mask], -scores[mask])
    auc_len_controlled = roc_auc_score(labels[mask], len_diffs[mask])
    print(f"Length-confound check (|delta_len| <= 15 chars, n={mask.sum()}):")
    print(f"  AUC (AST structural score): {auc_controlled:.4f}")
    print(f"  AUC (length-only, same subset): {auc_len_controlled:.4f}")
    print()


def run_tda_experiment(rows):
    print("=" * 70)
    print("Experiment: TDA internal coherence (Section 3 of the paper)")
    print("=" * 70)

    attestator = CodeTDAAttestator()
    labels, h1_scores, persistence_scores = [], [], []
    for r in rows:
        report = attestator.attest(r["reply"])
        labels.append(r["label"])
        h1_scores.append(report.h1_structural_falsehoods)
        persistence_scores.append(report.max_h1_persistence)

    labels = np.array(labels)
    auc_h1 = roc_auc_score(labels, np.array(h1_scores))
    auc_pers = roc_auc_score(labels, np.array(persistence_scores))
    print(f"AUC (h1_structural_falsehoods, n={len(labels)}): {auc_h1:.4f}")
    print(f"AUC (max_h1_persistence): {auc_pers:.4f}")
    print("Expected: both close to or below 0.5 (documented negative result).")
    print()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--data_root",
        required=True,
        help="Path to the CodeHallucinationDetection 'data' folder containing the line_diff_* subfolders.",
    )
    args = parser.parse_args()

    rows = build_corpus(args.data_root)
    run_ast_diff_experiment(rows)
    run_tda_experiment(rows)


if __name__ == "__main__":
    main()
