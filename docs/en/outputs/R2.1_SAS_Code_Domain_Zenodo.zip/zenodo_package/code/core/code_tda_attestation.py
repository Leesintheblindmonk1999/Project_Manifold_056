"""
core/code_tda_attestation.py

Módulo especializado para el dominio de código (R2.1). NO modifica
core/tda_attestation.py -- reutiliza sus utilidades de bajo nivel
(cómputo de homología persistente vía Ripser/fallback, estructuras de
datos del reporte) porque esas SÍ son genéricas sobre cualquier nube de
puntos. Lo que cambia es todo lo específico de interpretación:

  - Cómo se parte la unidad de análisis (líneas de código, no oraciones).
  - Cómo se embebe (por ahora: mismo LexicalEmbedder de tda_attestation,
    TF-IDF+SVD sobre tokens de código -- funciona sin dependencias nuevas
    y sirve como baseline rápido antes de invertir en CodeBERT/GraphCodeBERT).
  - Qué SIGNIFICA un ciclo H₁ en este dominio: coherencia interna del
    snippet (redundancia/circularidad de líneas), NO validez de API
    contra un universo externo -- ver advertencia en el docstring de
    CodeTDAAttestator.attest() más abajo.

Este módulo responde la pregunta "¿el código tiene estructura interna
anómala?", que es una pregunta MÁS ACOTADA que "¿el código está
alucinado?". Se usa acá como primer experimento barato (Vía 1) para
medir si hay correlación real con la etiqueta funcional antes de
invertir en el enfoque de outlier-contra-corpus-de-referencia (Vía 2,
arquitectónicamente más ajustado a "función/import inventado" pero de
mayor costo de implementación).
"""

import re
import math
from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np

# Reutilizamos utilidades de bajo nivel del módulo de texto -- no las
# duplicamos. Requiere que tda_attestation.py esté en el mismo paquete core/.
from core.tda_attestation import (
    LexicalEmbedder,
    _compute_persistence_ripser,
    _compute_persistence_fallback,
    _RIPSER_OK,
)


@dataclass
class CodeTDAReport:
    line_count: int
    point_cloud_size: int
    h1_total: int = 0
    h1_structural_falsehoods: int = 0
    max_h1_persistence: float = 0.0
    mean_h1_persistence: float = 0.0
    verdict: str = "PENDING"
    fallback_used: bool = False
    kappa_d: float = 0.56


class CodeTDAAttestator:
    """
    Aplica homología persistente sobre las líneas de UN snippet de código,
    tratando cada línea como una "oración" en el sentido de LexicalEmbedder.

    ADVERTENCIA DE ALCANCE (leer antes de interpretar resultados):
    Esto mide coherencia/redundancia estructural INTERNA del snippet, no
    validez de las APIs que usa contra un universo externo de librerías
    reales. Un snippet que llama a una función inventada pero por lo demás
    tiene una estructura de líneas perfectamente normal NO tiene por qué
    mostrar ningún ciclo H₁ anómalo acá -- ese es un límite conocido de
    este enfoque, no un bug. Se usa como primer experimento de bajo costo
    para medir correlación real con la etiqueta funcional antes de decidir
    si vale la pena construir el enfoque de outlier-contra-corpus (Vía 2).
    """

    def __init__(self, persistence_threshold: float = 0.56, embedding_dim: int = 20, min_lines: int = 3):
        self.kappa_d = persistence_threshold
        self.embed_dim = embedding_dim
        self.min_lines = min_lines
        self._embedder = LexicalEmbedder(n_components=embedding_dim)

    def _split_lines(self, code: str) -> List[str]:
        """Líneas no vacías, ignorando comentarios puros y líneas triviales
        (solo llaves/paréntesis), que no aportan señal semántica."""
        lines = []
        for raw in code.splitlines():
            s = raw.strip()
            if not s or s.startswith("#"):
                continue
            if s in ("{", "}", "(", ")", "```", "```python"):
                continue
            lines.append(s)
        return lines

    def attest(self, code: str) -> CodeTDAReport:
        lines = self._split_lines(code)
        report = CodeTDAReport(
            line_count=len(lines),
            point_cloud_size=0,
            kappa_d=self.kappa_d,
        )

        if len(lines) < self.min_lines:
            report.verdict = "INSUFFICIENT_DATA"
            return report

        try:
            point_cloud = self._embedder.fit_transform(lines)
        except Exception as e:
            report.verdict = f"EMBEDDING_ERROR:{e}"
            return report

        report.point_cloud_size = len(point_cloud)

        use_fallback = not _RIPSER_OK
        try:
            if _RIPSER_OK:
                dgms = _compute_persistence_ripser(point_cloud, max_dim=1)
            else:
                dgms = _compute_persistence_fallback(point_cloud, max_dim=1)
                report.fallback_used = True
        except Exception:
            dgms = _compute_persistence_fallback(point_cloud, max_dim=1)
            report.fallback_used = True

        if len(dgms) > 1 and len(dgms[1]) > 0 and not report.fallback_used:
            h1 = dgms[1]
            persistences = []
            structural = 0
            for row in h1:
                birth, death = float(row[0]), float(row[1])
                if math.isinf(death):
                    continue
                persistence = death - birth
                ratio = (death / birth) if birth > 1e-8 else float("inf")
                persistences.append(persistence)
                if math.isinf(ratio) or ratio > self.kappa_d:
                    structural += 1

            report.h1_total = len(h1)
            report.h1_structural_falsehoods = structural
            if persistences:
                report.max_h1_persistence = round(max(persistences), 6)
                report.mean_h1_persistence = round(sum(persistences) / len(persistences), 6)

        if report.h1_total == 0:
            report.verdict = "TOPOLOGICALLY_SIMPLE"
        elif report.h1_structural_falsehoods == 0:
            report.verdict = "STABLE"
        else:
            ratio = report.h1_structural_falsehoods / report.h1_total
            report.verdict = "STRUCTURAL_TENSION" if ratio <= 0.6 else "COLLAPSE"

        return report
