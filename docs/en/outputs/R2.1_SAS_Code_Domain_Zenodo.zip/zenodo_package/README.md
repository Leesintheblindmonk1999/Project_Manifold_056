# R2.1 — Extending SAS (κD = 0.56) to the Code Domain

**Standard:** SAS (Symbiotic Autoprotection System) / Omni-Scanner Semantic
**Author:** Gonzalo Emir Durante
**TAD Registry:** EX-2026-18792778
**Milestone:** R2.1 (code domain, first extension beyond declarative text)

---

## What R2.1 Is

R2.1 is a stress-test of the κD = 0.56 coherence threshold, previously
validated on declarative text (R0.5D, R1-D), extended to source code. The
goal was to determine, with equal scientific weight, both where the
underlying mechanism generalizes and where it does not.

Full methodology, results, and discussion are in
`paper/R2.1_SAS_Code_Domain_Validation.pdf`. This README summarizes the
scope and reproduction steps; **read the paper's Section 5 ("Scope and
Limitations") before citing or reusing any result from this deposit.**

---

## Scope Disclaimer — Read This First

**The validated positive result in this deposit requires a reference
implementation available at detection time.** It answers: *"does this
candidate code diverge structurally from a known-correct reference?"*

It does **not** address the harder, reference-free problem of detecting a
fabricated function or a non-existent import in freshly generated code
with no ground truth available. No method in this deposit solves that
version of the problem. See paper Section 5 for the distinction and for
the proposed direction (knowledge-base-of-valid-APIs) for a future
milestone.

---

## Documented Negative Findings

In the interest of methodological transparency (and consistent with the
stress-test mandate of this milestone), the following negative results
are documented with the same rigor as the positive one:

1. **Internal-coherence TDA (Vía 1)** — adapting the text-domain
   `TDAAttestator` mechanism (persistent homology over sentence
   embeddings) to code, by treating code lines as the atomic unit,
   produced **AUC ≈ 0.40–0.45**, at or below chance level. Confirmed by
   two independent implementations. See paper Section 3.

2. **Information-theoretic composite score** — a method combining
   entropy, a fractal-dimension heuristic, the H₁ term above, and a
   semantic-density term is **excluded from this deposit's validated
   results**. Internal audit found that 40% of its composite weight (the
   topological term and the semantic-density term) was contributing zero
   information across every one of the 1,596 evaluated rows, due to a
   silent exception-handling defect and a hard-coded placeholder value
   respectively (not a genuine empirical result about information-theoretic
   methods). See paper Section 5.1. This method will be revisited in a
   future milestone after correction.

3. **Raw diff-based dataset label** — the `hallucinated` column shipped
   with the source dataset was found to be a pure textual-divergence flag
   (`reply != answer`, verified with zero exceptions across the corpus),
   not a functional-correctness label. This is documented in detail in
   paper Section 2, and is the reason this deposit ships a corrected,
   execution-verified corpus instead of using the shipped label directly.

---

## Repository Contents

```
paper/
  R2.1_paper.md                             Source (Markdown)
  R2.1_SAS_Code_Domain_Validation.pdf       Full report (read this first)

code/
  functional_relabel.py                     Execution-based corpus relabeling
  validate_r21.py                           Reproduces all headline AUC numbers
  core/
    code_ast_diff.py                        Patched: binary vetoes removed (Section 4)
    code_ast_diff_original_reference.py     Original, unmodified version (for diff/audit)
    code_tda_attestation.py                 Code-domain TDA adaptation (Section 3, negative result)
    tda_attestation.py                      Underlying text-domain TDA mechanism (dependency, unmodified)

data/
  corpus_funcional_completo.csv             Corpus metadata + labels (2,050 rows; see column notes below)
  corpus_funcional_completo.sha256          SHA-256 of the CSV above
```

### Corpus CSV column notes

The CSV contains metadata and labels, not the code text itself (the
underlying model completions belong to the `datapaf/CodeHallucinationDetection`
dataset and are not redistributed here — see reproduction instructions
below). Columns:

- `source_dir`, `split`, `idx`, `model`, `dataset`, `task_id`: identifiers
  to join back against the original dataset.
- `original_hallucinated_label`: the diff-based label shipped with the
  source dataset (see negative finding #3 above — do not use this as
  ground truth).
- `functional_outcome`: `PASS_ALL`, `FAIL_ASSERTION`, a specific exception
  type (e.g. `ERROR:NameError`), or `EXCLUDED_ANSWER_FAILS:<outcome>` for
  rows where the reference implementation itself failed its own test
  (benchmark noise, excluded from all reported results).
- `functional_hallucination`: the corrected ground truth used throughout
  this report (0 = passes tests, 1 = fails). Empty for excluded rows.

---

## Reproducing the Corpus and Results

1. Download the source dataset variants (public, not redistributed in
   this deposit): `datapaf/CodeHallucinationDetection` on GitHub/HuggingFace,
   all six `line_diff_*` model-generation folders except `line_diff_dsc6_repair`
   (0% of its rows carry executable tests, see paper Section 2.1).

2. Install dependencies:
   ```
   pip install datasets pandas numpy scikit-learn
   ```

3. Run:
   ```
   cd code
   python validate_r21.py --data_root /path/to/CodeHallucinationDetection/datasets/data
   ```

   This rebuilds the corpus from scratch (execution-based relabeling,
   ~2-3 minutes) and prints all headline numbers reported in the paper:
   the AST structural comparison AUC (raw and length-confound-controlled),
   and the TDA internal-coherence AUC.

**Security note:** `functional_relabel.py` executes model-generated code
in subprocesses with a timeout. This is process-level isolation, not a
full security sandbox — do not run as Administrator/root, and see the
docstring in `functional_relabel.py` for details.

---

## Integrity

SHA-256 of `data/corpus_funcional_completo.csv`:

```
3528edae8a319fac942ef00084eaee5f933eb86e77f477
```

(see `data/corpus_funcional_completo.sha256` for the exact, machine-verifiable value)

SHA-256 of this complete ZIP deposit is provided separately at time of
Zenodo upload / OpenTimestamps anchoring — see the accompanying
`.sha256` file distributed alongside the ZIP, not bundled inside it (a
file cannot contain a hash of itself).

---

## Citation

If citing this milestone, cite the paper (`R2.1_SAS_Code_Domain_Validation.pdf`)
and this Zenodo deposit's DOI (assigned at upload). This work extends
the SAS standard published at DOI 10.5281/zenodo.19702379 and the R0.5D/R1-D
declarative-text validation at DOI 10.5281/zenodo.21231662.
