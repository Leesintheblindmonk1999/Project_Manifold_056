# Limitations and Claims — R0.5D halueval_qa v1.0.0

## Defensible claims

1. **744 accepted declarative C_clean pairs were generated for halueval_qa** under the B ≥ 15 words filter, with 99.75% generation success rate and 0 runtime errors.
2. **The C/B length confound was substantially reduced.** C/B ratio dropped from 2.07 (R1 v1.0.7) to 1.29, and lexical baseline AUC dropped from 0.957 to 0.749.
3. **B_hallucination was quarantined from generation.** All C_clean were generated from A_clean only. Contamination checks ran post-generation only. Documented in `VERIFICATION_MANIFEST.json`.
4. **`long_b_ngram_overlap` generates false positives in QA tracks.** Manual inspection of beta-100 showed 53/54 rejections were legitimate topic overlap, not text copied from B. Threshold adjustment (2 → 4) is documented and reproducible.
5. **The split is source-level and leakage-free.** `sha_bucket(source_id, seed=42)` assigns all pairs from a given source to the same split. R1-D must reuse this function for comparability.

## Claims not supported by this package

1. **SAS structural modules outperform the lexical baseline on this corpus.** That is R1-D, which has not been run yet.
2. **This is a universal hallucination detection benchmark.** It is halueval_qa-specific.
3. **Results generalize to other tracks** (references, rationalization_binary, dialogue, etc.).
4. **κD = 0.56 is validated as a hallucination threshold for this corpus.**
5. **The verifier detects novel factual fabrication absent from both A_clean and B_hallucination.** The verifier has a documented blind spot: numbers or entities invented by the model that do not appear in B cannot be detected deterministically. Manual spot-check is required.
6. **A lexical baseline AUC of 0.749 means R1-D will show strong structural signal.** The baseline is lower than R1 v1.0.7 but remains non-trivial. R1-D results must report the baseline alongside structural scores.

## Residual methodological note

C/B ratio of 1.29 means C_clean is still slightly longer than B_hallucination on average. Complete parity was not achieved, which means some residual length signal remains in the lexical baseline. R1-D ablation should include a run without `length_delta` to quantify how much of the structural signal is length-driven.
