# SAS / κD = 0.56 — R0.5D Declarative External-Clean Corpus
## halueval_qa — Main-1200 Run — Package v1.0.0

**Author:** Gonzalo Emir Durante — Origin Node, Project Manifold 0.56  
**Date:** 6 July 2026  
**Registry:** TAD EX-2026-18792778 (Argentina)  
**License:** GPL-3.0 + Durante Invariance License v1.0  
**Repository:** https://github.com/Leesintheblindmonk1999/Project_Manifold_056  
**SAS Base DOI:** https://doi.org/10.5281/zenodo.19702379  
**R1 v1.0.7 DOI:** https://zenodo.org/records/21034155  

---

## Scope boundary

This package is an **external-clean corpus construction and verifier calibration artifact**.

It does not claim:
- Final SAS hallucination detection validation
- Superiority over lexical baselines (that is R1-D)
- Universal generalization beyond halueval_qa
- κD = 0.56 threshold validation

---

## 1. Executive Summary

R0.5D generated a declarative external-clean corpus for the `halueval_qa` track. The primary methodological objective was to reduce the **length confound** identified in R1 v1.0.7, where the lexical baseline dominated (AUC 0.957) because `C_clean` paraphrases were systematically shorter than `B_hallucination` responses.

| Metric | Value |
|--------|-------|
| Track | halueval_qa (factual QA) |
| Generations attempted | 1,200 |
| Generations OK | 1,197 (99.75%) |
| C_clean accepted | **744 (62%)** |
| C/B length ratio mean | **1.29** (vs 2.07 in R1 v1.0.7) |
| C/B Jaccard mean | 0.36 |
| Lexical baseline AUC (test) | **0.749** (vs 0.957 in R1 v1.0.7) |

The length confound was substantially reduced. The baseline AUC drop from 0.957 to 0.749 creates meaningful evaluation space for SAS structural modules in R1-D.

---

## 2. Research Context

### Why R0.5D exists

R1 v1.0.7 demonstrated reproducible structural signal in SAS-light modules (Flow + CRE + Negation composite: F1 = 0.8717, Precision = 0.9952), but the lexical baseline achieved F1 = 0.9968, AUC = 0.9963. The gap was attributable to a systematic form difference: `C_clean` in R1 v1.0.7 were short instruction/query paraphrases (~15 words) while `B_hallucination` were longer declarative responses (~40–80 words).

R0.5D addresses this by generating `C_clean` as **declarative factual prose** rather than paraphrases of the source instruction, producing comparable form to `B_hallucination`.

### R1 v1.0.7 vs R0.5D comparison

| Phase | Corpus type | Baseline AUC | C/B ratio | Status |
|-------|-------------|--------------|-----------|--------|
| R1 v1.0.7 | Prompt-paraphrase (B short) | 0.957 | 2.07 | Completed |
| R0.5D | Declarative (B ≥ 15 words) | **0.749** | **1.29** | This package |
| R1-D | Declarative structural eval | — | — | Planned |

---

## 3. Corpus Design

### Generation protocol

| Parameter | Value |
|-----------|-------|
| Track | halueval_qa |
| Generator version | r05d_generator.py v0.1.5 |
| Model | anthropic/claude-3-haiku via OpenRouter |
| Temperature | 0.25 primary, 0.35 fallback |
| Max tokens | 450 |
| Seed | 42 |
| Prompt | Explicit anti-paraphrase, declarative-target instructions |

### Corpus filtering

The original halueval_qa corpus (10,000 pairs) was filtered to pairs where `B_hallucination` ≥ 15 words, removing short B entries that reintroduce the length confound.

| Step | Count |
|------|-------|
| Original pairs | 10,000 |
| After B ≥ 15 words filter | **2,510** |
| Selected for generation | 1,200 |
| Accepted C_clean | **744** |

### Quarantine rule

`B_hallucination` was **never** used in generation prompts. It was used exclusively post-generation for contamination checks. This is documented in `VERIFICATION_MANIFEST.json` under `quarantine.b_used_for_generation: false`.

---

## 4. Results

### 4.1 Generation

| Metric | Count |
|--------|-------|
| Total attempts | 1,200 |
| Status OK | 1,197 |
| Status NO_RESPONSE | 3 |
| Errors | 0 |

### 4.2 Verification

| Outcome | Count |
|---------|-------|
| Accepted | **744** (62%) |
| Rejected | 456 (38%) |

Rejection breakdown:

| Reason | Count |
|--------|-------|
| `long_b_ngram_overlap` | 419 |
| `c_too_short` | 24 |
| `c_b_length_ratio_low` | 15 |
| `numbers_added_not_in_a` | 11 |
| `c_b_length_ratio_high` | 3 |
| `dates_added_not_in_a` | 3 |
| `no_response` | 3 |
| `b_only_entity_contamination` | 1 |

**Methodological note on `long_b_ngram_overlap`:** Manual inspection of the beta-100 run revealed that 53 of 54 rejections by this check in halueval_qa were due to legitimate topic overlap (both B and C answer the same question A, sharing 5-grams like "is the capital of france") rather than actual text copied from B. The threshold was adjusted from 2 to 4 shared 5-grams, increasing acceptance from 46% to 62%. The residual 419 rejections under the adjusted threshold represent cases where overlap was sufficiently dense to warrant caution.

### 4.3 Form comparability

| Metric | Value |
|--------|-------|
| C/B length ratio mean | 1.29 |
| C/B length ratio median | 1.24 |
| C/B length ratio min | 0.40 |
| C/B length ratio max | 3.00 |
| C/B token Jaccard mean | 0.36 |
| C/B token Jaccard median | 0.35 |

### 4.4 Lexical baseline

The form analyzer computed a lexical baseline using candidate length and source-candidate Jaccard overlap. Threshold was calibrated on the validation split and evaluated on held-out test.

| Split | AUC | F1 | Precision | Recall |
|-------|-----|-----|-----------|--------|
| Validation | 0.762 | 0.748 | 0.683 | 0.827 |
| Test | **0.749** | **0.711** | 0.652 | 0.781 |

The baseline AUC of 0.749 is substantially lower than R1 v1.0.7 (0.957), confirming that the length confound has been significantly reduced.

**Remaining limitation:** AUC 0.749 means the lexical baseline retains non-trivial separability. Some residual form asymmetry remains (C/B ratio 1.29, not 1.00). R1-D structural evaluation must report this baseline alongside SAS module results for any claim to be interpretable.

---

## 5. File Structure

```
SAS_R05D_halueval_qa_v1_0_0/
├── README.md
├── SHA256SUMS.txt
├── ZENODO_METADATA.json
├── generations/
│   ├── r05d_generations.jsonl       # 1200 generation records (no raw text)
│   └── raw_generations/
│       └── *.txt                    # 1200 generated C_clean texts
├── verification/
│   ├── VERIFICATION_MANIFEST.json   # Summary counts and quarantine proof
│   ├── r05d_verification.jsonl      # Per-pair verification records
│   ├── accepted_C_clean/
│   │   └── *.txt                    # 744 accepted C_clean files
│   └── rejected_C_clean_private/
│       └── *.txt                    # 456 rejected candidates (B-adjacent by construction)
└── form_analysis/
    ├── FORM_ANALYSIS_REPORT.json    # C/B ratios, Jaccard, baseline AUC
    ├── form_metrics_by_pair.csv     # Per-pair form metrics
    └── lexical_baseline_rows.csv    # Per-pair lexical baseline scores
```

**`rejected_C_clean_private/`** is included for reproducibility. Rejected candidates may contain B-adjacent content by construction (they were rejected precisely for excessive overlap with B) and should not be used as clean training data.

---

## 6. Integrity

All files are SHA-256 hashed in `SHA256SUMS.txt`. Verify with:

```bash
# Linux/Mac
sha256sum -c SHA256SUMS.txt

# Windows PowerShell
Get-FileHash -Algorithm SHA256 <filename>
```

---

## 7. Methodological boundaries

### Defensible claims

1. R0.5D successfully generated 744 accepted declarative C_clean pairs for halueval_qa under the `B ≥ 15 words` filtering constraint.
2. The C/B length ratio was reduced from 2.07 (R1 v1.0.7) to 1.29, substantially reducing the length confound.
3. The lexical baseline AUC was reduced from 0.957 (R1 v1.0.7) to 0.749, creating evaluation space for structural modules.
4. The `long_b_ngram_overlap` check generates false positives in QA tracks due to legitimate topic overlap; threshold calibration (2 → 4) is documented and justified by beta-100 manual inspection.
5. B_hallucination was quarantined from generation; all C_clean were generated from A_clean only.

### Claims not supported

1. SAS structural modules outperform the lexical baseline — that is R1-D.
2. This corpus is a universal hallucination detection benchmark.
3. Results generalize beyond halueval_qa.
4. κD = 0.56 is validated as a threshold for this corpus.
5. The verifier can detect novel factual fabrication absent from both A_clean and B_hallucination — manual review is required for that class of error.

---

## 8. Next step

R1-D: run SAS structural modules (Flow, CRE, Negation, NIG, TDA) over the 744 accepted pairs using the R1 scaffold (v1.0.4+). Report structural composite F1 alongside the lexical baseline AUC = 0.749. The split uses `sha_bucket(source_id, seed=42)` from `r05d_common.py` — R1-D must reuse the same split function for comparability.

---

## 9. Citation

```
Durante, G. E. (2026). SAS / κD = 0.56 — R0.5D Declarative External-Clean Corpus,
halueval_qa, Main-1200 Run (Version v1.0.0) [Data set]. Zenodo.
https://doi.org/[PENDING]
```

---

## 10. References

- SAS Standard: https://doi.org/10.5281/zenodo.19702379  
- R0-bis Nonlinear Dependence Paper: https://doi.org/10.5281/zenodo.20671824  
- R1 v1.0.7 Structural Evaluation: https://zenodo.org/records/21034155  
- Project Manifold 0.56: https://github.com/Leesintheblindmonk1999/Project_Manifold_056  
