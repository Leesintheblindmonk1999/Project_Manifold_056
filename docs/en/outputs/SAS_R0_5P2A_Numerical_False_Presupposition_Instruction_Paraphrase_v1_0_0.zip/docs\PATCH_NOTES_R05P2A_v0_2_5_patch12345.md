﻿# Patch Notes - R0.5P-2A v0.2.5 patch12345

PATCH-1/2/3:
Prompt hardening for numerical false-presupposition instruction paraphrase:
- preserve numbers, dates, quantities, letters, item types, separators, output constraints
- preserve fallback no-response behavior
- do not answer, solve, correct, fact-check, or replace with no response

PATCH-4:
Verifier adaptation for instruction-paraphrase:
- accept Generate/Produce request-like shapes
- expand stopwords for task-format words
- allow conditional fallback language when source contains no-response fallback

PATCH-5:
Numeric contamination boundary fix:
- prevent B-only numeric invariant "4" from matching legitimate "44"
- reduce false positive numeric contamination

PATCH-6:
Tested and rejected.
Reason:
- caused over-paraphrasing and track-shape failures.
Status:
- reverted; not included in frozen package.
