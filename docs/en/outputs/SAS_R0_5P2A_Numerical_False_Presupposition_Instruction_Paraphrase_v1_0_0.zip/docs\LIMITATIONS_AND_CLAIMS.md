﻿# Limitations and Claims - R0.5P-2A

Allowed claims:
- R0.5P-2A demonstrates scalable external-clean generation for an instruction-shaped numerical false-presupposition track.
- The run validates a track-conditioned generation and filtering pipeline under explicit constraints.
- The accepted set passed invariant and contamination checks under the packaged verifier.
- Rejected cases show the verifier actively filtered poor paraphrases, numeric changes, or B-only contamination.

Not claimed:
- This is not final hallucination-detection validation.
- This is not evidence that SAS detects all hallucinations.
- This is not production validation.
- This is not a benchmark superiority claim over other systems.

Known limitations:
- Results are model-dependent.
- Some candidates fail by being too close to source or too compressed.
- The method depends on track-conditioned prompts and verifier rules.
- The corpus itself may contain malformed B_hallucination artifacts; B is used only for post-generation contamination checks.
