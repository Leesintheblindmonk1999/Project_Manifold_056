﻿# Methodology - R0.5P-2A

Input category:
halogen/numerical_falsepresupposition

Track:
prompt_paraphrase / instruction-paraphrase

Generation boundary:
- Allowed: A_clean only
- Forbidden during generation: B_hallucination, labels, mutation hints
- B_hallucination used only after generation for contamination audit

Model:
anthropic/claude-3-haiku via OpenRouter

Temperature schedule:
- primary: 0.25
- fallback: 0.35

Preflight:
- mojibake exclusion enabled
- skip-short-source-chars: 40
- skip-short-source-words: 5

Acceptance checks:
- length ratio
- lexical distance
- request-like prompt paraphrase shape
- entity recall
- numbers/dates preservation
- B-only contamination audit

Main-scale result:
- selected: 1200
- accepted: 1152
- rejected: 48
- errors: 0
- with-retry acceptance: 96.0%
