﻿# Results Summary - R0.5P-2A

alpha30:
- accepted: 26/30
- rejected: 4/30
- errors: 0

alpha50:
- accepted: 49/50
- rejected: 1/50
- errors: 0

beta100:
- accepted: 94/100
- rejected: 6/100
- errors: 0

beta500:
- accepted: 478/500
- rejected: 22/500
- errors: 0
- with-retry acceptance: 95.6%

main1200:
- accepted: 1152/1200
- rejected: 48/1200
- errors: 0
- with-retry acceptance: 96.0%

Critical inspection:
- numbers_or_dates_changed cases were rejected.
- b_only_contamination case was rejected.
- no accepted critical contamination was identified during manual inspection.
