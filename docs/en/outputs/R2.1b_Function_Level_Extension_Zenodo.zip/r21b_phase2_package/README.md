# R2.1-b, Function-Level Extension — Reference-Free Validation of Python API Calls

**Standard:** SAS (Symbiotic Autoprotection System) / Omni-Scanner Semantic
**Author:** Gonzalo Emir Durante
**TAD Registry:** EX-2026-18792778
**Extends:** R2.1-b, import-level phase (DOI 10.5281/zenodo.21420392)

---

## What This Is

R2.1-b's import-level phase validated whether a Python module name corresponds to a real PyPI package. This extension goes one level deeper: given that a module is real, does a specific function or method call against it actually exist? `requests.get(...)` vs. `requests.fetch(...)` — same module, only one real call.

Full methodology, the ground-truth defect found during validation, and all limitations are in `paper/R2.1b_Function_Level_Extension.pdf`. **Read Section 6 ("Limitations and Scope") before reusing any result from this deposit.**

---

## Scope Disclaimer

This validates **direct calls against five specific, pre-vetted libraries** (numpy, pandas, matplotlib.pyplot, requests, json) where the call receiver is a recognized module alias. It does **not** validate:

- calls on object instances returned by prior calls (e.g. `df.to_csv(...)` where `df` is a DataFrame instance) — requires type inference, explicitly out of scope;
- "missing import" errors (the call is real, but never imported) — a different category, not addressed;
- "contextual misnaming" (the call is real, but semantically wrong for context) — not addressable by any existence-based method in principle;
- any library outside the five listed above.

---

## Findings Summary

| Item | Result |
|---|---|
| Corpus catalog correction | `WM-SEMERU/Hallucinations-in-Code` is the official replication package of arXiv:2601.19106 (FORGE '26), not an uncredited synthetic dataset as previously catalogued in this project's own history |
| Scope-aligned evaluation | 145 of 200 rows address name-existence errors; 55 rows (missing-import, contextual) are explicitly out of scope and excluded from the primary metric |
| Ground-truth defect found | 5 rows (IDs 67, 107, 125, 167, 187) use `pd.groupby(...)` as a module-level call in their own reference code — confirmed non-existent by direct execution (`AttributeError`). Third instance in this research line of third-party benchmark ground truth containing a verifiable defect (after MBPP in R2.1 and Slopsquatting in R2.1-b's import phase) |
| Final result (140 rows, noise excluded) | **Precision 100.00%, Recall 98.04%, F1 0.9901** |
| Comparison | arXiv:2601.19106 (200 rows, all categories): Precision 100%, Recall 87.6%, F1 0.934 — not a strict apples-to-apples comparison (see paper Section 5.2) |
| Disclosed limitation | 2 false negatives, both `df.to_cv(...)`-style calls on instances — require type inference, explicitly out of scope, not hidden |

---

## Repository Contents

```
paper/
  R2.1b_function_level_paper.md            Source (Markdown)
  R2.1b_Function_Level_Extension.pdf        Full report — read this first

code/
  build_function_kb.py                      Sandboxed introspection KB builder (5 libraries)
  validate_function_call.py                 AST-based call extraction and validation
  eval_function_existence.py                Full evaluation pipeline, incl. ground-truth noise exclusion

data/
  function_kb.json                          Generated knowledge base (462 numpy, 102 pandas, 222 matplotlib.pyplot,
                                             27 requests, 8 json public callable names)
  results_manifest.json                     Per-row-ID outcome manifest (TP/FP/FN/TN), no code content included
```

**Not included** (no license declared by the source repository):
- `generated_dataset.csv` — download from `github.com/WM-SEMERU/Hallucinations-in-Code`, path `hallucination_pipeline/data/generated_dataset.csv`, to reproduce.

---

## Reproducing the Results

```bash
pip install numpy pandas matplotlib requests

cd code
python build_function_kb.py --out ../data/function_kb.json

# Download generated_dataset.csv yourself (see above), then:
python eval_function_existence.py --dataset /path/to/generated_dataset.csv --kb ../data/function_kb.json --out ../data/results_manifest.json
```

The `results_manifest.json` already included in this deposit was produced by this exact pipeline and can be cross-checked against a freshly downloaded copy of the dataset by row ID, without this deposit needing to redistribute any of the dataset's content.

---

## Citation

```text
Durante, G. E. (2026). SAS / κD=0.56 — R2.1-b, Function-Level Extension:
Reference-Free Validation of Python API Calls via Sandboxed Introspection.
[Zenodo DOI to be assigned at upload].
```

Extends R2.1-b (DOI 10.5281/zenodo.21420392), R2.1 (DOI 10.5281/zenodo.21365707), and the SAS standard (DOI 10.5281/zenodo.19702379).
