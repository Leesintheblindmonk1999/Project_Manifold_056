"""
build_function_kb.py — R2.1-b, extensión a nivel de función/método (Fase 1)

Construye una base de conocimiento de funciones/clases reales expuestas a
nivel de módulo por un conjunto reducido de librerías YA CONOCIDAS Y
CONFIABLES (numpy, pandas, matplotlib.pyplot, requests, json), replicando
la metodología de arXiv:2601.19106 (Knowledge-Conflicting Hallucinations):
introspección en vivo en vez de parseo estático del código fuente de la
librería, porque la introspección sí captura atributos expuestos
dinámicamente (carga perezosa, extensiones en C) que un AST del código
fuente puede no ver.

DECISIÓN DE SEGURIDAD (Opción A, acordada explícitamente):
Esto SÍ ejecuta código -- pero únicamente `import` de librerías ya
instaladas localmente y elegidas a mano por ser de uso común y confiable.
Esto es categóricamente distinto de instalar/ejecutar un paquete arbitrario
descubierto por nombre (que sigue estando prohibido sin excepción). Cada
introspección corre en un subproceso aislado, con timeout, sin red y sin
acceso a filesystem compartido -- mismo patrón que functional_relabel.py.

Uso:
    python build_function_kb.py --out function_kb.json
"""

import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path

TARGET_LIBRARIES = {
    "numpy": "import numpy as _m",
    "pandas": "import pandas as _m",
    "matplotlib.pyplot": "import matplotlib\nmatplotlib.use('Agg')\nimport matplotlib.pyplot as _m",
    "requests": "import requests as _m",
    "json": "import json as _m",
}

INTROSPECTION_TEMPLATE = r'''
import json as _json_out

{import_stmt}

names = []
for name in dir(_m):
    if name.startswith("_"):
        continue
    try:
        obj = getattr(_m, name)
    except Exception:
        continue
    if callable(obj) or isinstance(obj, type):
        names.append(name)

print(_json_out.dumps(sorted(set(names))))
'''

TIMEOUT_SECONDS = 20


def introspect_library(library_key: str, import_stmt: str) -> dict:
    """
    Corre la introspección de una librería en un subproceso aislado.
    Devuelve {"status": "ok", "names": [...]} o {"status": "error", "reason": ...}.
    Nunca deja que un fallo en una librería tire abajo el resto del build.
    """
    script = INTROSPECTION_TEMPLATE.format(import_stmt=import_stmt)

    with tempfile.TemporaryDirectory() as tmp:
        script_path = Path(tmp) / "introspect.py"
        script_path.write_text(script, encoding="utf-8")

        try:
            result = subprocess.run(
                [sys.executable, str(script_path)],
                cwd=tmp,                      # sin acceso al filesystem del proyecto
                capture_output=True,
                text=True,
                timeout=TIMEOUT_SECONDS,
            )
        except subprocess.TimeoutExpired:
            return {"status": "error", "reason": "timeout"}

        if result.returncode != 0:
            return {"status": "error", "reason": result.stderr[:500]}

        try:
            names = json.loads(result.stdout.strip())
        except json.JSONDecodeError:
            return {"status": "error", "reason": "no se pudo parsear la salida como JSON"}

        return {"status": "ok", "names": names}


def main():
    parser = argparse.ArgumentParser(description="Construye la KB de funciones/clases por introspección aislada (R2.1-b, fase función).")
    parser.add_argument("--out", default="function_kb.json")
    args = parser.parse_args()

    kb = {}
    for library_key, import_stmt in TARGET_LIBRARIES.items():
        print(f"Introspectando {library_key} ...")
        result = introspect_library(library_key, import_stmt)
        if result["status"] == "ok":
            kb[library_key] = {
                "source": "live_introspection_sandboxed",
                "names": result["names"],
                "count": len(result["names"]),
            }
            print(f"  OK: {len(result['names'])} nombres públicos encontrados.")
        else:
            kb[library_key] = {"source": "live_introspection_sandboxed", "names": [], "error": result["reason"]}
            print(f"  ERROR: {result['reason']}")

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(kb, f, indent=2, sort_keys=True)

    print(f"\nKB guardada en: {args.out}")


if __name__ == "__main__":
    main()
