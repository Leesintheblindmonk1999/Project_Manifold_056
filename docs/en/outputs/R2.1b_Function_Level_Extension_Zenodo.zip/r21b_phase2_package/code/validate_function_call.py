"""
validate_function_call.py — R2.1-b, extensión a nivel de función/método (Fase 1)

Dado un snippet de código Python, extrae llamadas del tipo `modulo.atributo(...)`
vía AST (nunca ejecuta el snippet en sí) y valida cada atributo contra la
KB generada por build_function_kb.py.

Resuelve alias de import (`import numpy as np` -> "np" mapea a "numpy")
a partir del propio snippet. Si un alias no se puede resolver a ninguna
de las librerías conocidas, se reporta aparte (UNRESOLVED_ALIAS) -- esto
incluye el caso de "import faltante" (alias usado pero nunca importado),
que es una categoría de error DISTINTA a la de existencia y no se cuenta
como acierto ni error en la métrica principal (ver README/paper).

Limitación explícita: solo resuelve llamadas donde el receptor es
directamente el alias del módulo (ej. `np.mean(x)`). Llamadas sobre
instancias de objetos devueltos (ej. `df.to_csv(...)` donde `df` es una
instancia de DataFrame, o `response.read()` sobre un objeto Response) NO
se resuelven -- requerirían inferencia de tipos, fuera de alcance de esta
fase. Esas llamadas se reportan como NOT_RESOLVABLE, explícitamente, en
vez de contarse como acierto o error.
"""

import ast
import json
from typing import List, Dict

ALIAS_TO_LIBRARY = {
    "np": "numpy",
    "numpy": "numpy",
    "pd": "pandas",
    "pandas": "pandas",
    "plt": "matplotlib.pyplot",
    "requests": "requests",
    "json": "json",
}


def _build_alias_map(tree: ast.AST) -> Dict[str, str]:
    """Extrae alias reales del propio snippet (import X as Y), con fallback
    a ALIAS_TO_LIBRARY para los casos comunes no explícitamente importados
    con alias distinto (para no penalizar dos veces el caso de "missing
    import", que se reporta aparte)."""
    alias_map = dict(ALIAS_TO_LIBRARY)  # default, sobreescrito por imports reales

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                local_name = alias.asname or alias.name
                if alias.name in ("numpy", "pandas", "requests", "json"):
                    alias_map[local_name] = alias.name
                elif alias.name == "matplotlib.pyplot":
                    alias_map[local_name] = "matplotlib.pyplot"
        elif isinstance(node, ast.ImportFrom):
            if node.module == "matplotlib" :
                for alias in node.names:
                    if alias.name == "pyplot":
                        local_name = alias.asname or alias.name
                        alias_map[local_name] = "matplotlib.pyplot"

    return alias_map


def extract_calls(code: str) -> List[dict]:
    """Devuelve una lista de {"receiver": ..., "attr": ..., "line": ...}
    para cada llamada del tipo receiver.attr(...) encontrada en el código."""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return []

    alias_map = _build_alias_map(tree)
    calls = []

    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if isinstance(node.func.value, ast.Name):
                receiver = node.func.value.id
                calls.append({
                    "receiver": receiver,
                    "attr": node.func.attr,
                    "line": node.lineno,
                    "resolved_library": alias_map.get(receiver),
                })

    return calls


def validate_code(code: str, kb: dict) -> List[dict]:
    """
    Valida cada llamada encontrada en `code` contra `kb` (la salida de
    build_function_kb.py). Devuelve un veredicto por llamada:
      VERIFIED        -> el atributo existe en la KB de esa librería
      UNKNOWN          -> la librería es conocida, pero el atributo no existe
                           (esto es el caso de interés: nombre fabricado/typo)
      NOT_RESOLVABLE   -> el receptor no es un alias de librería conocido
                           (variable/instancia -- requiere inferencia de tipos,
                           fuera de alcance; no cuenta en la métrica principal)
    """
    results = []
    for call in extract_calls(code):
        library = call["resolved_library"]
        if library is None:
            results.append({**call, "verdict": "NOT_RESOLVABLE"})
            continue

        kb_entry = kb.get(library)
        if kb_entry is None or not kb_entry.get("names"):
            results.append({**call, "verdict": "NOT_RESOLVABLE"})
            continue

        if call["attr"] in kb_entry["names"]:
            results.append({**call, "verdict": "VERIFIED", "library": library})
        else:
            results.append({**call, "verdict": "UNKNOWN", "library": library})

    return results


def code_has_hallucinated_call(code: str, kb: dict) -> bool:
    """Atajo: True si ALGUNA llamada resoluble en el código es UNKNOWN."""
    results = validate_code(code, kb)
    return any(r["verdict"] == "UNKNOWN" for r in results)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--kb", default="function_kb.json")
    parser.add_argument("file", help="Archivo .py a validar")
    args = parser.parse_args()

    with open(args.kb, "r", encoding="utf-8") as f:
        kb = json.load(f)
    with open(args.file, "r", encoding="utf-8") as f:
        code = f.read()

    for r in validate_code(code, kb):
        print(json.dumps(r, ensure_ascii=False))
