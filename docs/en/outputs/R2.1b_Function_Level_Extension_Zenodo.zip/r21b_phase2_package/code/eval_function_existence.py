"""
eval_function_existence.py — R2.1-b, extensión a nivel de función/método

Evalúa el validador de existencia de funciones/métodos (build_function_kb.py
+ validate_function_call.py) contra el dataset público de WM-SEMERU
(replication package de arXiv:2601.19106), con el subconjunto y la
corrección de ruido de ground truth documentados en el paper adjunto.

Este dataset NO se redistribuye en este paquete (el repo de origen no
declara licencia). Para reproducir, bajalo vos mismo:
    https://github.com/WM-SEMERU/Hallucinations-in-Code
    archivo: hallucination_pipeline/data/generated_dataset.csv

Uso:
    python eval_function_existence.py --dataset generated_dataset.csv --kb function_kb.json --out results_manifest.json
"""

import argparse
import csv
import json
import sys

sys.path.insert(0, ".")
from validate_function_call import code_has_hallucinated_call

PRIMARY_REASONS = {
    "API misuse (Incorrect function name)",
    "API substitution (Incorrect function name)",
    "No hallucination",
}
EXCLUDED_REASONS = {
    "API misuse (Missing import)",
    "API substitution (Missing import)",
    "API misuse (Bare call without alias)",
    "Contextual misnaming (.csv path implies read_csv)",
    "Contextual normalization (stream → load)",
    "API substitution (Missing import + wrong name)",
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", default="generated_dataset.csv")
    parser.add_argument("--kb", default="function_kb.json")
    parser.add_argument("--out", default="results_manifest.json")
    args = parser.parse_args()

    with open(args.kb, "r", encoding="utf-8") as f:
        kb = json.load(f)
    with open(args.dataset, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    primary_rows = [r for r in rows if r["reason"] in PRIMARY_REASONS]
    excluded_rows = [r for r in rows if r["reason"] in EXCLUDED_REASONS]
    unclassified = [r for r in rows if r["reason"] not in PRIMARY_REASONS and r["reason"] not in EXCLUDED_REASONS]

    print(f"Total filas: {len(rows)}")
    print(f"Subconjunto primario: {len(primary_rows)}")
    print(f"Excluidas (missing import / contextual, fuera de alcance): {len(excluded_rows)}")
    if unclassified:
        print(f"ADVERTENCIA: {len(unclassified)} filas con reason no reconocido, revisar manualmente.")

    # Paso 1: detectar filas de ruido de ground truth (el propio ground_truth
    # falla nuestro validador -- mismo criterio que la exclusión de asserts
    # rotos de MBPP en R2.1).
    noise_ids = set()
    for r in primary_rows:
        if code_has_hallucinated_call(r["ground_truth"], kb):
            noise_ids.add(r["id"])
        if r["reason"] == "No hallucination" and r["hallucination"] == r["ground_truth"]:
            if code_has_hallucinated_call(r["hallucination"], kb):
                noise_ids.add(r["id"])

    clean_rows = [r for r in primary_rows if r["id"] not in noise_ids]
    print(f"Filas excluidas por ruido de ground truth: {sorted(noise_ids)}")
    print(f"Filas limpias evaluadas: {len(clean_rows)}")
    print()

    # Paso 2: evaluar
    tp = fp = tn = fn = 0
    manifest = []

    for r in clean_rows:
        is_hallucinated = r["reason"] != "No hallucination"
        pred_hall = code_has_hallucinated_call(r["hallucination"], kb)
        pred_gt = code_has_hallucinated_call(r["ground_truth"], kb)

        if pred_hall and is_hallucinated:
            tp += 1
            outcome_hall = "TP"
        elif pred_hall and not is_hallucinated:
            fp += 1
            outcome_hall = "FP"
        elif not pred_hall and not is_hallucinated:
            tn += 1
            outcome_hall = "TN"
        else:
            fn += 1
            outcome_hall = "FN"

        if pred_gt:
            fp += 1
            outcome_gt = "FP"
        else:
            tn += 1
            outcome_gt = "TN"

        manifest.append({
            "id": r["id"],
            "reason": r["reason"],
            "outcome_hallucination_column": outcome_hall,
            "outcome_ground_truth_column": outcome_gt,
        })

    for nid in sorted(noise_ids):
        manifest.append({"id": nid, "reason": "EXCLUDED_GROUND_TRUTH_NOISE", "note": "pd.groupby used as a module-level call; not a real pandas API (verified: AttributeError on import)"})

    precision = tp / (tp + fp) if (tp + fp) else 0
    recall = tp / (tp + fn) if (tp + fn) else 0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0

    print("=== Resultado final (post-corrección de ground truth) ===")
    print(f"TP={tp}  FP={fp}")
    print(f"FN={fn}  TN={tn}")
    print(f"Precision: {precision:.4f}")
    print(f"Recall:    {recall:.4f}")
    print(f"F1:        {f1:.4f}")
    print()
    print("Comparacion, arXiv:2601.19106 (200 filas completas, metodologia similar):")
    print("  Precision: 1.0000 | Recall: 0.8760 | F1: 0.9340")

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump({
            "summary": {"tp": tp, "fp": fp, "fn": fn, "tn": tn, "precision": precision, "recall": recall, "f1": f1},
            "excluded_row_ids": sorted(noise_ids),
            "per_row_manifest": manifest,
        }, f, indent=2)
    print(f"\nManifiesto de resultados (por ID de fila, sin contenido de código) guardado en: {args.out}")


if __name__ == "__main__":
    main()
