#!/usr/bin/env python3
"""
r1_module_runner.py

Run raw SAS module outputs over R1 validation/test pairs.

Patch level: v1.0.7
-------------------
Cross-audit patches included:
- NIG is treated as source-aware only if its signature supports source/context.
  Otherwise it is marked DIAGNOSTIC_ONLY/STANDALONE_ONLY and should not be
  used as a divergence vote in the R1 tribunal.
- DECM receives real isi_tda from the same pair when available. If TDA is
  skipped or failed, DECM is marked DIAGNOSTIC_ONLY with explicit reason.
- MSC is marked DIAGNOSTIC_ONLY because dummy restatements are not valid
  independent evidence for the tribunal.
- Source/candidate original SHA-256 and truncation flags are stored in every row.
- Batch output SHA-256 hashes are written to run_manifest.json.
- Basic numeric range validation warnings are attached per module.
- Optional TDA sampling is supported to avoid long full runs.
- v1.0.2 adds --skip-msc and --max-runtime-hours safeguards.

Design principle
----------------
This script does NOT use the API final verdict as the scientific target.
It stores raw/normalized module outputs only. Thresholds and tribunal decisions
must be calibrated later on validation before evaluating test.
"""

from __future__ import annotations

import argparse
import dataclasses
import hashlib
import inspect
import json
import math
import re
import sys
import time
import traceback
from pathlib import Path
from typing import Any, Callable

SCRIPT_PATH = Path(__file__).resolve()
REPO_ROOT = SCRIPT_PATH.parents[1]
for candidate in (REPO_ROOT, REPO_ROOT / "src"):
    s = str(candidate)
    if s not in sys.path:
        sys.path.insert(0, s)

DEFAULT_VALIDATION = REPO_ROOT / "outputs" / "r1_dataset" / "validation.jsonl"
DEFAULT_TEST = REPO_ROOT / "outputs" / "r1_dataset" / "test.jsonl"
DEFAULT_OUTPUT_DIR = REPO_ROOT / "outputs" / "r1_results"

CODE_HINT_RE = re.compile(
    r"(^\s*(def|class|import|from)\s+|;\s*$|\{\s*$|\}\s*$|=>|function\s+|console\.log|return\s+)",
    re.MULTILINE,
)

ISI_KEYS = (
    "isi_tda", "isi_nig", "isi_cre", "isi_msc", "isi_decm", "isi_code",
    "penalty", "combined_penalty", "weighted_score",
)


def to_jsonable(obj: Any, max_string: int = 4000) -> Any:
    if obj is None or isinstance(obj, (bool, int, float, str)):
        if isinstance(obj, str) and len(obj) > max_string:
            return obj[:max_string] + "...<truncated>"
        return obj
    if dataclasses.is_dataclass(obj):
        return to_jsonable(dataclasses.asdict(obj), max_string=max_string)
    if hasattr(obj, "to_dict") and callable(obj.to_dict):
        try:
            return to_jsonable(obj.to_dict(), max_string=max_string)
        except Exception:
            pass
    if hasattr(obj, "to_json") and callable(obj.to_json):
        try:
            return json.loads(obj.to_json())
        except Exception:
            pass
    if isinstance(obj, dict):
        return {str(k): to_jsonable(v, max_string=max_string) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [to_jsonable(x, max_string=max_string) for x in list(obj)[:200]]
    if hasattr(obj, "__dict__"):
        return to_jsonable(vars(obj), max_string=max_string)
    return repr(obj)[:max_string]


def stable_json(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def sha256_text(text: str) -> str:
    return hashlib.sha256((text or "").encode("utf-8", errors="replace")).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if not path.exists():
        return rows
    with path.open("r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ValueError(f"Malformed JSONL {path}:{line_no}: {exc}") from exc
    return rows


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(stable_json(row) + "\n")


def existing_pair_ids(output_dir: Path) -> set[str]:
    ids: set[str] = set()
    for path in sorted(output_dir.glob("batch_*.jsonl")):
        for row in read_jsonl(path):
            pair_id = row.get("pair_id")
            if pair_id:
                ids.add(str(pair_id))
    return ids


def truncate(text: str, limit: int) -> tuple[str, bool]:
    text = text or ""
    if len(text) <= limit:
        return text, False
    return text[:limit] + "...<truncated>", True


def maybe_float(value: Any) -> float | None:
    try:
        if value is None:
            return None
        x = float(value)
        if math.isnan(x) or math.isinf(x):
            return None
        return x
    except Exception:
        return None


def add_range_warnings(module_name: str, out: dict[str, Any]) -> dict[str, Any]:
    warnings: list[str] = list(out.get("warnings", [])) if isinstance(out.get("warnings"), list) else []
    for key in ISI_KEYS:
        if key not in out:
            continue
        value = maybe_float(out.get(key))
        if value is None:
            if out.get(key) is not None:
                warnings.append(f"{module_name}.{key} is non-numeric or NaN: {out.get(key)!r}")
            continue
        if not (0.0 <= value <= 1.0):
            warnings.append(f"{module_name}.{key} outside [0,1]: {value}")
    if warnings:
        out["warnings"] = warnings
    return out


def module_error(exc: Exception, runtime_ms: float) -> dict[str, Any]:
    return {
        "status": "ERROR",
        "error_type": type(exc).__name__,
        "error": str(exc),
        "runtime_ms": round(runtime_ms, 3),
        "traceback": traceback.format_exc(limit=6),
    }


def run_module(name: str, fn: Callable[[str, str], dict[str, Any]], source: str, candidate: str) -> dict[str, Any]:
    t0 = time.perf_counter()
    try:
        out = fn(source, candidate)
        runtime_ms = (time.perf_counter() - t0) * 1000.0
        if isinstance(out, dict):
            out.setdefault("status", "OK")
            out.setdefault("runtime_ms", round(runtime_ms, 3))
            return add_range_warnings(name, out)
        return add_range_warnings(name, {"status": "OK", "runtime_ms": round(runtime_ms, 3), "raw": to_jsonable(out)})
    except Exception as exc:
        runtime_ms = (time.perf_counter() - t0) * 1000.0
        return module_error(exc, runtime_ms)


def run_tda(source: str, candidate: str) -> dict[str, Any]:
    from core.semantic_diff import quick_diff

    report = quick_diff(
        source,
        candidate,
        kappa_d=0.56,
        label_a="A_clean",
        label_b="candidate",
        adaptive_kappa=False,
        experimental=False,
    )
    raw = to_jsonable(report)
    return {
        "isi_tda": getattr(report, "isi_tda", None),
        "wasserstein_h1": getattr(report, "wasserstein_h1", None),
        "bottleneck_h1": getattr(report, "bottleneck_h1", None),
        "wasserstein_h0": getattr(report, "wasserstein_h0", None),
        "effective_kappa": getattr(report, "effective_kappa", 0.56),
        "lexical_overlap": getattr(report, "lexical_overlap", None),
        "measurement_surface": "core.semantic_diff.quick_diff",
        "note": "This is the SAS quick_diff surface, not necessarily isolated pure TDA.",
        "raw": raw,
    }




def ensure_jsonable(obj):
    """Best-effort conversion of module return objects into JSON-safe structures."""
    import dataclasses

    if obj is None or isinstance(obj, (str, int, float, bool)):
        return obj

    if dataclasses.is_dataclass(obj):
        return ensure_jsonable(dataclasses.asdict(obj))

    if isinstance(obj, dict):
        return {str(k): ensure_jsonable(v) for k, v in obj.items()}

    if isinstance(obj, (list, tuple, set)):
        return [ensure_jsonable(v) for v in obj]

    if hasattr(obj, "_asdict"):
        return ensure_jsonable(obj._asdict())

    if hasattr(obj, "__dict__"):
        return {
            str(k): ensure_jsonable(v)
            for k, v in vars(obj).items()
            if not str(k).startswith("_")
        }

    return repr(obj)


def ensure_dict(value: Any) -> dict[str, Any]:
    """
    Convert heterogeneous SAS core outputs into a dict without losing traceability.

    v1.0.7 patch:
    Some local SAS core modules return dataclasses, pydantic-like objects, plain
    scalars, tuples/lists, or custom objects. NIG used ensure_dict(), but the
    helper was missing in v1.0.5. This implementation keeps the runner defensive
    and JSONL-safe.
    """
    if isinstance(value, dict):
        return dict(value)

    if value is None:
        return {"raw": None}

    if hasattr(value, "model_dump"):
        try:
            dumped = value.model_dump()
            if isinstance(dumped, dict):
                return dumped
            return {"raw": ensure_jsonable(dumped)}
        except Exception as exc:
            return {"raw_repr": repr(value), "conversion_error": str(exc)}

    if hasattr(value, "dict"):
        try:
            dumped = value.dict()
            if isinstance(dumped, dict):
                return dumped
            return {"raw": ensure_jsonable(dumped)}
        except Exception as exc:
            return {"raw_repr": repr(value), "conversion_error": str(exc)}

    if hasattr(value, "__dict__"):
        try:
            return {k: ensure_jsonable(v) for k, v in vars(value).items() if not k.startswith("_")}
        except Exception as exc:
            return {"raw_repr": repr(value), "conversion_error": str(exc)}

    return {
        "raw": ensure_jsonable(value),
        "raw_type": type(value).__name__,
    }


def run_nig_module(source: str, candidate: str) -> dict[str, Any]:
    """
    Run NIG safely.

    v1.0.7 audit patch:
    Do not infer source-awareness from positional arity. A function such as
    run_nig(text, domain="...") has two parameters but is not a source-candidate
    comparator. Only explicit keyword names ("source", "context", "reference")
    are treated as source-aware.
    """
    # v1.0.7 local-core compatibility patch:
    # The SAS core in the current repository exposes NIG as core.nig_engine_v1.run_nig.
    # Older scaffold drafts tried core.nig.run_nig, which fails on SAS-main.
    try:
        from core.nig_engine_v1 import run_nig
        nig_import_path = "core.nig_engine_v1.run_nig"
    except ImportError:
        from core.nig import run_nig
        nig_import_path = "core.nig.run_nig"

    sig = inspect.signature(run_nig)
    params = sig.parameters
    source_keyword = next((name for name in ("source", "context", "reference") if name in params), None)
    source_aware = source_keyword is not None

    if source_keyword == "source":
        raw = run_nig(candidate, source=source)
    elif source_keyword == "context":
        raw = run_nig(candidate, context=source)
    elif source_keyword == "reference":
        raw = run_nig(candidate, reference=source)
    else:
        raw = run_nig(candidate)

    result = ensure_dict(raw)
    result.setdefault("import_path", nig_import_path)
    result.setdefault("source_aware", source_aware)
    if source_aware:
        result.setdefault("tribunal_role", "SOURCE_CANDIDATE_SIGNAL")
        result.setdefault("limitations", "NIG accepted an explicit source/context/reference keyword.")
    else:
        result.setdefault("tribunal_role", "DIAGNOSTIC_ONLY_STANDALONE")
        result.setdefault(
            "limitations",
            "NIG did not expose an explicit source/context/reference parameter; output is standalone candidate scoring and must not be used as a source-candidate divergence vote.",
        )
    return result


def run_negation_module(source: str, candidate: str) -> dict[str, Any]:
    from core.negation_probe import detect_inversions

    result = detect_inversions(source, candidate)
    data = to_jsonable(result)
    return {
        "inversion_count": data.get("inversion_count"),
        "weighted_score": data.get("weighted_inversion_score"),
        "penalty": data.get("penalty"),
        "polarity_inverted": data.get("polarity_inverted"),
        "quantifier_changed": data.get("quantifier_changed"),
        "raw": data,
    }


def run_reference_module(source: str, candidate: str) -> dict[str, Any]:
    from core.reference_check import detect_fabrications

    result = detect_fabrications(source, candidate)
    data = to_jsonable(result)
    return {
        "fabricated_count": data.get("fabricated_count"),
        "anachronistic_count": data.get("anachronistic_count"),
        "penalty": data.get("penalty"),
        "raw": data,
    }


def run_arithmetic_module(source: str, candidate: str) -> dict[str, Any]:
    from core.arithmetic_detector import detect_arithmetic_errors

    result = detect_arithmetic_errors(candidate)
    data = to_jsonable(result)
    return {
        "error_count": data.get("error_count"),
        "penalty": data.get("penalty"),
        "tribunal_role": "candidate_intrinsic_numeric_check",
        "raw": data,
    }


def run_entropy_density_module(source: str, candidate: str) -> dict[str, Any]:
    from core.entropy_density import compute_entropy_density

    result = compute_entropy_density(candidate)
    data = to_jsonable(result)
    return {
        "is_artificial": data.get("is_artificial"),
        "penalty": data.get("penalty"),
        "mean_entropy": data.get("mean_entropy"),
        "variance": data.get("variance"),
        "tribunal_role": "candidate_intrinsic_style_check",
        "raw": data,
    }


def run_flow_module(source: str, candidate: str) -> dict[str, Any]:
    from core.flow_coherence import run_flow_coherence

    result = run_flow_coherence(source, candidate)
    data = to_jsonable(result)
    return {
        "combined_penalty": data.get("combined_penalty", data.get("penalty", data.get("flow_penalty"))),
        "layer4_fired": data.get("layer4_fired", data.get("fired", data.get("flow_fired"))),
        "raw": data,
    }


def run_cre_module(source: str, candidate: str) -> dict[str, Any]:
    from core.ricci_enhanced_cre import run_cre_ricci

    result = run_cre_ricci(source, candidate)
    data = to_jsonable(result)
    return {
        "isi_cre": data.get("isi_cre", data.get("isi_ricci", data.get("isi"))),
        "ricci_singularities": data.get("ricci_singularities", data.get("singularities")),
        "classification": data.get("classification", data.get("verdict")),
        "raw": data,
    }


def run_msc_module(source: str, candidate: str) -> dict[str, Any]:
    # v1.0.7 audit patch: MSC is diagnostic-only; no artificial isi_tda is injected.
    from core.msc_engine_v5 import msc_v5_from_texts

    texts = [
        source,
        candidate,
        f"Source-preserving restatement: {source}",
        f"Candidate-preserving restatement: {candidate}",
    ]
    result = msc_v5_from_texts(texts, isi_tda=None, domain="r1_pilot")
    data = to_jsonable(result)
    return {
        "status": "DIAGNOSTIC_ONLY",
        "isi_msc": data.get("isi_msc", data.get("isi")),
        "sigma": data.get("sigma"),
        "tribunal_role": "DIAGNOSTIC_ONLY",
        "limitations": "Uses dummy restatements; not an independent vote for R1 tribunal until real paraphrase inputs exist.",
        "raw": data,
    }


def run_decm_module_with_tda(source: str, candidate: str, tda_out: dict[str, Any] | None) -> dict[str, Any]:
    if not tda_out or tda_out.get("status") == "ERROR":
        return {
            "status": "DIAGNOSTIC_ONLY",
            "tribunal_role": "DIAGNOSTIC_ONLY",
            "reason": "TDA unavailable; DECM requires real isi_tda from same pair.",
            "isi_decm": None,
        }
    isi_tda = maybe_float(tda_out.get("isi_tda"))
    if isi_tda is None:
        return {
            "status": "DIAGNOSTIC_ONLY",
            "tribunal_role": "DIAGNOSTIC_ONLY",
            "reason": f"TDA output did not provide numeric isi_tda: {tda_out.get('isi_tda')!r}",
            "isi_decm": None,
        }

    from core.thermic_invariance_v5 import ThermicInvarianceDetector

    detector = ThermicInvarianceDetector(backend=None)
    result = detector.detect(candidate, isi_tda=isi_tda, domain="r1_pilot")
    data = to_jsonable(result)
    return {
        "isi_decm": data.get("isi_decm", data.get("isi")),
        "verdict": data.get("verdict", data.get("classification")),
        "input_isi_tda": isi_tda,
        "raw": data,
    }


def is_code_like(text: str) -> bool:
    return bool(CODE_HINT_RE.search(text or ""))


def run_code_ast_module(source: str, candidate: str) -> dict[str, Any]:
    if not (is_code_like(source) or is_code_like(candidate)):
        return {"status": "SKIPPED", "reason": "candidate/source not code-like", "isi_code": None}
    from core.code_ast_diff import code_diff_isi

    return {"isi_code": code_diff_isi(source, candidate)}


def should_run_tda(row: dict[str, Any], args: argparse.Namespace, index: int) -> bool:
    if args.tda_mode == "skip":
        return False
    if args.tda_mode == "full":
        return True
    if args.tda_mode == "sample":
        if args.tda_sample_limit is not None and index >= args.tda_sample_limit:
            return False
        frac = max(0.0, min(1.0, args.tda_sample_fraction))
        key = f"{row.get('pair_id')}|{args.seed}"
        bucket = int(hashlib.sha256(key.encode()).hexdigest()[:8], 16) / 0xFFFFFFFF
        return bucket <= frac
    raise ValueError(f"unknown tda_mode: {args.tda_mode}")


def process_pair(row: dict[str, Any], args: argparse.Namespace, index: int) -> dict[str, Any]:
    source = str(row.get("source") or "")
    candidate = str(row.get("candidate") or row.get("response") or "")
    pair_start = time.perf_counter()

    source_preview, source_truncated = truncate(source, args.text_preview_chars)
    candidate_preview, candidate_truncated = truncate(candidate, args.text_preview_chars)

    modules: dict[str, Any] = {}

    if should_run_tda(row, args, index):
        modules["tda"] = run_module("tda", run_tda, source, candidate)
    else:
        modules["tda"] = {
            "status": "SKIPPED",
            "reason": f"tda_mode={args.tda_mode}",
            "isi_tda": None,
            "tribunal_role": "unavailable_for_this_pair",
        }

    modules["nig"] = run_module("nig", run_nig_module, source, candidate)
    modules["negation"] = run_module("negation", run_negation_module, source, candidate)
    modules["reference"] = run_module("reference", run_reference_module, source, candidate)
    modules["arithmetic"] = run_module("arithmetic", run_arithmetic_module, source, candidate)
    modules["entropy_density"] = run_module("entropy_density", run_entropy_density_module, source, candidate)
    modules["flow"] = run_module("flow", run_flow_module, source, candidate)
    modules["cre"] = run_module("cre", run_cre_module, source, candidate)
    if args.skip_msc:
        modules["msc"] = {
            "status": "SKIPPED",
            "reason": "--skip-msc was set",
            "tribunal_role": "DIAGNOSTIC_ONLY",
            "limitations": "MSC dummy-restatement mode is diagnostic-only and was skipped to save runtime.",
            "isi_msc": None,
        }
    else:
        modules["msc"] = run_module("msc", run_msc_module, source, candidate)

    t0 = time.perf_counter()
    try:
        decm_out = run_decm_module_with_tda(source, candidate, modules.get("tda"))
        decm_ms = (time.perf_counter() - t0) * 1000.0
        decm_out.setdefault("runtime_ms", round(decm_ms, 3))
        decm_out.setdefault("status", "OK" if decm_out.get("isi_decm") is not None else decm_out.get("status", "DIAGNOSTIC_ONLY"))
        modules["decm"] = add_range_warnings("decm", decm_out)
    except Exception as exc:
        modules["decm"] = module_error(exc, (time.perf_counter() - t0) * 1000.0)

    modules["code_ast"] = run_module("code_ast", run_code_ast_module, source, candidate)

    total_runtime_ms = (time.perf_counter() - pair_start) * 1000.0
    return {
        "pair_id": str(row.get("pair_id") or f"PAIR_{index:08d}"),
        "source_id": row.get("source_id"),
        "track": row.get("track"),
        "source": source_preview,
        "candidate": candidate_preview,
        "source_original_sha256": row.get("source_sha256") or sha256_text(source),
        "candidate_original_sha256": row.get("candidate_sha256") or sha256_text(candidate),
        "source_truncated": source_truncated,
        "candidate_truncated": candidate_truncated,
        "label": int(row.get("label")) if row.get("label") is not None else None,
        "pair_type": row.get("pair_type"),
        "split": row.get("split"),
        "modules": modules,
        "runtime_ms": round(total_runtime_ms, 3),
    }


def batch_hashes(output_dir: Path) -> list[dict[str, Any]]:
    hashes = []
    for path in sorted(output_dir.glob("batch_*.jsonl")):
        hashes.append({
            "file": path.name,
            "path": str(path),
            "rows": sum(1 for line in path.open("r", encoding="utf-8") if line.strip()),
            "sha256": sha256_file(path),
        })
    return hashes


def main() -> int:
    parser = argparse.ArgumentParser(description="Run raw SAS module outputs over R1 validation/test pairs")
    parser.add_argument("--validation", type=Path, default=DEFAULT_VALIDATION)
    parser.add_argument("--test", type=Path, default=DEFAULT_TEST)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--batch-size", type=int, default=500)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--text-preview-chars", type=int, default=1000)
    parser.add_argument("--tda-mode", choices=["full", "sample", "skip"], default="full")
    parser.add_argument("--tda-sample-fraction", type=float, default=0.20)
    parser.add_argument("--tda-sample-limit", type=int, default=None)
    parser.add_argument("--skip-msc", action="store_true", help="Skip MSC diagnostic-only module to save runtime.")
    parser.add_argument("--dry-run", action="store_true", help="Inspect planned pairs/batches without executing SAS modules.")
    parser.add_argument(
        "--max-runtime-hours",
        type=float,
        default=None,
        help="Abort cleanly before starting a new pair if elapsed runtime exceeds this limit.",
    )
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    if args.batch_size <= 0:
        raise SystemExit("--batch-size must be positive")
    args.output_dir.mkdir(parents=True, exist_ok=True)

    rows = read_jsonl(args.validation) + read_jsonl(args.test)
    if args.limit is not None:
        rows = rows[:args.limit]
    if not rows:
        raise SystemExit("No validation/test rows found. Run r1_dataset_builder.py first.")

    processed = existing_pair_ids(args.output_dir) if args.resume else set()
    todo = [r for r in rows if str(r.get("pair_id")) not in processed]

    print("R1 MODULE RUNNER v1.0.7")
    print("=" * 80)
    print(f"validation: {args.validation}")
    print(f"test:       {args.test}")
    print(f"output:     {args.output_dir}")
    print(f"rows total: {len(rows)}")
    print(f"resume processed: {len(processed)}")
    print(f"todo:       {len(todo)}")
    print(f"tda_mode:   {args.tda_mode}")
    print(f"skip_msc:   {args.skip_msc}")
    print(f"max hours:  {args.max_runtime_hours}")
    print("=" * 80)


    if args.dry_run:
        preview = []
        for row in todo[: min(10, len(todo))]:
            preview.append({
                "pair_id": row.get("pair_id"),
                "split": row.get("split"),
                "track": row.get("track"),
                "label": row.get("label"),
            })
        dry_manifest = {
            "schema_version": "r1_module_runner_dry_run_v1.0.7",
            "validation": str(args.validation),
            "test": str(args.test),
            "output_dir": str(args.output_dir),
            "rows_input_total": len(rows),
            "already_processed": len(processed),
            "todo_total": len(todo),
            "batch_size": args.batch_size,
            "limit": args.limit,
            "tda_mode": args.tda_mode,
            "tda_sample_fraction": args.tda_sample_fraction,
            "tda_sample_limit": args.tda_sample_limit,
            "skip_msc": args.skip_msc,
            "max_runtime_hours": args.max_runtime_hours,
            "preview_first_10": preview,
            "note": "Dry run only; no SAS modules executed and no batch_*.jsonl files written.",
        }
        args.output_dir.mkdir(parents=True, exist_ok=True)
        dry_path = args.output_dir / "dry_run_manifest.json"
        dry_path.write_text(json.dumps(dry_manifest, indent=2, ensure_ascii=False), encoding="utf-8")
        print("[DRY-RUN] No modules executed.")
        print(f"[DRY-RUN] todo_total: {len(todo)}")
        print(f"[DRY-RUN] preview written to: {dry_path}")
        return 0

    start = time.perf_counter()
    buffer: list[dict[str, Any]] = []
    batch_idx = len(list(args.output_dir.glob("batch_*.jsonl"))) + 1 if args.resume else 1
    written = 0

    aborted_due_runtime_limit = False
    for idx, row in enumerate(todo):
        elapsed_hours = (time.perf_counter() - start) / 3600.0
        if args.max_runtime_hours is not None and elapsed_hours >= args.max_runtime_hours:
            print(f"[WARN] max runtime reached ({elapsed_hours:.4f}h >= {args.max_runtime_hours}h). Stopping cleanly.")
            aborted_due_runtime_limit = True
            break

        pair_id = str(row.get("pair_id") or f"PAIR_{idx:08d}")
        print(f"[{idx + 1}/{len(todo)}] {pair_id}")
        result = process_pair(row, args, idx)
        buffer.append(result)

        if len(buffer) >= args.batch_size:
            out_path = args.output_dir / f"batch_{batch_idx:06d}.jsonl"
            write_jsonl(out_path, buffer)
            print(f"Wrote {out_path} ({len(buffer)} rows) sha256={sha256_file(out_path)[:12]}...")
            written += len(buffer)
            buffer = []
            batch_idx += 1

    if buffer:
        out_path = args.output_dir / f"batch_{batch_idx:06d}.jsonl"
        write_jsonl(out_path, buffer)
        print(f"Wrote {out_path} ({len(buffer)} rows) sha256={sha256_file(out_path)[:12]}...")
        written += len(buffer)

    total_ms = (time.perf_counter() - start) * 1000.0
    hashes = batch_hashes(args.output_dir)
    run_manifest = {
        "script": "r1_module_runner.py",
        "schema_version": "r1_module_runner_v1.0.7",
        "script_sha256": sha256_file(SCRIPT_PATH),
        "validation": str(args.validation),
        "test": str(args.test),
        "output_dir": str(args.output_dir),
        "batch_size": args.batch_size,
        "resume": args.resume,
        "limit": args.limit,
        "text_preview_chars": args.text_preview_chars,
        "tda_mode": args.tda_mode,
        "tda_sample_fraction": args.tda_sample_fraction,
        "tda_sample_limit": args.tda_sample_limit,
        "skip_msc": args.skip_msc,
        "max_runtime_hours": args.max_runtime_hours,
        "aborted_due_runtime_limit": aborted_due_runtime_limit,
        "rows_input_total": len(rows),
        "rows_previously_processed": len(processed),
        "rows_written_this_run": written,
        "runtime_ms": round(total_ms, 3),
        "runtime_hours": round(total_ms / 1000.0 / 3600.0, 4),
        "batch_outputs": hashes,
        "scientific_notes": [
            "Raw module outputs only. Do not treat this as final API verdict evidence.",
            "NIG may be DIAGNOSTIC_ONLY if core.run_nig is standalone-only.",
            "MSC is DIAGNOSTIC_ONLY because dummy restatements are not independent evidence.",
            "DECM receives real isi_tda when available; otherwise it is DIAGNOSTIC_ONLY.",
            "Threshold/tribunal computation belongs to a later validation-calibrated evaluation step.",
        ],
    }
    manifest_path = args.output_dir / "run_manifest.json"
    manifest_path.write_text(json.dumps(run_manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print("=" * 80)
    print(f"Done. Wrote {written} rows in {total_ms/1000.0:.2f}s")
    print(f"Manifest: {manifest_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
