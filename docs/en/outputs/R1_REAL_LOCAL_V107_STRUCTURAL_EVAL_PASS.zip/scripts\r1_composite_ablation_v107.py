﻿import json
from pathlib import Path

RUN_DIR = Path("outputs/r1_results_light_full_real_v107")
DATASET_FILES = [
    Path("outputs/r1_dataset/validation.jsonl"),
    Path("outputs/r1_dataset/test.jsonl"),
]
OUT = Path("outputs/r1_eval")
OUT.mkdir(parents=True, exist_ok=True)

def load_jsonl(p):
    return [json.loads(x) for x in p.read_text(encoding="utf-8").splitlines() if x.strip()]

def metrics(y, pred):
    tp = sum(1 for yy, pp in zip(y, pred) if yy == 1 and pp == 1)
    fp = sum(1 for yy, pp in zip(y, pred) if yy == 0 and pp == 1)
    fn = sum(1 for yy, pp in zip(y, pred) if yy == 1 and pp == 0)
    tn = sum(1 for yy, pp in zip(y, pred) if yy == 0 and pp == 0)
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    acc = (tp + tn) / max(1, tp + tn + fp + fn)
    return {"accuracy": acc, "precision": precision, "recall": recall, "f1": f1, "tp": tp, "fp": fp, "fn": fn, "tn": tn}

run_rows = []
for p in sorted(RUN_DIR.glob("batch_*.jsonl")):
    run_rows.extend(load_jsonl(p))

data_rows = []
for p in DATASET_FILES:
    data_rows.extend(load_jsonl(p))

by_pair_id = {r.get("pair_id"): r for r in run_rows}

joined = []
for d in data_rows:
    r = by_pair_id.get(d.get("pair_id"))
    if not r:
        continue

    m = r.get("modules", {})
    joined.append({
        "split": d.get("split"),
        "label": int(d.get("label")),
        "flow": int(bool(m.get("flow", {}).get("layer4_fired"))),
        "cre": int(bool(m.get("cre", {}).get("raw", {}).get("is_rupture"))),
        "negation": int(bool(m.get("negation", {}).get("polarity_inverted"))),
        "nig": int(bool(m.get("nig", {}).get("alert"))),
    })

val = [r for r in joined if r["split"] == "validation"]
test = [r for r in joined if r["split"] == "test"]

rules = {
    "flow_only": ["flow"],
    "cre_only": ["cre"],
    "negation_only": ["negation"],
    "nig_only": ["nig"],
    "flow_cre": ["flow", "cre"],
    "flow_negation": ["flow", "negation"],
    "flow_nig": ["flow", "nig"],
    "flow_cre_negation": ["flow", "cre", "negation"],
    "flow_cre_negation_nig": ["flow", "cre", "negation", "nig"],
}

report = {}

for name, feats in rules.items():
    report[name] = {}
    for th in range(1, len(feats) + 1):
        for split_name, rows in [("validation", val), ("test", test)]:
            y = [r["label"] for r in rows]
            pred = [1 if sum(r[f] for f in feats) >= th else 0 for r in rows]
            report[name][f"{split_name}_score>={th}"] = metrics(y, pred)

print("joined:", len(joined))
print("validation:", len(val))
print("test:", len(test))
print()

for name, feats in rules.items():
    print("=" * 90)
    print(name, feats)
    for th in range(1, len(feats) + 1):
        v = report[name][f"validation_score>={th}"]
        t = report[name][f"test_score>={th}"]
        print(
            "score>=", th,
            "val_f1=", round(v["f1"], 4),
            "test_f1=", round(t["f1"], 4),
            "test_prec=", round(t["precision"], 4),
            "test_rec=", round(t["recall"], 4),
            "test_acc=", round(t["accuracy"], 4),
        )

out = OUT / "r1_real_v107_composite_ablation.json"
out.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
print()
print("Wrote:", out)
