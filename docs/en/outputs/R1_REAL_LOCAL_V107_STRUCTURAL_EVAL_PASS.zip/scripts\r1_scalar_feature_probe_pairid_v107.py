﻿import json
import math
from pathlib import Path
from collections import defaultdict

RUN_DIR = Path("outputs/r1_results_light_full_real_v107")
DATASET_FILES = [
    Path("outputs/r1_dataset/validation.jsonl"),
    Path("outputs/r1_dataset/test.jsonl"),
]

OUT = Path("outputs/r1_eval")
OUT.mkdir(parents=True, exist_ok=True)

def load_jsonl(p):
    return [json.loads(x) for x in p.read_text(encoding="utf-8").splitlines() if x.strip()]

def flatten_numeric(obj, prefix=""):
    out = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            out.update(flatten_numeric(v, key))
    elif isinstance(obj, bool):
        out[prefix] = float(obj)
    elif isinstance(obj, (int, float)) and not isinstance(obj, bool):
        if math.isfinite(float(obj)):
            out[prefix] = float(obj)
    return out

def auc_rank(labels, scores):
    pairs = [(float(s), int(y)) for y, s in zip(labels, scores) if s is not None and math.isfinite(float(s))]
    if not pairs:
        return None
    n_pos = sum(1 for _, y in pairs if y == 1)
    n_neg = sum(1 for _, y in pairs if y == 0)
    if n_pos == 0 or n_neg == 0:
        return None

    pairs.sort(key=lambda x: x[0])
    rank_sum_pos = 0.0
    i = 0
    rank = 1
    while i < len(pairs):
        j = i
        while j < len(pairs) and pairs[j][0] == pairs[i][0]:
            j += 1
        avg_rank = (rank + rank + (j - i) - 1) / 2.0
        for k in range(i, j):
            if pairs[k][1] == 1:
                rank_sum_pos += avg_rank
        rank += j - i
        i = j

    return (rank_sum_pos - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg)

run_rows = []
for p in sorted(RUN_DIR.glob("batch_*.jsonl")):
    run_rows.extend(load_jsonl(p))

data_rows = []
for p in DATASET_FILES:
    data_rows.extend(load_jsonl(p))

by_pair_id = {r.get("pair_id"): r for r in run_rows}

joined = []
missing = 0
for d in data_rows:
    rr = by_pair_id.get(d.get("pair_id"))
    if rr is None:
        missing += 1
        continue

    features = {}
    for mod, payload in rr.get("modules", {}).items():
        features.update(flatten_numeric(payload, mod))

    joined.append({
        "split": d.get("split"),
        "pair_id": d.get("pair_id"),
        "source_id": d.get("source_id"),
        "track": d.get("track"),
        "label": int(d.get("label")),
        "features": features,
    })

print("run_rows:", len(run_rows))
print("dataset_rows:", len(data_rows))
print("joined:", len(joined))
print("missing:", missing)

features = sorted({k for r in joined for k in r["features"]})
print("numeric_features:", len(features))

results = []
for feat in features:
    val = [r for r in joined if r["split"] == "validation" and feat in r["features"]]
    test = [r for r in joined if r["split"] == "test" and feat in r["features"]]

    if len(val) < 50 or len(test) < 50:
        continue

    yv = [r["label"] for r in val]
    sv = [r["features"][feat] for r in val]
    yt = [r["label"] for r in test]
    st = [r["features"][feat] for r in test]

    auc_v = auc_rank(yv, sv)
    auc_t = auc_rank(yt, st)
    if auc_v is None or auc_t is None:
        continue

    results.append({
        "feature": feat,
        "validation_auc": auc_v,
        "validation_auc_best": max(auc_v, 1 - auc_v),
        "test_auc": auc_t,
        "test_auc_best": max(auc_t, 1 - auc_t),
        "validation_n": len(val),
        "test_n": len(test),
    })

results.sort(key=lambda r: r["test_auc_best"], reverse=True)

out = OUT / "r1_real_scalar_feature_probe_pairid.json"
out.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")

print()
print("top 40 by test_auc_best:")
for r in results[:40]:
    print(
        f"{r['feature'][:70]:70s}",
        "val_auc_best=", round(r["validation_auc_best"], 4),
        "test_auc_best=", round(r["test_auc_best"], 4),
        "n=", r["test_n"],
    )

print()
print("Wrote:", out)
