﻿import json
import math
from pathlib import Path

RUN_DIR = Path("outputs/r1_results_light_full_real_v107")
DATASET_FILES = [
    Path("outputs/r1_dataset/validation.jsonl"),
    Path("outputs/r1_dataset/test.jsonl"),
]
OUT = Path("outputs/r1_eval")
OUT.mkdir(parents=True, exist_ok=True)

FEATURES = [
    "flow.combined_penalty",
    "flow.layer4_fired",
    "flow.raw.entropy_penalty",
    "cre.raw.ricci_scalar_max",
    "cre.raw.ricci_scalar_mean",
    "cre.raw.hessian_trace_max",
    "cre.raw.hessian_trace_mean",
    "cre.raw.is_rupture",
    "cre.isi_cre",
    "negation.penalty",
    "negation.polarity_inverted",
    "negation.inversion_count",
    "nig.isi_nig",
    "nig.violations_count",
    "nig.alert",
    "nig.entities_found",
]

def load_jsonl(p):
    return [json.loads(x) for x in p.read_text(encoding="utf-8").splitlines() if x.strip()]

def flatten_numeric(obj, prefix=""):
    out = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            out.update(flatten_numeric(v, key))
    elif isinstance(obj, bool):
        out[prefix] = float(obj)
    elif isinstance(obj, (int, float)) and not isinstance(obj, bool):
        if math.isfinite(float(obj)):
            out[prefix] = float(obj)
    return out

def metrics(y, pred):
    tp = sum(1 for yy, pp in zip(y, pred) if yy == 1 and pp == 1)
    fp = sum(1 for yy, pp in zip(y, pred) if yy == 0 and pp == 1)
    fn = sum(1 for yy, pp in zip(y, pred) if yy == 1 and pp == 0)
    tn = sum(1 for yy, pp in zip(y, pred) if yy == 0 and pp == 0)

    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    acc = (tp + tn) / max(1, tp + tn + fp + fn)

    return {
        "accuracy": acc,
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "tn": tn,
    }

def best_threshold(rows, feat):
    vals = sorted(set(r["features"][feat] for r in rows if feat in r["features"]))
    best = None

    for direction in ["high_is_hall", "low_is_hall"]:
        for th in vals:
            y = [r["label"] for r in rows if feat in r["features"]]
            pred = []
            for r in rows:
                if feat not in r["features"]:
                    continue
                s = r["features"][feat]
                pred.append(1 if (s >= th if direction == "high_is_hall" else s <= th) else 0)

            m = metrics(y, pred)
            item = {
                "feature": feat,
                "threshold": th,
                "direction": direction,
                **m,
            }

            if best is None or item["f1"] > best["f1"]:
                best = item

    return best

def apply_threshold(rows, feat, th, direction):
    y = []
    pred = []
    for r in rows:
        if feat not in r["features"]:
            continue
        s = r["features"][feat]
        y.append(r["label"])
        pred.append(1 if (s >= th if direction == "high_is_hall" else s <= th) else 0)
    return metrics(y, pred)

run_rows = []
for p in sorted(RUN_DIR.glob("batch_*.jsonl")):
    run_rows.extend(load_jsonl(p))

data_rows = []
for p in DATASET_FILES:
    data_rows.extend(load_jsonl(p))

by_pair_id = {r.get("pair_id"): r for r in run_rows}

joined = []
for d in data_rows:
    rr = by_pair_id.get(d.get("pair_id"))
    if rr is None:
        continue

    features = {}
    for mod, payload in rr.get("modules", {}).items():
        features.update(flatten_numeric(payload, mod))

    joined.append({
        "split": d.get("split"),
        "pair_id": d.get("pair_id"),
        "source_id": d.get("source_id"),
        "track": d.get("track"),
        "label": int(d.get("label")),
        "features": features,
    })

val = [r for r in joined if r["split"] == "validation"]
test = [r for r in joined if r["split"] == "test"]

results = []
for feat in FEATURES:
    if sum(1 for r in val if feat in r["features"]) < 50:
        continue
    if sum(1 for r in test if feat in r["features"]) < 50:
        continue

    cal = best_threshold(val, feat)
    tst = apply_threshold(test, feat, cal["threshold"], cal["direction"])

    results.append({
        "feature": feat,
        "validation": cal,
        "test_at_validation_threshold": tst,
    })

results.sort(key=lambda r: r["test_at_validation_threshold"]["f1"], reverse=True)

print("joined:", len(joined))
print("validation:", len(val))
print("test:", len(test))
print()
print("single-feature calibrated results:")
for r in results:
    v = r["validation"]
    t = r["test_at_validation_threshold"]
    print(
        f"{r['feature']:35s}",
        "dir=", v["direction"],
        "th=", round(v["threshold"], 6) if isinstance(v["threshold"], float) else v["threshold"],
        "val_f1=", round(v["f1"], 4),
        "test_f1=", round(t["f1"], 4),
        "test_prec=", round(t["precision"], 4),
        "test_rec=", round(t["recall"], 4),
        "test_acc=", round(t["accuracy"], 4),
    )

# Simple rule composites, calibrated manually from validation-derived intuitive signals.
def composite_score(f):
    score = 0
    if f.get("flow.layer4_fired", 0) >= 1:
        score += 2
    if f.get("cre.raw.is_rupture", 0) >= 1:
        score += 1
    if f.get("negation.polarity_inverted", 0) >= 1:
        score += 1
    if f.get("nig.alert", 0) >= 1:
        score += 1
    return score

def eval_composite(rows, threshold):
    y = [r["label"] for r in rows]
    pred = [1 if composite_score(r["features"]) >= threshold else 0 for r in rows]
    return metrics(y, pred)

composites = []
for th in [1, 2, 3, 4]:
    mv = eval_composite(val, th)
    mt = eval_composite(test, th)
    composites.append({
        "threshold": th,
        "validation": mv,
        "test": mt,
    })

print()
print("simple composite rule:")
for c in composites:
    print(
        "score>=", c["threshold"],
        "val_f1=", round(c["validation"]["f1"], 4),
        "test_f1=", round(c["test"]["f1"], 4),
        "test_prec=", round(c["test"]["precision"], 4),
        "test_rec=", round(c["test"]["recall"], 4),
        "test_acc=", round(c["test"]["accuracy"], 4),
    )

report = {
    "runner_dir": str(RUN_DIR),
    "joined_rows": len(joined),
    "validation_rows": len(val),
    "test_rows": len(test),
    "single_feature_results": results,
    "simple_composite_results": composites,
    "notes": [
        "Runtime features excluded as non-scientific timing artifacts.",
        "Thresholds calibrated on validation and evaluated on held-out test.",
        "NIG is JSON-serialized in v1.0.7 but remains source-unaware/diagnostic-only.",
    ],
}

out = OUT / "r1_real_v107_calibrated_nonruntime_eval.json"
out.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
print()
print("Wrote:", out)
