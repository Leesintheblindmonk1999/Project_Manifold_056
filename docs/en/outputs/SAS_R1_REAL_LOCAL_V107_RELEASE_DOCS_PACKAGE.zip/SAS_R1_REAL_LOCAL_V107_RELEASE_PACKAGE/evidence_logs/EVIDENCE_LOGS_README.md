# Evidence logs

These are transcript exports from the local validation conversation. They are included only as review evidence.

Primary evidence chain:

- `Pegado_text(182).txt` - feature variability, NIG conversion error in v1.0.6, original pair sampling issue.
- `Pegado_text(183).txt` - corrected `pair_id`/`source_id` schema and pair join.
- `Pegado_text(184).txt` - corrected scalar probe by `pair_id`, v1.0.7 patch trace, NIG probe.
- `Pegado_text(185).txt` - pair samples confirming Flow/CRE/Negation patterns.
- `Pegado_text(186).txt` - full v1.0.7 NIG check and scalar probe after serialization fix.

For formal release, prefer the local frozen JSON/manifests produced by the repository over these transcript logs.
