# GitHub Upload Guide

## Recommended GitHub release title

`SAS R1 Real Local Structural Evaluation v1.0.7`

## Recommended tag

`r1-real-local-v1.0.7`

## Upload to GitHub

Upload or commit the following documentation files:

- `docs/R1_REAL_RESULTS_v1_0_7.md`
- `docs/LIMITATIONS_AND_CLAIM_BOUNDARY.md`
- `docs/RELEASE_CHECKLIST.md`
- `docs/AUDIT_PROMPT_EXTERNAL_REVIEWERS.md`
- `paper/SAS_kD056_R1_Real_Local_Structural_Evaluation_v1_0_7.md`
- `zenodo/ZENODO_METADATA.json`
- `zenodo/ZENODO_RECORD_DESCRIPTION.md`

Upload or attach the real local freeze artifacts after running `scripts/collect_release_artifacts.ps1`:

- `release_upload/R1_REAL_LOCAL_V107_STRUCTURAL_EVAL_PASS.zip`

## Do not overcommit blindly

Do not upload private/local caches, `.venv`, huge intermediate folders, or unrelated outputs. If dataset licensing is uncertain, upload manifests and hashes first, and keep JSONL data private until reviewed.

## Suggested GitHub release notes

```text
R1 real local v1.0.7 structural evaluation snapshot.

Highlights:
- 4698/4698 real R1 rows processed.
- NIG JSON serialization fixed; 0 conversion_error across the full run.
- Non-runtime structural evaluation completed with validation-calibrated thresholds.
- Best structural composite: Flow + CRE + Negation, score>=1.
- Held-out test: F1=0.8717, precision=0.9952, recall=0.7755, accuracy=0.8859.

Boundary:
- Lexical baseline remains stronger: test AUC=0.9963, F1=0.9968.
- This release confirms interpretable structural signal, not final detector superiority.
```
