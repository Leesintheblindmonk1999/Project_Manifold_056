param(
    [string]$RepoRoot = "C:\Users\conno\Downloads\SAS-V2\SAS-main"
)

$ErrorActionPreference = "Stop"
$FreezeId = "R1_REAL_LOCAL_V107_STRUCTURAL_EVAL_PASS"
$OutRoot = Join-Path $RepoRoot "release_upload"
$OutDir = Join-Path $OutRoot $FreezeId
$ZipPath = Join-Path $OutRoot "$FreezeId.zip"
New-Item -ItemType Directory -Force $OutDir | Out-Null

$Files = @(
    "docs\R1_REAL_RESULTS_v1_0_7.md",
    "outputs\r1_freeze_real_v107\INTEGRITY_MANIFEST_R1_REAL_LOCAL_v107.json",
    "outputs\r1_dataset\manifest.json",
    "outputs\r1_dataset\validation.jsonl",
    "outputs\r1_dataset\test.jsonl",
    "outputs\r1_dataset\rejected_stress_set.jsonl",
    "outputs\r1_baseline\baseline_metrics.json",
    "outputs\r1_results_light_full_real_v107\run_manifest.json",
    "outputs\r1_eval\r1_real_scalar_feature_probe_pairid.json",
    "outputs\r1_eval\r1_real_v107_calibrated_nonruntime_eval.json",
    "outputs\r1_eval\r1_real_v107_composite_ablation.json",
    "outputs\r1_runlogs\32_runner_full_light_real_v107.txt",
    "outputs\r1_runlogs\33_nig_full_v107_check.txt",
    "outputs\r1_runlogs\34_scalar_feature_probe_pairid_real_v107.txt",
    "outputs\r1_runlogs\35_calibrated_eval_nonruntime_v107.txt",
    "outputs\r1_runlogs\36_composite_ablation_v107.txt",
    "outputs\r1_runlogs\37_freeze_real_v107.txt",
    "scripts\r1_module_runner.py",
    "scripts\r1_scalar_feature_probe_pairid_v107.py",
    "scripts\r1_calibrated_eval_nonruntime_v107.py",
    "scripts\r1_composite_ablation_v107.py"
)

$Missing = @()
$Copied = @()
foreach ($Rel in $Files) {
    $Src = Join-Path $RepoRoot $Rel
    if (!(Test-Path $Src)) { $Missing += $Rel; continue }
    $Dst = Join-Path $OutDir $Rel
    New-Item -ItemType Directory -Force (Split-Path $Dst -Parent) | Out-Null
    Copy-Item $Src $Dst -Force
    $Hash = Get-FileHash $Dst -Algorithm SHA256
    $Copied += [PSCustomObject]@{ path = $Rel; bytes = (Get-Item $Dst).Length; sha256 = $Hash.Hash.ToLower() }
}
$Manifest = [PSCustomObject]@{ freeze_id=$FreezeId; created_local=(Get-Date).ToString("o"); repo_root=$RepoRoot; copied_count=$Copied.Count; missing_count=$Missing.Count; copied=$Copied; missing=$Missing; claim_boundary="Structural signal confirmation; not superiority over lexical baseline." }
$ManifestPath = Join-Path $OutDir "LOCAL_UPLOAD_MANIFEST.json"
$Manifest | ConvertTo-Json -Depth 6 | Set-Content $ManifestPath -Encoding UTF8
if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force }
Compress-Archive -Path (Join-Path $OutDir "*") -DestinationPath $ZipPath -Force
$ZipHash = Get-FileHash $ZipPath -Algorithm SHA256
"$($ZipHash.Hash.ToLower())  $(Split-Path $ZipPath -Leaf)" | Set-Content "$ZipPath.sha256.txt" -Encoding UTF8
Write-Host "Output dir: $OutDir"
Write-Host "Zip: $ZipPath"
Write-Host "Zip SHA256: $($ZipHash.Hash.ToLower())"
Write-Host "Copied: $($Copied.Count)"
Write-Host "Missing: $($Missing.Count)"
if ($Missing.Count -gt 0) { Write-Host "Missing files:"; $Missing | ForEach-Object { Write-Host " - $_" } }
