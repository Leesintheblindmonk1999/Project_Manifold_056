# SAS / kD=0.56 - R1 Real Local Structural Evaluation v1.0.7

This package contains the documentation and release materials for the R1 real local structural evaluation snapshot.

**Freeze ID:** `R1_REAL_LOCAL_V107_STRUCTURAL_EVAL_PASS`  
**Runner:** `r1_module_runner_v1.0.7`  
**Integrity manifest SHA-256:** `eb2899292ae72384f9eff8e8fab8e57f09b00ea0962ee822a40fbcdac2574b4c`  
**Prepared UTC:** `2026-06-29T14:58:20.832634+00:00`

## What this ZIP contains

- `paper/` - Zenodo-ready technical paper in Markdown and PDF.
- `docs/` - key technical report, limitations, audit prompts, and release checklist.
- `github/` - GitHub upload guide and release notes.
- `zenodo/` - Zenodo metadata, upload guide, and record description.
- `scripts/` - PowerShell helper to collect the real local artifacts from your Windows repo.
- `evidence_logs/` - copied transcript logs from the validation conversation, when available.

## Core technical closure

The R1 real local v1.0.7 pipeline is a reproducibility snapshot, not a final detector claim.

| Composite | Test F1 | Precision | Recall | Accuracy |
|---|---:|---:|---:|---:|
| Flow + CRE + Negation, score >= 1 | 0.8717 | 0.9952 | 0.7755 | 0.8859 |

Important limitation:

| Baseline | Test AUC | Test F1 |
|---|---:|---:|
| Lexical baseline | 0.9963 | 0.9968 |

Correct claim:

> SAS-light structural modules produce a reproducible, non-runtime, interpretable signal on the R1 real split. They do not outperform the lexical baseline in this release.

## Before uploading the real outputs

Run `scripts/collect_release_artifacts.ps1` from your local repository root. Example:

```powershell
cd C:\Users\conno\Downloads\SAS-V2\SAS-main
powershell -ExecutionPolicy Bypass -File .\scripts\collect_release_artifacts.ps1
```

This documentation package itself does not contain the full real local outputs unless you add them from your machine.
