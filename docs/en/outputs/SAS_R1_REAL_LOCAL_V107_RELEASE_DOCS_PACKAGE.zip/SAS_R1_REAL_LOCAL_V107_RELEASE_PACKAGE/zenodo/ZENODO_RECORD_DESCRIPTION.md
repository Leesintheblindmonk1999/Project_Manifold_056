# Zenodo Record Description

This record archives the R1 real local structural evaluation snapshot for SAS / kD=0.56 v1.0.7.

The release validates an end-to-end real-data structural evaluation pipeline over 4698 paired CLEAN/HALLUCINATION rows, including corrected `pair_id`/`source_id` joins, full light-runner execution, NIG JSON serialization, non-runtime feature evaluation, and composite ablation.

The best non-runtime structural composite, Flow + CRE + Negation with score >= 1, achieved:

- Test F1: 0.8717
- Precision: 0.9952
- Recall: 0.7755
- Accuracy: 0.8859

The release is bounded by an explicit limitation: the lexical baseline remains stronger on this split, with test AUC=0.9963 and test F1=0.9968. Therefore, this snapshot should be cited as evidence of reproducible, interpretable structural signal, not as final detector superiority.

Freeze ID: `R1_REAL_LOCAL_V107_STRUCTURAL_EVAL_PASS`

Integrity manifest SHA-256: `eb2899292ae72384f9eff8e8fab8e57f09b00ea0962ee822a40fbcdac2574b4c`
