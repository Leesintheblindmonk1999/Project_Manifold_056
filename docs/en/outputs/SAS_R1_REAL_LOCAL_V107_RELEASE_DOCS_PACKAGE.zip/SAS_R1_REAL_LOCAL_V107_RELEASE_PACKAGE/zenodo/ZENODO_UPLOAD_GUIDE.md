# Zenodo Upload Guide

## Recommended record type

Publication -> Technical report

Alternative: Dataset / Software, if you decide to upload the full output artifacts as reproducibility material.

## Recommended title

`SAS / kD=0.56 - R1 Real Local Structural Evaluation v1.0.7`

## Recommended creator

- Gonzalo Emir Durante

## Recommended files

Minimum Zenodo upload:

- `paper/SAS_kD056_R1_Real_Local_Structural_Evaluation_v1_0_7.pdf`
- `paper/SAS_kD056_R1_Real_Local_Structural_Evaluation_v1_0_7.md`
- `docs/R1_REAL_RESULTS_v1_0_7.md`
- `docs/LIMITATIONS_AND_CLAIM_BOUNDARY.md`
- `zenodo/ZENODO_METADATA.json`
- `release_upload/R1_REAL_LOCAL_V107_STRUCTURAL_EVAL_PASS.zip` after local collection

## Keywords

SAS; kD=0.56; hallucination detection; structural coherence; AI auditing; reproducibility; Flow coherence; CRE; Negation inversion; NIG.

## Notes

Do not state that SAS outperforms the lexical baseline. State that SAS-light provides non-trivial interpretable structural signal under R1 real v1.0.7.
