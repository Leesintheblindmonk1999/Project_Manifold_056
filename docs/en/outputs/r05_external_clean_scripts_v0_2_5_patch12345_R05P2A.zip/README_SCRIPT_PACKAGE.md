﻿# r05_external_clean_scripts_v0_2_5_patch12345_R05P2A

Frozen script package for SAS / Project Manifold R0.5P-2A.

Track:
- halogen/numerical_falsepresupposition
- prompt_paraphrase / instruction-paraphrase

Base:
- r05_external_clean_scripts_v0_2_5

Local patch state:
- PATCH-1/2/3: prompt preservation for numbers, quantities, letters, output constraints, fallback no-response clause.
- PATCH-4: verifier adaptation for instruction-paraphrase request shape and conditional fallback handling.
- PATCH-5: numeric boundary fix for B-only contamination false positives.
- PATCH-6: tested and reverted; not included.

Boundary:
This package supports external-clean generation and calibration. It is not final production hallucination-detection validation.
