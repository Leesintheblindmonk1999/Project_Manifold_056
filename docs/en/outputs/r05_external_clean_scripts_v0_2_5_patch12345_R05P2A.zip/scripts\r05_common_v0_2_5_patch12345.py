#!/usr/bin/env python3
from __future__ import annotations
import difflib, hashlib, json, math, os, platform, re, subprocess, sys
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

SCRIPT_VERSION = "0.2.5"

MOJIBAKE_PATTERNS = [
    "ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢", "ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡", "ÃƒÆ’Ã†â€™", "ÃƒÆ’Ã¢â‚¬Å¡", "ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â‚¬Å¾Ã‚Â¢", "ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã¢â‚¬Å“", "ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¯Ã‚Â¿Ã‚Â½", "ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬", "ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œ", "ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â", "ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¦", "ÃƒÆ’Ã‚Â¯Ãƒâ€šÃ‚Â¿Ãƒâ€šÃ‚Â½", "ÃƒÂ¯Ã‚Â¿Ã‚Â½"
]

def mojibake_hits(text: str) -> List[str]:
    return sorted({p for p in MOJIBAKE_PATTERNS if p in text})

def has_mojibake_artifact(text: str) -> bool:
    return bool(mojibake_hits(text))

STOPWORDS = {
    "the","this","that","there","in","on","at","by","to","for","of","and","or","a","an",
    "it","its","they","them","their","we","our","you","your","he","she","his","her",
    "but","not","no","yes","so","if","as","was","were","is","are","be","been","have",
    "has","had","do","does","did","will","would","could","should","may","might","also",
    "then","than","when","where","which","who","how","what","while","during","after",
    "before","between","because","since","results","methods","conclusions","background",
    "introduction","however","therefore","furthermore","moreover","additionally","first",
    "second","third","finally","notably","specifically","overall","importantly",
    "significantly","study","research","analysis","paper","report","data","table",
    "figure","section","abstract","source","text","output","question","answer",
    "historian","historians","scholar","scholars","researcher","researchers",
    "official","officials","expert","experts","critic","critics","authority","authorities",
    "witness","witnesses","supporter","supporters","opponent","opponents",
    "leader","leaders","observer","observers","analyst","analysts","commentator",
    "commentators","writer","writers","author","authors","scientist","scientists",
    "professor","professors","lawyer","lawyers","judge","judges","doctor","doctors",
    "people","person","group","groups","team","teams","committee","committees",
    "january","february","march","april","may","june","july","august",
    "september","october","november","december",
    "jan","feb","mar","apr","jun","jul","aug","sep","sept","oct","nov","dec",
    # Prompt/task framing words. These are not named entities.
    "tell","describe","discuss","explain","summarize","generate","provide","list",
    "compose","answer","find","write","make","analyze","request","prompt","separate","separating","separator","separators","item","items","additional","information","respond","response","separate","separating","separator","separators","item","items","additional","information","respond","response",
    "meeting","famous","bio","biography","reference","references","claim",
    "dataset","textual","record","records","placeholder","potential","interaction",
    "encounter","parameters","sure",
    # Generic capitalized fragments often extracted from longer B-only phrases.
    # These are too weak to be treated as standalone named-entity contamination.
    "trade","board","company","society","university","institute","church",
    "state","city","court","house","school","college","press","party",
    "committee","association","council","center","centre","bank","group",
    "office","department","ministry","government","national","international",
    "royal","academy","foundation","museum","corporation","league","union",
    "club","organization","organisation"
}

B_ONLY_WEAK_SINGLE_TOKEN_FRAGMENTS = {
    "trade","board","company","society","university","institute","church",
    "state","city","court","house","school","college","press","party",
    "committee","association","council","center","centre","bank","group",
    "office","department","ministry","government","national","international",
    "royal","academy","foundation","museum","corporation","league","union",
    "club","organization","organisation"
}
KNOWN_ALIASES = {
    "united states": ["usa","u.s.","u.s.a.","america","us"],
    "united kingdom": ["uk","u.k.","great britain","britain"],
    "european union": ["eu"],
    "world health organization": ["who"],
    "united nations": ["un"],
    "artificial intelligence": ["ai"],
    "machine learning": ["ml"],
    "large language model": ["llm"],
    "large language models": ["llms"],
    "natural language processing": ["nlp"],
}
ENTITY_PATTERN = r"\b(?:[A-ZÃƒÆ’Ã¢â€šÂ¬-Ãƒâ€¦Ã‚Â¸][a-zA-ZÃƒÆ’Ã¢â€šÂ¬-ÃƒÆ’Ã‚Â¿0-9&.\-]+(?:\s+[A-ZÃƒÆ’Ã¢â€šÂ¬-Ãƒâ€¦Ã‚Â¸][a-zA-ZÃƒÆ’Ã¢â€šÂ¬-ÃƒÆ’Ã‚Â¿0-9&.\-]+){0,5})\b"

PROMPTLIKE_PATTERNS = [
    r"^\s*(write|tell|discuss|describe|explain|summarize|generate|provide|list|compose|answer)\b",
    r"(?m)^\s*q\s*:",
    r"(?m)^\s*a\s*:",
    r"(?m)^\s*question\s*:",
    r"(?m)^\s*answer\s*:",
    r"\b(first,\s*)?respond with yes or no\b",
    r"\bquestion\s*:",
    r"\banswer\s*:",
    r"\bcurrent flight information\b",
    r"\bis there\b.*\?",
    r"\bis\s+this\b.{0,180}\b(consistent|correct|valid)\b.{0,180}\?",
    r"\bcan you\b.*\?",
    r"\bwhich of\b",
    r"\bchoose the\b",
    r"\baccording to\b.*\?",
]

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def sha256_text(text: Optional[str]) -> Optional[str]:
    if text is None:
        return None
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace").strip()

def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.strip() + "\n", encoding="utf-8")

def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(obj, ensure_ascii=False, default=str) + "\n")

def write_json(path: Path, obj: Dict[str, Any]) -> None:
    """Write JSON as UTF-8 without BOM, with stable indentation and newline.

    This avoids Windows PowerShell/Out-File UTF-8 BOM ambiguity in generated
    artifacts and keeps manifests friendlier to strict JSON tooling.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")

def read_json(path: Path) -> Dict[str, Any]:
    """Read JSON while tolerating UTF-8 BOM from external/manual files."""
    return json.loads(path.read_text(encoding="utf-8-sig"))

def token_words(text: str) -> List[str]:
    return re.findall(r"[A-Za-zÃƒÆ’Ã¢â€šÂ¬-ÃƒÆ’Ã‚Â¿0-9_]+", text.lower())

def estimate_tokens(text: str) -> int:
    return max(1, int(len(text) / 4) + 1)

def dynamic_max_tokens(source: str, multiplier: float = 1.8, minimum: int = 24, maximum: int = 420) -> int:
    return max(minimum, min(maximum, int(estimate_tokens(source) * multiplier) + 16))

def lexical_jaccard(a: str, b: str) -> float:
    sa, sb = set(token_words(a)), set(token_words(b))
    if not sa and not sb: return 1.0
    if not sa or not sb: return 0.0
    return len(sa & sb) / len(sa | sb)

def sequence_ratio(a: str, b: str) -> float:
    return difflib.SequenceMatcher(None, a.lower(), b.lower()).ratio()

def extract_numbers_dates(text: str) -> List[str]:
    patterns = [
        r"\b\d{1,6}(?:[.,]\d+)?%?\b",
        r"\b\d{4}-\d{2}-\d{2}\b",
        r"\b\d{1,2}/\d{1,2}/\d{2,4}\b",
        r"\b\d{1,2}(?:st|nd|rd|th)?\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?\s+\d{4}\b",
        r"\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?\s+\d{1,2}(?:st|nd|rd|th)?,?\s+\d{4}\b",
    ]
    out = []
    for p in patterns:
        out.extend(re.findall(p, text, flags=re.IGNORECASE))
    return sorted(set(out))

_NUM_WORDS_0_20 = {
    0:"zero", 1:"one", 2:"two", 3:"three", 4:"four", 5:"five", 6:"six", 7:"seven", 8:"eight", 9:"nine", 10:"ten",
    11:"eleven", 12:"twelve", 13:"thirteen", 14:"fourteen", 15:"fifteen", 16:"sixteen", 17:"seventeen", 18:"eighteen", 19:"nineteen", 20:"twenty"
}
_NUM_TENS = {30:"thirty", 40:"forty", 50:"fifty", 60:"sixty", 70:"seventy", 80:"eighty", 90:"ninety", 100:"one hundred"}
_MONTHS = {
    "jan":1,"january":1,"feb":2,"february":2,"mar":3,"march":3,"apr":4,"april":4,"may":5,"jun":6,"june":6,
    "jul":7,"july":7,"aug":8,"august":8,"sep":9,"sept":9,"september":9,"oct":10,"october":10,"nov":11,"november":11,"dec":12,"december":12
}

def _norm_invariant_text(text: str) -> str:
    return re.sub(r"\s+", " ", text.lower().replace(",", "").strip())

def _number_word_equivalents(value: str) -> List[str]:
    v = value.replace(",", "").strip()
    if not re.fullmatch(r"\d{1,3}", v):
        return []
    n = int(v)
    out: List[str] = []
    if n in _NUM_WORDS_0_20:
        out.append(_NUM_WORDS_0_20[n])
    if n in _NUM_TENS:
        out.append(_NUM_TENS[n])
    if 21 <= n <= 99 and n not in _NUM_TENS:
        tens = (n // 10) * 10
        ones = n % 10
        if tens in _NUM_TENS and ones in _NUM_WORDS_0_20:
            out.append(f"{_NUM_TENS[tens]}-{_NUM_WORDS_0_20[ones]}")
            out.append(f"{_NUM_TENS[tens]} {_NUM_WORDS_0_20[ones]}")
    return out

def _date_equivalents(value: str) -> List[str]:
    s = value.strip()
    out: List[str] = []
    m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", s)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        month_names = [k for k, v in _MONTHS.items() if v == mo and len(k) > 3]
        if month_names:
            month = month_names[0]
            out.extend([f"{month} {d} {y}", f"{month} {d}, {y}", f"{d} {month} {y}"])
        return out
    m = re.fullmatch(r"([A-Za-z]+)\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})", s, flags=re.I)
    if m:
        mo = _MONTHS.get(m.group(1).lower().rstrip('.'))
        if mo:
            d, y = int(m.group(2)), int(m.group(3))
            out.append(f"{y}-{mo:02d}-{d:02d}")
            out.append(f"{d}/{mo}/{y}")
            out.append(f"{mo}/{d}/{y}")
        return out
    m = re.fullmatch(r"(\d{1,2})(?:st|nd|rd|th)?\s+([A-Za-z]+)\.?\s+(\d{4})", s, flags=re.I)
    if m:
        mo = _MONTHS.get(m.group(2).lower().rstrip('.'))
        if mo:
            d, y = int(m.group(1)), int(m.group(3))
            out.append(f"{y}-{mo:02d}-{d:02d}")
            out.append(f"{d}/{mo}/{y}")
            out.append(f"{mo}/{d}/{y}")
    return out

def invariant_equivalents(value: str) -> List[str]:
    eq = [value]
    eq.extend(_number_word_equivalents(value))
    eq.extend(_date_equivalents(value))
    seen = []
    for x in eq:
        nx = _norm_invariant_text(x)
        if nx and nx not in seen:
            seen.append(nx)
    return seen

def invariant_present(value: str, text: str) -> bool:
    t = _norm_invariant_text(text)
    return any(eq in t for eq in invariant_equivalents(value))

def numbers_preserved(a: str, c: str) -> Tuple[bool, List[str]]:
    missing = []
    for num in extract_numbers_dates(a):
        if not invariant_present(num, c):
            missing.append(num)
    return len(missing) == 0, missing

def _sentence_chunks(text: str) -> List[str]:
    # Prevent entity regex from crossing sentence boundaries, e.g. "Assam. He".
    parts = re.split(r"(?<=[.!?])\s+(?=[A-ZÃƒÆ’Ã¢â€šÂ¬-Ãƒâ€¦Ã‚Â¸])", text)
    return [p for p in parts if p.strip()]

def _clean_entity(value: str) -> str:
    value = value.strip().strip(" \t\r\n.,;:!?()[]{}\"\'ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œÃƒÂ¢Ã¢â€šÂ¬Ã‚ÂÃƒÂ¢Ã¢â€šÂ¬Ã‹Å“ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢")
    value = re.sub(r"\s+", " ", value)
    parts = value.split()
    while parts and parts[0].lower().strip(".") in STOPWORDS:
        parts = parts[1:]
    while parts and parts[-1].lower().strip(".") in STOPWORDS:
        parts = parts[:-1]
    return " ".join(parts)

def _is_valid_entity(value: str) -> bool:
    v = _clean_entity(value)
    if not v or len(v) <= 2:
        return False
    low = v.lower().strip(". ")
    if low in STOPWORDS:
        return False
    if all(part.lower().strip(".") in STOPWORDS for part in v.split()):
        return False
    return True

def extract_entities(text: str) -> List[str]:
    ents = set()
    for chunk in _sentence_chunks(text):
        for m in re.finditer(ENTITY_PATTERN, chunk):
            value = _clean_entity(m.group(0))
            if not _is_valid_entity(value):
                continue
            ents.add(value)
        for m in re.finditer(r"\b[A-ZÃƒÆ’Ã¢â€šÂ¬-Ãƒâ€¦Ã‚Â¸]{2,}(?:[-_][A-Z0-9]+)*\b", chunk):
            v = _clean_entity(m.group(0))
            if _is_valid_entity(v):
                ents.add(v)
    return sorted(ents)

def recall_with_aliases(required: Sequence[str], candidate_text: str) -> float:
    if not required:
        return 1.0
    lower = candidate_text.lower()
    found = 0
    for x in required:
        xl = x.lower()
        if xl in lower:
            found += 1
            continue
        matched = False
        for canonical, aliases in KNOWN_ALIASES.items():
            if xl == canonical and any(alias in lower for alias in aliases):
                matched = True
            if xl in aliases and canonical in lower:
                matched = True
        if matched:
            found += 1
    return found / len(required)

def _compact_entity_text(value: str) -> str:
    """Lowercase entity text and remove punctuation/spacing for overlap checks.

    This catches apostrophe/spacing variants such as dEmery vs d'Emery without
    rewriting the source text or weakening exact output preservation rules.
    """
    return "".join(token_words(value))

def _is_weak_single_token_b_entity(entity: str) -> bool:
    toks = token_words(entity)
    if len(toks) != 1:
        return False
    tok = toks[0]
    return tok in STOPWORDS or tok in B_ONLY_WEAK_SINGLE_TOKEN_FRAGMENTS or len(tok) <= 2

def _entity_covered_by_a_entity(b_entity: str, a_entities: Sequence[str], a_text: str = "") -> bool:
    """Return True when a B entity is already contained in A.

    Examples:
    - B extracts "Wildsmith" while A has "Brian Wildsmith".
    - B extracts "Emery" from d'Emery while A has "dEmery".

    These are not B-only contamination; they are substrings or orthographic
    variants of source entities.
    """
    b_low = b_entity.lower().strip()
    if not b_low:
        return True
    b_tokens = set(token_words(b_low))
    b_compact = _compact_entity_text(b_low)

    if _is_weak_single_token_b_entity(b_low):
        return True

    for a_ent in a_entities:
        a_low = a_ent.lower().strip()
        if b_low == a_low:
            return True
        if b_low in a_low or a_low in b_low:
            return True
        a_tokens = set(token_words(a_low))
        if b_tokens and b_tokens.issubset(a_tokens):
            return True
        a_compact = _compact_entity_text(a_low)
        if b_compact and (b_compact in a_compact or a_compact in b_compact):
            return True

    # Source text fallback catches cases where entity extraction drops lowercase
    # particles or apostrophe-bound fragments, e.g. dEmery/d'Emery.
    a_compact_text = _compact_entity_text(a_text.lower())
    if b_compact and b_compact in a_compact_text:
        return True
    for tok in b_tokens:
        if len(tok) > 3:
            for a_tok in token_words(a_text.lower()):
                if a_tok.endswith(tok):
                    return True
    return False

def b_only_invariants(a: str, b: str) -> Dict[str, List[str]]:
    nums_a, nums_b = set(extract_numbers_dates(a)), set(extract_numbers_dates(b))
    a_entities = extract_entities(a)
    ents_b = {x.lower(): x for x in extract_entities(b)}
    return {
        "numbers_dates": sorted(nums_b - nums_a),
        "entities": sorted(
            v for k, v in ents_b.items()
            if not _entity_covered_by_a_entity(v, a_entities, a_text=a)
        ),
    }

def _entity_present_as_boundary(entity: str, text: str) -> bool:
    toks = token_words(entity)
    if not toks:
        return False
    # Treat apostrophes, curly apostrophes, backticks, and hyphens as entity-join
    # characters for boundary purposes. This prevents false hits such as B-only
    # "Emery" matching C source-preserved "d'Emery" or "dÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢Emery", while still
    # flagging a true standalone "Emery".
    join_chars = r"A-Za-zÃƒÆ’Ã¢â€šÂ¬-ÃƒÆ’Ã‚Â¿0-9_'ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢`-"
    if len(toks) == 1:
        pattern = r"(?<![" + join_chars + r"])(" + re.escape(toks[0]) + r")(?![" + join_chars + r"])"
        return re.search(pattern, text.lower()) is not None
    norm_text = " ".join(token_words(text))
    norm_entity = " ".join(toks)
    pattern = r"(?<![A-Za-zÃƒÆ’Ã¢â€šÂ¬-ÃƒÆ’Ã‚Â¿0-9_])" + re.escape(norm_entity) + r"(?![A-Za-zÃƒÆ’Ã¢â€šÂ¬-ÃƒÆ’Ã‚Â¿0-9_])"
    return re.search(pattern, norm_text) is not None

def _number_invariant_present_as_boundary(x: str, text: str) -> bool:
    """Return True only when a numeric/date invariant appears as its own token.

    This avoids false positives such as B-only "4" matching C's legitimate "44".
    """
    x_norm = str(x).strip()
    if not x_norm:
        return False
    if re.fullmatch(r"\d+", x_norm):
        return re.search(r"(?<!\d)" + re.escape(x_norm) + r"(?!\d)", text) is not None
    return invariant_present(x_norm, text)
def contamination_hits(c: str, b_only: Dict[str, List[str]]) -> Dict[str, List[str]]:
    return {
        "numbers_dates": [x for x in b_only.get("numbers_dates", []) if _number_invariant_present_as_boundary(x, c)],
        "entities": [x for x in b_only.get("entities", []) if _entity_present_as_boundary(x, c)],
    }

def source_category_from_rel(rel_path: str) -> str:
    parts = rel_path.replace("\\", "/").split("/")
    return "/".join(parts[:2]) if len(parts) >= 2 else (parts[0] if parts else "")

def category_matches(category: str, patterns: Sequence[str]) -> bool:
    return any(category == p or category.startswith(p.rstrip("/") + "/") or category.startswith(p) for p in patterns)

def is_promptlike_source(text: str) -> bool:
    lower = text.lower().strip()
    return any(re.search(p, lower, flags=re.I | re.S) for p in PROMPTLIKE_PATTERNS)

def final_yes_no(text: str) -> Optional[str]:
    lines = [ln.strip() for ln in text.strip().splitlines() if ln.strip()]
    candidates = []
    if lines:
        candidates.append(lines[-1])
    candidates.append(text[-260:])
    for frag in candidates:
        m = re.search(r"\b(yes|no)\b", frag, flags=re.I)
        if m:
            return m.group(1).lower()
    return None

def answer_polarity_changed(a: str, c: str) -> bool:
    ay, cy = final_yes_no(a), final_yes_no(c)
    return bool(ay in {"yes", "no"} and cy in {"yes", "no"} and ay != cy)


PROMPT_PARAPHRASE_REQUEST_PATTERNS = [
    r"^\s*(tell|describe|discuss|explain|summarize|provide|give|show|write|list|find|generate|produce)\b",
    r"^\s*(can|could|would)\s+you\b",
    r"^\s*what\s+(?:can|could|do)\b.*\?",
]
PROMPT_PARAPHRASE_META_PATTERNS = [
    r"\bdataset\s+(?:text|reference|record)\b",
    r"\btextual\s+reference\b",
    r"\bplaceholder\b",
    r"\bencounter\s+parameters\b",
    r"\binteraction\s+record\b",
    r"\bwithout\s+substantive\s+details\b",
]

PROMPT_BOUNDARY_LEAKAGE_PATTERNS = [
    r"(?im)^\s*(human|assistant|user|system)\s*:",
    r"(?i)\.\.\s*(human|assistant|user|system)\s*:",
    r"(?i)\b(re)?tell me detailed the details\b",
]

REJECTION_REASON_TAXONOMY = {
    "empty_output": "candidate_empty",
    "prompt_paraphrase_not_request_like": "track_shape_violation",
    "prompt_paraphrase_meta_description": "track_shape_violation",
    "prompt_boundary_leakage": "malformed_generation",
    "candidate_mojibake_or_encoding_artifact": "malformed_generation",
    "refusal_or_meta_output": "refusal_or_meta",
    "external_clean_too_short": "length_violation",
    "external_clean_too_long": "length_violation",
    "numbers_or_dates_changed": "invariant_violation",
    "entity_recall_below_threshold": "invariant_violation",
    "external_clean_too_close_to_self": "lexical_distance_violation",
    "external_clean_too_far": "lexical_distance_violation",
    "answer_polarity_changed": "invariant_violation",
    "b_only_contamination": "contamination",
    "semantic_truncation_risk": "semantic_observability",
    "semantic_similarity_unavailable": "semantic_observability",
    "semantic_similarity_below_threshold": "semantic_similarity_failure",
}

def taxonomize_reasons(reasons: Sequence[str]) -> Dict[str, int]:
    out: Dict[str, int] = {}
    for reason in reasons:
        bucket = REJECTION_REASON_TAXONOMY.get(reason, "other")
        out[bucket] = out.get(bucket, 0) + 1
    return out

def prompt_boundary_leakage_hits(text: str) -> List[str]:
    return [p for p in PROMPT_BOUNDARY_LEAKAGE_PATTERNS if re.search(p, text, flags=re.I | re.S | re.M)]

def is_request_like(text: str) -> bool:
    stripped = text.strip()
    return any(re.search(p, stripped, flags=re.I | re.S) for p in PROMPT_PARAPHRASE_REQUEST_PATTERNS)

def prompt_paraphrase_meta_hits(text: str) -> List[str]:
    return [p for p in PROMPT_PARAPHRASE_META_PATTERNS if re.search(p, text, flags=re.I | re.S)]

def source_eligibility_reason(
    text: str,
    rel_path: str,
    *,
    min_chars: int = 80,
    min_words: int = 8,
    skip_promptlike: bool = True,
    skip_mojibake: bool = False,
    include_categories: Sequence[str] = (),
    exclude_categories: Sequence[str] = (),
) -> Optional[str]:
    category = source_category_from_rel(rel_path)
    if include_categories and not category_matches(category, include_categories):
        return "category_not_included"
    if exclude_categories and category_matches(category, exclude_categories):
        return "category_excluded"
    # Check encoding corruption before promptlike/length filters so the
    # preflight breakdown preserves the most diagnostically important reason.
    if skip_mojibake and has_mojibake_artifact(text):
        return "mojibake_or_encoding_artifact"
    if skip_promptlike and is_promptlike_source(text):
        return "promptlike_or_task_source_skipped"
    if len(text.strip()) < min_chars or len(token_words(text)) < min_words:
        return "source_too_short_or_underspecified"
    return None

class SemanticModel:
    def __init__(self, model_name: str):
        from sentence_transformers import SentenceTransformer  # type: ignore
        import numpy as np  # type: ignore
        self.np = np
        self.model_name = model_name
        self.model = SentenceTransformer(model_name)
        self.max_seq_length = int(getattr(self.model, "max_seq_length", 256) or 256)
    def token_count(self, text: str) -> int:
        tok = getattr(self.model, "tokenizer", None)
        if tok is None:
            return estimate_tokens(text)
        try:
            return len(tok.encode(text, add_special_tokens=True))
        except Exception:
            return estimate_tokens(text)
    def similarity(self, a: str, b: str) -> Tuple[float, List[str]]:
        warnings = []
        ta, tb = self.token_count(a), self.token_count(b)
        if ta > self.max_seq_length:
            warnings.append(f"source_tokens_exceed_model_window:{ta}>{self.max_seq_length}")
        if tb > self.max_seq_length:
            warnings.append(f"candidate_tokens_exceed_model_window:{tb}>{self.max_seq_length}")
        emb = self.model.encode([a, b], normalize_embeddings=True)
        return float(self.np.dot(emb[0], emb[1])), warnings

@dataclass
class CandidateCheck:
    accepted: bool
    reasons: List[str]
    warnings: List[str]
    rejection_taxonomy: Dict[str, int]
    length_ratio: float
    lexical_jaccard: float
    sequence_ratio: float
    semantic_similarity: Optional[float]
    semantic_warnings: List[str]
    numbers_dates_preserved: bool
    missing_numbers_dates: List[str]
    entity_recall: float
    contamination_hits: Dict[str, List[str]]

def check_candidate(
    a: str,
    c: str,
    b: Optional[str],
    *,
    min_len_ratio: float,
    max_len_ratio: float,
    min_entity_recall: float,
    min_lexical: float,
    max_lexical: float,
    semantic_model: Optional[SemanticModel] = None,
    min_semantic_warn: float = 0.75,
    allow_semantic_truncation: bool = False,
    reject_semantic_truncation: bool = False,
    track: str = "inert_dataset",
) -> CandidateCheck:
    reasons = []
    warnings = []
    if not c.strip():
        reasons.append("empty_output")
    if has_mojibake_artifact(c):
        reasons.append("candidate_mojibake_or_encoding_artifact")
        warnings.extend(["candidate_mojibake_hit:" + h for h in mojibake_hits(c)])
    leakage_hits = prompt_boundary_leakage_hits(c)
    if leakage_hits:
        reasons.append("prompt_boundary_leakage")
        warnings.extend(["prompt_boundary_leakage_hit:" + h for h in leakage_hits])
    if track == "prompt_paraphrase":
        if not is_request_like(c):
            reasons.append("prompt_paraphrase_not_request_like")
        meta_hits = prompt_paraphrase_meta_hits(c)
        if meta_hits:
            reasons.append("prompt_paraphrase_meta_description")
            warnings.extend(["prompt_paraphrase_meta_hit:" + h for h in meta_hits])
    hard_refusal_patterns = [
        ("i_cannot", r"\bi cannot\b"),
        ("i_cant", r"\bi can'?t\b"),
        ("unable_to", r"\bunable to\b"),
        ("as_an_ai", r"\bas an ai\b"),
        ("cannot_generate", r"\bcannot generate\b"),
        ("cannot_provide", r"\bcannot provide\b"),
    ]
    soft_meta_patterns = [
        ("do_not_have_confirmation", r"\bdo not have\b.*\bconfirmation\b"),
        ("unverified_claim", r"\bunverified claim\b"),
    ]
    hard_refusal_hit = any(re.search(p, c, flags=re.I | re.S) for _, p in hard_refusal_patterns)
    conditional_fallback_preserved = (
        track == "prompt_paraphrase"
        and re.search(r"\bno response\b", a, flags=re.I)
        and re.search(r"\bno response\b", c, flags=re.I)
        and re.search(r"\bif\b.{0,120}\b(?:unable to|cannot|can't)\b.{0,120}\brespond\b.{0,80}\bno response\b", c, flags=re.I | re.S)
    )
    if hard_refusal_hit and not conditional_fallback_preserved:
        reasons.append("refusal_or_meta_output")
    elif hard_refusal_hit and conditional_fallback_preserved:
        warnings.append("hard_refusal_language_preserved_as_conditional_fallback")
    for name, pat in soft_meta_patterns:
        if re.search(pat, c, flags=re.I | re.S):
            if re.search(pat, a, flags=re.I | re.S):
                warnings.append(f"soft_meta_or_uncertainty_language_preserved:{name}")
            else:
                warnings.append(f"soft_meta_or_uncertainty_language_generated:{name}")
    len_ratio = len(c) / max(1, len(a))
    if len_ratio < min_len_ratio:
        reasons.append("external_clean_too_short")
    if len_ratio > max_len_ratio:
        reasons.append("external_clean_too_long")
    nums_ok, missing_nums = numbers_preserved(a, c)
    if not nums_ok:
        reasons.append("numbers_or_dates_changed")
    ent_recall = recall_with_aliases(extract_entities(a), c)
    if ent_recall < min_entity_recall:
        reasons.append("entity_recall_below_threshold")
    jac = lexical_jaccard(a, c)
    if jac > max_lexical:
        reasons.append("external_clean_too_close_to_self")
    if jac < min_lexical:
        reasons.append("external_clean_too_far")
    seq = sequence_ratio(a, c)
    if answer_polarity_changed(a, c):
        reasons.append("answer_polarity_changed")
    hits = {"numbers_dates": [], "entities": []}
    if b:
        hits = contamination_hits(c, b_only_invariants(a, b))
        if hits["numbers_dates"] or hits["entities"]:
            reasons.append("b_only_contamination")
    sem = None
    sem_warns = []
    if semantic_model:
        try:
            sem, sem_warns = semantic_model.similarity(a, c)
            if sem_warns:
                warnings.extend(sem_warns)
                if reject_semantic_truncation and not allow_semantic_truncation:
                    reasons.append("semantic_truncation_risk")
            if sem < min_semantic_warn:
                warnings.append(f"semantic_similarity_below_warning_threshold:{sem:.6f}")
        except Exception as exc:
            warnings.append(f"semantic_similarity_error:{exc}")
    return CandidateCheck(
        accepted=not reasons,
        reasons=reasons,
        warnings=warnings,
        rejection_taxonomy=taxonomize_reasons(reasons),
        length_ratio=round(len_ratio, 6),
        lexical_jaccard=round(jac, 6),
        sequence_ratio=round(seq, 6),
        semantic_similarity=round(sem, 6) if sem is not None else None,
        semantic_warnings=sem_warns,
        numbers_dates_preserved=nums_ok,
        missing_numbers_dates=missing_nums,
        entity_recall=round(ent_recall, 6),
        contamination_hits=hits,
    )

def rel_c_path(a_path: Path, corpus_dir: Path, out_dir: Path, a_suffix: str, c_suffix: str) -> Path:
    rel = a_path.relative_to(corpus_dir)
    return out_dir / rel.parent / (rel.name[: -len(a_suffix)] + c_suffix)

def b_path_for_a(a_path: Path, a_suffix: str, b_suffix: str) -> Path:
    return a_path.with_name(a_path.name[: -len(a_suffix)] + b_suffix)

def environment_snapshot() -> Dict[str, Any]:
    pkgs = {}
    for name in ["anthropic", "openai", "sentence-transformers", "numpy", "torch", "transformers"]:
        try:
            import importlib.metadata as md
            pkgs[name] = md.version(name)
        except Exception:
            pkgs[name] = None
    return {"python": sys.version, "platform": platform.platform(), "packages": pkgs}


def sanitize_args_for_manifest(args: Any) -> Dict[str, Any]:
    """Return argparse values without leaking absolute local paths into publishable manifests."""
    raw = vars(args) if hasattr(args, "__dict__") else dict(args)
    out: Dict[str, Any] = {}
    path_like_keys = {"corpus_dir", "out_dir", "external_dir", "manifest_in", "report_out"}
    for key, value in raw.items():
        if key in path_like_keys and value is not None:
            try:
                out[key] = Path(value).name
            except Exception:
                out[key] = str(value).replace("\\", "/").split("/")[-1]
        elif isinstance(value, Path):
            out[key] = value.name
        elif isinstance(value, list):
            out[key] = [v.name if isinstance(v, Path) else v for v in value]
        else:
            out[key] = value
    return out


def summarize_generation_records(records: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    """Summarize retry and attempt observability for generation manifests."""
    total = len(records)
    attempted = [r for r in records if r.get("status") in {"accepted", "rejected"}]
    accepted = [r for r in records if r.get("status") == "accepted"]
    rejected = [r for r in records if r.get("status") == "rejected"]

    first_attempt_accepted = 0
    retry_attempted = 0
    retry_accepted = 0
    retry_failed = 0
    accepted_on_attempt: Dict[str, int] = {}
    temperature_counts: Dict[str, int] = {}
    error_attempts = 0
    rejection_taxonomy_counts: Dict[str, int] = {}
    reason_counts: Dict[str, int] = {}

    for r in attempted:
        attempts = r.get("attempts") or []
        if len(attempts) > 1:
            retry_attempted += 1
        if any("error" in a for a in attempts):
            error_attempts += sum(1 for a in attempts if "error" in a)

        accepted_idx = None
        for idx, a in enumerate(attempts, 1):
            temp = a.get("temperature")
            if temp is not None:
                key = str(temp)
                temperature_counts[key] = temperature_counts.get(key, 0) + 1
            check = a.get("check") or {}
            if check.get("accepted") is True and accepted_idx is None:
                accepted_idx = idx

        if r.get("status") == "accepted" and accepted_idx is not None:
            accepted_on_attempt[str(accepted_idx)] = accepted_on_attempt.get(str(accepted_idx), 0) + 1
            if accepted_idx == 1:
                first_attempt_accepted += 1
            elif accepted_idx > 1:
                retry_accepted += 1
        elif r.get("status") == "rejected" and len(attempts) > 1:
            retry_failed += 1

        if r.get("status") == "rejected":
            final_checks = [a.get("check") for a in attempts if isinstance(a.get("check"), dict)]
            if final_checks:
                reasons = final_checks[-1].get("reasons") or []
                for reason in reasons:
                    reason_counts[reason] = reason_counts.get(reason, 0) + 1
                for bucket, count in taxonomize_reasons(reasons).items():
                    rejection_taxonomy_counts[bucket] = rejection_taxonomy_counts.get(bucket, 0) + count

    selected_count = len([r for r in records if r.get("status") != "selected_preflight_only"]) or total
    generation_count = max(1, len(attempted))
    return {
        "records_total": total,
        "generation_attempted_records": len(attempted),
        "accepted_records": len(accepted),
        "rejected_records": len(rejected),
        "first_attempt_accepted": first_attempt_accepted,
        "retry_attempted_records": retry_attempted,
        "retry_accepted_records": retry_accepted,
        "retry_failed_records": retry_failed,
        "first_attempt_acceptance_rate": round(first_attempt_accepted / generation_count, 6),
        "with_retry_acceptance_rate": round(len(accepted) / generation_count, 6),
        "accepted_on_attempt": accepted_on_attempt,
        "temperature_attempt_counts": temperature_counts,
        "error_attempts": error_attempts,
        "rejected_reason_counts_final_attempt": reason_counts,
        "rejected_taxonomy_counts_final_attempt": rejection_taxonomy_counts,
    }
