# R05 PROGRESS LOG — R0 TO R0.5P-1 v0.2.3

## R0 baseline

R0 was an infrastructure/baseline stability audit under `clean_strategy=self`. It established that the pipeline could ingest complete A/B hallucination pairs, generate stratified samples, and produce stable baseline detector behavior. R0 was not a final production validation.

Key R0 facts:

- complete A/B pairs: 152,525
- clean-self records: 305,050
- 12k run: minimal module F1 0.9993, full F1 1.0000, FP 0, FN 2

## R0-bis

R0-bis tested nonlinear dependence and redundancy among baseline modules using Pearson, Spearman, Distance Correlation, and normalized Mutual Information.

Key R0-bis conclusion:

- correlated modules should be grouped as evidence, not counted as independent votes;
- Pearson alone is insufficient;
- R0.5 external-clean robustness was justified before R1.

## R0.5 design shift

Initial assumption: `halogen/historical_events` might be factual prose.

Corpus inspection showed this was wrong. The actual A_clean surface form is prompt-like:

```text
Tell me about the famous meeting between X and Y.
```

Decision:

```text
R0.5P-1 Historical Query Paraphrase
```

The objective is to paraphrase the request itself, not answer it.

## Version progression

### v0.2.0

- Cross-audit hardening from Claude/Gemini/DeepSeek.
- Zero-accepted guard confirmed operational.
- R0.5P-1 smoke-3: 0/3 accepted.
- Diagnosis: model produced meta-descriptions instead of equivalent requests.

### v0.2.1

- Added `--track prompt_paraphrase`.
- Added request-preserving prompt and verifier logic.
- smoke-3: 3/3 accepted.
- alpha-20: 20/20 accepted.
- beta-100: 99/100 accepted.
- Only beta-100 rejection: encoding/mojibake mutation.

### v0.2.2

- Added mojibake/encoding source exclusion.
- beta-250:
  - raw A: 21,008
  - eligible: 18,964
  - skipped: 2,044
  - mojibake skipped: 1,232
  - short/underspecified skipped: 812
  - generation accepted: 248/250
  - generation rejected: 2/250
  - verification accepted: 248/248 generated C

Manual inspection of the two rejected candidates showed they were valid prompt paraphrases.

### v0.2.3

- Verifier-only patch for false positive `b_only_contamination`.
- Fixes generic fragment `Trade` matching `(trader)`.
- Fixes apostrophe/substring variant `dEmery` vs `d'Emery` causing `Emery` contamination.
- Maintains strict entity preservation and mojibake exclusion.

## Current methodological status

R0.5P-1 is stable enough for beta-500, pending repeat validation with v0.2.3.

Do not claim final R1 validation yet. Correct claim:

```text
R0.5P-1 prompt paraphrase calibration is stable through beta-250 with remaining failures traced to verifier false positives, now patched in v0.2.3.
```
