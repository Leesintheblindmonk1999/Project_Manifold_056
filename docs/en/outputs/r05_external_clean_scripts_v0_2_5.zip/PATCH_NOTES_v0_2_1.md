# PATCH NOTES v0.2.1 — R0.5 Track-Conditioned Prompt Paraphrase

Date: 2026-06-18
Project: SAS / Project Manifold 0.56
Package: `r05_external_clean_scripts_v0_2_1.zip`

## Status

`v0.2.1` is an audit-integrated patch over `v0.2.0`.

It is designed to address the first real smoke result on `halogen/historical_events`, where:

- Preflight succeeded when prompt-like skipping was disabled.
- `21,008` raw historical-event A files were found.
- `20,196` were eligible.
- `812` were skipped as too short or underspecified.
- Smoke-3 generated outputs but obtained `0/3 accepted`.
- The generation guard returned exit code `2`, correctly preventing scale-up.

## Core finding motivating v0.2.1

`halogen/historical_events` is not declarative historical prose. It is a prompt/query source track.

Example source form:

```text
Tell me about the famous meeting between Brian Wildsmith and Samuel W. McCall.
```

Therefore, the valid `C_clean_equivalent` should be a paraphrased request, not inert metatext.

Valid example:

```text
Describe the famous meeting between Brian Wildsmith and Samuel W. McCall.
```

Invalid example:

```text
Dataset text regarding interaction between Brian Wildsmith and Samuel W. McCall.
```

## Changes

### 1. Added `--track prompt_paraphrase`

`generate_external_clean.py` and `verify_external_clean.py` now accept:

```bash
--track prompt_paraphrase
```

Supported tracks:

- `inert_dataset` — default v0.2.0 behavior.
- `prompt_paraphrase` — request/prompt paraphrase behavior.

### 2. Added prompt-specific generation template

For `--track prompt_paraphrase`, the generator now instructs the model to:

- rewrite the request as a request;
- not answer the request;
- not describe the source as dataset text;
- not use phrases like `dataset text`, `textual reference`, `placeholder`, `potential historical interaction`;
- preserve all names exactly;
- preserve the same request intent.

### 3. Added prompt-specific verification rules

For `--track prompt_paraphrase`, candidate checks now include:

- `prompt_paraphrase_not_request_like`
- `prompt_paraphrase_meta_description`

This rejects outputs such as:

```text
Dataset text regarding interaction between...
```

while accepting request-like rewrites such as:

```text
Describe the famous meeting between...
```

### 4. Fixed B-only contamination false positives for source-contained name parts

The previous smoke showed `Wildsmith` as B-only contamination even though `Brian Wildsmith` was present in A.

`b_only_invariants()` now ignores B entities already covered by a source entity.

Example:

```text
A entity: Brian Wildsmith
B entity: Wildsmith
```

This is no longer counted as B-only contamination.

### 5. Expanded STOPWORDS for prompt/meta terms

Added prompt/meta words that should not be treated as named entities, including:

- tell
- describe
- discuss
- find
- dataset
- textual
- record
- placeholder
- potential
- interaction
- encounter
- parameters
- sure

## Operational rule

Do not run R0.5P smoke/alpha without:

```bash
--track prompt_paraphrase
```

## Recommended next run

```powershell
py -u scripts\generate_external_clean.py `
  --track prompt_paraphrase `
  --provider openrouter `
  --model anthropic/claude-3.5-haiku `
  --corpus-dir "$TEMP_CORPUS" `
  --out-dir "$EXTERNAL_DIR" `
  --include-category "halogen/historical_events" `
  --skip-short-source-chars 70 `
  --max-source-chars 1200 `
  --sample 3 `
  --seed 42
```

Then verify with:

```powershell
py -u scripts\verify_external_clean.py `
  --track prompt_paraphrase `
  --corpus-dir "$TEMP_CORPUS" `
  --external-dir "$EXTERNAL_DIR" `
  --manifest-in "$EXTERNAL_DIR\external_clean_manifest.json" `
  --require-semantic `
  --report-out "$RUN_DIR\verification_report.json" `
  --show-failures
```

## Stop rule

- `3/3 accepted`: proceed to alpha-20.
- `2/3 accepted`: proceed cautiously to alpha-20.
- `1/3 accepted`: inspect rejected candidates.
- `0/3 accepted`: stop and patch; do not scale.
