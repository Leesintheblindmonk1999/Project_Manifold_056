#!/usr/bin/env python3
from __future__ import annotations
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from r05_common import (  # type: ignore
    SCRIPT_VERSION,
    contamination_hits,
    check_candidate,
    summarize_generation_records,
    write_json,
    read_json,
    source_eligibility_reason,
    REJECTION_REASON_TAXONOMY,
)


def assert_equal(name: str, got, expected, failures: list[str]) -> None:
    if got != expected:
        failures.append(f"{name}: expected {expected!r}, got {got!r}")


def assert_true(name: str, value: bool, failures: list[str]) -> None:
    if not value:
        failures.append(f"{name}: expected true, got {value!r}")


def assert_false(name: str, value: bool, failures: list[str]) -> None:
    if value:
        failures.append(f"{name}: expected false, got {value!r}")


def main() -> int:
    failures: list[str] = []

    assert_equal("script_version", SCRIPT_VERSION, "0.2.5", failures)

    # Boundary-aware B-only contamination tests.
    assert_equal(
        "Trade should not match inside trader",
        contamination_hits("Describe the famous meeting with a trader.", {"numbers_dates": [], "entities": ["Trade"]})["entities"],
        [],
        failures,
    )
    assert_equal(
        "Trade should match as standalone",
        contamination_hits("Describe the Trade meeting.", {"numbers_dates": [], "entities": ["Trade"]})["entities"],
        ["Trade"],
        failures,
    )
    assert_equal(
        "Emery should not match d'Emery",
        contamination_hits("Describe the famous meeting between John d'Emery and Alice.", {"numbers_dates": [], "entities": ["Emery"]})["entities"],
        [],
        failures,
    )
    assert_equal(
        "Emery should not match d’Emery curly apostrophe",
        contamination_hits("Describe the famous meeting between John d’Emery and Alice.", {"numbers_dates": [], "entities": ["Emery"]})["entities"],
        [],
        failures,
    )
    assert_equal(
        "Emery should match standalone",
        contamination_hits("Describe the famous meeting between Emery and Alice.", {"numbers_dates": [], "entities": ["Emery"]})["entities"],
        ["Emery"],
        failures,
    )
    for label, text, ent in [
        ("Brien/O'Brien", "Describe the meeting between Anne O'Brien and Smith.", "Brien"),
        ("Angelo/D'Angelo", "Describe the meeting between Sam D'Angelo and Smith.", "Angelo"),
        ("Diaye/N'Diaye", "Describe the meeting between Awa N'Diaye and Smith.", "Diaye"),
    ]:
        assert_equal(
            f"{label} should not contaminate",
            contamination_hits(text, {"numbers_dates": [], "entities": [ent]})["entities"],
            [],
            failures,
        )

    assert_equal(
        "Ouverture should not match L'Ouverture",
        contamination_hits("Describe the meeting with L'Ouverture today.", {"numbers_dates": [], "entities": ["Ouverture"]})["entities"],
        [],
        failures,
    )
    assert_equal(
        "Ouverture should match standalone",
        contamination_hits("Describe the meeting with Ouverture today.", {"numbers_dates": [], "entities": ["Ouverture"]})["entities"],
        ["Ouverture"],
        failures,
    )

    # Candidate malformed-generation checks.
    a = "Tell me about the famous meeting between Pancho Villa and Walt E. Ambord."
    c_leak = "Describe the famous meeting between Pancho Villa and Walt E. Ambord...Human: reTell me detailed the details."
    chk = check_candidate(
        a, c_leak, None,
        min_len_ratio=0.70,
        max_len_ratio=3.00,
        min_entity_recall=0.90,
        min_lexical=0.10,
        max_lexical=0.95,
        track="prompt_paraphrase",
    )
    assert_false("prompt leakage candidate accepted", chk.accepted, failures)
    assert_true("prompt_boundary_leakage reason", "prompt_boundary_leakage" in chk.reasons, failures)
    assert_true("malformed_generation taxonomy", chk.rejection_taxonomy.get("malformed_generation", 0) >= 1, failures)

    c_moji = "Describe the famous meeting between PanchoÃ³ Villa and Walt E. Ambord."
    chk = check_candidate(
        a, c_moji, None,
        min_len_ratio=0.70,
        max_len_ratio=3.00,
        min_entity_recall=0.00,
        min_lexical=0.10,
        max_lexical=0.95,
        track="prompt_paraphrase",
    )
    assert_false("mojibake candidate accepted", chk.accepted, failures)
    assert_true("candidate_mojibake reason", "candidate_mojibake_or_encoding_artifact" in chk.reasons, failures)

    # Preflight observability order: mojibake should be reported before
    # promptlike or short/underspecified reasons when skip_mojibake is enabled.
    short_corrupt = "Ã³ test"
    assert_equal(
        "short mojibake source returns mojibake reason",
        source_eligibility_reason(
            short_corrupt,
            "halogen/historical_events/x_A_clean.txt",
            min_chars=80,
            skip_mojibake=True,
            skip_promptlike=True,
        ),
        "mojibake_or_encoding_artifact",
        failures,
    )
    promptlike_corrupt = "Tell me about PanchoÃ³ Villa and the historical meeting between multiple delegates."
    assert_equal(
        "promptlike mojibake source returns mojibake reason",
        source_eligibility_reason(
            promptlike_corrupt,
            "halogen/historical_events/y_A_clean.txt",
            min_chars=20,
            skip_mojibake=True,
            skip_promptlike=True,
        ),
        "mojibake_or_encoding_artifact",
        failures,
    )

    # Taxonomy split: semantic drift failures must be separated from technical
    # semantic-observability warnings/errors.
    assert_equal(
        "semantic_similarity_below_threshold taxonomy",
        REJECTION_REASON_TAXONOMY.get("semantic_similarity_below_threshold"),
        "semantic_similarity_failure",
        failures,
    )
    assert_equal(
        "semantic_similarity_unavailable taxonomy",
        REJECTION_REASON_TAXONOMY.get("semantic_similarity_unavailable"),
        "semantic_observability",
        failures,
    )
    assert_equal(
        "semantic_truncation_risk taxonomy",
        REJECTION_REASON_TAXONOMY.get("semantic_truncation_risk"),
        "semantic_observability",
        failures,
    )

    # Retry metrics summarization.
    records = [
        {"status": "accepted", "attempts": [{"temperature": 0.25, "check": {"accepted": True, "reasons": []}}]},
        {"status": "accepted", "attempts": [
            {"temperature": 0.25, "check": {"accepted": False, "reasons": ["external_clean_too_far"]}},
            {"temperature": 0.35, "check": {"accepted": True, "reasons": []}},
        ]},
        {"status": "rejected", "attempts": [
            {"temperature": 0.25, "check": {"accepted": False, "reasons": ["prompt_boundary_leakage"]}},
            {"temperature": 0.35, "check": {"accepted": False, "reasons": ["candidate_mojibake_or_encoding_artifact"]}},
        ]},
    ]
    metrics = summarize_generation_records(records)
    assert_equal("retry generation attempted", metrics["generation_attempted_records"], 3, failures)
    assert_equal("first attempt accepted", metrics["first_attempt_accepted"], 1, failures)
    assert_equal("retry attempted", metrics["retry_attempted_records"], 2, failures)
    assert_equal("retry accepted", metrics["retry_accepted_records"], 1, failures)
    assert_equal("retry failed", metrics["retry_failed_records"], 1, failures)

    # BOM-free writer + BOM-tolerant reader.
    tmp = ROOT / "_tmp_regression_json.json"
    write_json(tmp, {"ok": True, "script_version": SCRIPT_VERSION})
    raw = tmp.read_bytes()
    assert_false("JSON has UTF-8 BOM", raw.startswith(b"\xef\xbb\xbf"), failures)
    loaded = read_json(tmp)
    assert_equal("read_json value", loaded["script_version"], "0.2.5", failures)
    tmp.unlink(missing_ok=True)

    report = {
        "script_version": SCRIPT_VERSION,
        "total_tests": 29,
        "failures": failures,
        "passed": not failures,
        "metrics_sample": metrics,
    }
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
