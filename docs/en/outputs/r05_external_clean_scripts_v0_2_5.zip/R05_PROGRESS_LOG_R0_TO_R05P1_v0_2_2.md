# SAS / Project Manifold 0.56 Progress Log - R0 to R0.5P-1 v0.2.2

Date: 2026-06-18

## Guiding rule

```text
build -> audit -> hash -> publish -> limit -> scale
```

## R0

R0 was closed as an infrastructure and baseline stability audit under `clean_strategy=self`.

Important limit:

```text
R0 is not final external validation. It shows that the infrastructure, labels, sampling, and baseline detector behavior are stable under clean-self controls.
```

## R0-bis

R0-bis audited dependence and redundancy among baseline modules using Pearson, Spearman, Distance Correlation, and normalized Mutual Information.

Important limit:

```text
Lexical/entity/length-style modules can be redundant. They should not be counted as independent tribunal votes without dependence checks.
```

## R0.5 original hypothesis

Initial hypothesis:

```text
A universal A-only paraphrase prompt can generate external clean equivalents across source families.
```

Result:

```text
Rejected. The corpus is heterogeneous and requires track-conditioned generation.
```

## Audit sequence

DeepSeek:

```text
APPROVE WITH PATCHES. One reported category-filter bug was later found to be a false positive.
```

Gemini:

```text
Confirmed timeout, number/date tolerance, promptlike expansion, and universal-prompt risks.
```

Claude:

```text
Confirmed category filter worked, identified entity regex crossing sentence boundaries, generic role-noun entity false positives, hard/soft refusal split, manifest path sanitization, timeout, resume, and zero-accepted stop guard.
```

## v0.2.0

Integrated audit findings:

- sentence-split before entity regex;
- expanded STOPWORDS;
- hard/soft refusal split;
- promptlike expansion;
- timeout=45s;
- number/date tolerance;
- manifest sanitization;
- log cleanup;
- resume behavior;
- exit code 2 when real generation has 0 accepted.

v0.2.0 preflight discovered:

```text
halogen/historical_events is prompt-like, not factual prose.
```

v0.2.0 smoke-3:

```text
0/3 accepted
```

Failure mode:

```text
The model generated metadescriptions such as `Dataset text regarding...` instead of equivalent requests.
```

## v0.2.1

Added:

```text
--track prompt_paraphrase
```

Core behavior:

```text
A request is rewritten as a request. The model must not answer it and must not describe it as dataset text.
```

Smoke-3:

```text
3/3 accepted
3/3 verified
```

Alpha-20:

```text
20/20 accepted
20/20 verified
```

Beta-100:

```text
99/100 accepted in generation
99/99 verified among generated C outputs
1 missing C from 1 generation-time rejection
0 API errors
```

## v0.2.2

The only beta-100 rejection was caused by mojibake in a named entity:

```text
Leif MÃƒÂ¦hle -> Leif MÃ¦hle
```

Decision:

```text
Do not relax entity invariants. Add source-level mojibake exclusion.
```

New preflight reason:

```text
mojibake_or_encoding_artifact
```

New default behavior:

```text
For prompt_paraphrase, mojibake exclusion is enabled unless --allow-mojibake-sources is passed.
```

## Current next step

Run beta-250 with v0.2.2.

Do not jump directly to 1200 until beta-250/beta-500 confirm that remaining rejection patterns are either absent or understood.
