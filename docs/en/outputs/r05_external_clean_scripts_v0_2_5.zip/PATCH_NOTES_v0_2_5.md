# PATCH_NOTES_v0_2_5.md

# R0.5 External-Clean Scripts v0.2.5 — Audit-Converged Hardening Patch

**Project:** SAS / Project Manifold κD-0.56  
**Release type:** hardening patch before R0.5P-2 beta/main-scale  
**Base:** `r05_external_clean_scripts_v0_2_4.zip`  
**Version:** `0.2.5`  

---

## 1. Purpose

v0.2.5 incorporates the converged findings from DeepSeek, Gemini, and Claude audits of v0.2.4.

The prior v0.2.4 package was judged safe for smoke and alpha testing, but auditors converged on two observable-output improvements before beta/main-scale use:

1. improve preflight reason observability by reporting mojibake/encoding corruption before promptlike or short-source reasons;
2. split semantic similarity threshold failures from technical semantic-observability failures in the rejection taxonomy.

v0.2.5 is therefore a **hardening release**, not a new scientific result.

---

## 2. External Audit Convergence

### DeepSeek

Verdict: `APPROVE WITH MINOR PATCHES`

Required before beta/main:

- reorder preflight reason logic;
- review `L'Ouverture / Ouverture` boundary case;
- split `semantic_similarity_below_threshold` taxonomy.

### Gemini

Verdict: `APPROVE WITH MINOR PATCHES`

Required:

- reorder mojibake preflight before length/min-word checks;
- split semantic similarity taxonomy;
- verify package integrity after Gemini reported missing manifest files.

Gemini adjudicated that `L'Ouverture / Ouverture` is already covered by the apostrophe-aware boundary logic.

### Claude final adjudication

Verdict: `APPROVE WITH MINOR PATCHES`

Claude verified:

- `PACKAGE_MANIFEST.json`, `SHA256SUMS.txt`, and `REGRESSION_TEST_REPORT_v0_2_4.md` were present in v0.2.4;
- 26/26 hashes verified;
- 21/21 v0.2.4 tests passed;
- retry metrics were correctly implemented;
- JSON/BOM behavior was correct;
- apostrophe-boundary behavior was correct;
- `L'Ouverture / Ouverture` was already handled by `join_chars`;
- v0.2.4 was safe for smoke/alpha but should be patched before beta/main.

Claude recommended a version bump to `v0.2.5` because the patches change observable outputs: preflight reason labels and taxonomy buckets.

---

## 3. Changes in v0.2.5

### P1 — Preflight reason order

File:

```text
scripts/r05_common.py
```

Function:

```text
source_eligibility_reason()
```

Old effective order:

```text
category -> short -> mojibake -> promptlike
```

New order:

```text
category -> mojibake -> promptlike -> short
```

Rationale:

When a source is both corrupted and short/promptlike, the most diagnostically important fact is encoding corruption. Reporting it as only `source_too_short_or_underspecified` masks corpus-quality problems and weakens track calibration.

Impact:

- Does not change whether a source is skipped.
- Changes the reported skip reason in ambiguous cases.
- Improves preflight breakdown quality for R0.5P-2.

### P2 — Semantic rejection taxonomy split

File:

```text
scripts/r05_common.py
```

Object:

```text
REJECTION_REASON_TAXONOMY
```

Changed mapping:

```python
"semantic_similarity_below_threshold": "semantic_similarity_failure"
```

Unchanged mappings:

```python
"semantic_similarity_unavailable": "semantic_observability"
"semantic_truncation_risk": "semantic_observability"
```

Rationale:

`semantic_similarity_below_threshold` is a hard semantic-distance failure when semantic verification is enabled. It is not equivalent to a technical observability issue such as unavailable embeddings or truncation risk.

Impact:

- Does not change acceptance/rejection decisions.
- Changes `taxonomy_counts` and `final_rejection_taxonomy` summaries.
- Improves report interpretability for semantic-enabled R0.5 tracks.

### P3 — Regression suite extension

File:

```text
tests/run_regression_tests_v0_2_5.py
```

Added explicit coverage for:

- `L'Ouverture / Ouverture` boundary adjudication;
- standalone `Ouverture` contamination;
- mojibake preflight reason precedence over short/promptlike filters;
- taxonomy bucket for `semantic_similarity_below_threshold`;
- retained semantic-observability mappings for unavailable/truncation cases.

Total tests:

```text
29
```

Result:

```text
29 passed / 0 failed
```

---

## 4. Non-Changes

v0.2.5 does **not** change:

- prompt design;
- retry temperature schedule;
- acceptance thresholds;
- B_hallucination quarantine policy;
- candidate generation strategy;
- SourceTargetGuard behavior;
- numbers/date contamination strictness;
- public scientific claims.

---

## 5. Methodological Boundary

This release does not claim:

- full R0.5 validation;
- R1 validation;
- production-grade hallucination detection;
- cross-domain external-clean robustness;
- universal κD validation.

Correct scope:

```text
v0.2.5 is a hardening base for R0.5P-2 source-shape-aware prompt/query paraphrase experiments.
```

---

## 6. Recommended Use

Safe for:

```text
R0.5P-2 preflight-only
R0.5P-2 smoke
R0.5P-2 alpha
R0.5P-2 beta, after source-shape profiling
```

Before main-scale:

```text
Run source_shape_profiler.py.
Inspect category/source-shape distribution.
Run smoke-5 per selected category.
Confirm zero B-only contamination and no recurrent prompt leakage.
```
