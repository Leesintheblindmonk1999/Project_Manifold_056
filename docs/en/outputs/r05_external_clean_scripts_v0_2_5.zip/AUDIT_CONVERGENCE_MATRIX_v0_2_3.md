# AUDIT CONVERGENCE MATRIX v0.2.3

| Issue | Source | Status | Resolution in v0.2.3 |
|---|---|---:|---|
| Prompt-like sources incorrectly treated as factual prose | Corpus inspection | Closed in v0.2.1 | Added `--track prompt_paraphrase` |
| v0.2.0 meta-description outputs | smoke-3 rejected candidates | Closed in v0.2.1 | Prompt now requires request-to-request paraphrase |
| Mojibake entity mutation (`Leif MÃƒÂ¦hle -> Leif MÃ¦hle`) | beta-100 v0.2.1 | Closed in v0.2.2 | Default preflight exclusion for mojibake under `prompt_paraphrase` |
| Generic B-only fragment `Trade` matched source-preserved `(trader)` | beta-250 v0.2.2 manual inspection | Closed in v0.2.3 | Weak single-token fragments + token-boundary contamination matching |
| Apostrophe/substring variant `dEmery` vs `d'Emery` caused `Emery` B-only hit | beta-250 v0.2.2 manual inspection | Closed in v0.2.3 | Compact entity overlap and source-text fallback |
| Need to preserve strict entity invariants | Methodological constraint | Preserved | No broad normalization acceptance; only false-positive contamination filtering |
| Need to keep B out of generation | R0.5 boundary rule | Preserved | B remains post-generation contamination audit only |

## Current empirical chain

```text
v0.2.0 smoke-3: 0/3 accepted
v0.2.1 smoke-3: 3/3 accepted
v0.2.1 alpha-20: 20/20 accepted
v0.2.1 beta-100: 99/100 accepted; 99/99 generated C verified
v0.2.2 beta-250: 248/250 accepted; 248/248 generated C verified
v0.2.3: verifier-only patch for the two beta-250 false positives
```

## Next recommended run

Repeat beta-250 or run beta-500 with v0.2.3.

Recommended criterion:

```text
>= 95% generation acceptance and 100% verification acceptance over generated C -> continue scaling.
Any new rejection type -> inspect before 1.2k.
```
