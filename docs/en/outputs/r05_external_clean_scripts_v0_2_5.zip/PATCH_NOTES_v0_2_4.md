# PATCH_NOTES_v0_2_4.md

# R0.5 External-Clean Scripts v0.2.4 — Hardening Patch

**Date:** 2026-06-18  
**Base:** `r05_external_clean_scripts_v0_2_3.zip`  
**Status:** hardening release for post-R0.5P-1 / pre-R0.5P-2 preparation

---

## Purpose

v0.2.4 converts the R0.5P-1 external audit findings into code-level hardening before any R0.5P-2 scaling.

This release does **not** reopen or reinterpret the published R0.5P-1 v1.0.1 result. It prepares the generator/verifier for the next source-shape-aware track by adding better observability, stricter malformed-candidate detection, and regression coverage for the residual boundary issues found during external audit.

---

## External Audit Findings Addressed

The post-package audit of R0.5P-1 identified two non-blocking but important hardening targets:

1. **Retry-rate disclosure**  
   v0.2.3 manifests contained enough attempt-level data to reconstruct retry behavior, but retry metrics were not exported as a first-class manifest summary.

2. **Apostrophe-adjacent boundary gap**  
   v0.2.3 fixed `Trade` / `trader` suffix collisions, but still allowed an entity such as `Emery` to match inside `d'Emery` during B-only-vs-C contamination matching, because apostrophes were treated as token boundaries.

v0.2.4 addresses both issues directly.

---

## Priority 1 — Automatic Retry Metrics

Generation manifests now include a top-level `retry_metrics` block computed from all generation records.

Added fields include:

```text
first_attempt_accepted
retry_attempted_records
retry_accepted_records
retry_failed_records
first_attempt_acceptance_rate
with_retry_acceptance_rate
accepted_on_attempt
temperature_attempt_counts
error_attempts
rejected_reason_counts_final_attempt
rejected_taxonomy_counts_final_attempt
```

Each accepted/rejected record also includes `attempt_observability`:

```text
attempt_count
retry_attempted
accepted_attempt_number
accepted_temperature
first_attempt_accepted
accepted_after_retry
attempt_temperatures
attempt_error_count
```

This makes first-attempt acceptance and with-retry acceptance auditable without re-parsing nested attempt logs manually.

---

## Priority 2 — Apostrophe-Boundary Contamination Fix

`_entity_present_as_boundary()` now treats these as entity-joining characters for single-token B-only entity matching:

```text
apostrophe: '
curly apostrophe: ’
backtick: `
hyphen: -
```

This prevents false contamination hits such as:

```text
B-only entity: Emery
C text:        d'Emery
```

while preserving true standalone contamination detection:

```text
B-only entity: Emery
C text:        Emery
```

Regression coverage includes:

```text
Trade / trader
Emery / d'Emery
Emery / d’Emery
Brien / O'Brien
Angelo / D'Angelo
Diaye / N'Diaye
```

---

## Priority 3 — JSON Without BOM

Added shared JSON helpers:

```python
write_json(path, obj)
read_json(path)
```

`write_json()` writes UTF-8 JSON without BOM and with a trailing newline.

`read_json()` tolerates UTF-8 BOM through `utf-8-sig` when reading manually-created or externally-exported JSON.

`generate_external_clean.py` and `verify_external_clean.py` now write main JSON artifacts through `write_json()`.

---

## Priority 4 — Stable Rejection Taxonomy

Added `REJECTION_REASON_TAXONOMY` and `taxonomize_reasons()`.

Example buckets:

```text
malformed_generation
track_shape_violation
length_violation
invariant_violation
lexical_distance_violation
contamination
semantic_observability
refusal_or_meta
other
```

`CandidateCheck` now includes:

```text
rejection_taxonomy
```

Verification reports now include:

```text
taxonomy_counts
```

Rejected generation records now include:

```text
final_reasons
final_rejection_taxonomy
```

---

## Priority 5 — Real Regression Tests

Added:

```text
tests/run_regression_tests_v0_2_4.py
```

The regression suite checks:

```text
SCRIPT_VERSION == 0.2.4
Trade does not match inside trader
Trade does match standalone
Emery does not match d'Emery
Emery does not match d’Emery
Emery does match standalone
Brien does not match O'Brien
Angelo does not match D'Angelo
Diaye does not match N'Diaye
prompt-boundary leakage is rejected
candidate mojibake is rejected
retry metrics summarize correctly
write_json output has no UTF-8 BOM
read_json reads the produced JSON
```

Result:

```text
passed: true
failures: []
```

---

## Priority 6 — Better Manifest Observability

v0.2.4 makes retry and rejection behavior visible at two levels:

1. **Per-record level** via `attempt_observability`.
2. **Manifest level** via `retry_metrics`.

This directly addresses the auditability gap that required external reviewers to manually query `external_clean_manifest.json` in v0.2.3.

---

## New Candidate Rejection Signals

`check_candidate()` now rejects:

```text
candidate_mojibake_or_encoding_artifact
prompt_boundary_leakage
```

Prompt-boundary leakage catches patterns such as:

```text
Human:
Assistant:
User:
System:
..Human:
```

This makes the three R0.5P-1 main-1200 rejection classes more explicit and easier to diagnose in future runs.

---

## Compatibility Notes

v0.2.4 is backward-compatible with the v0.2.3 CLI interface.

New manifest/report fields are additive.

No API keys are required for regression tests.

No semantic embedding model is required unless `--soft-semantic-warn` or `--require-semantic` is used.

---

## Methodological Boundary

This patch is a hardening release. It does not claim:

```text
full R0.5 validation
R1 validation
production-grade hallucination detection
cross-domain external-clean robustness
```

It should be used as the technical base for:

```text
R0.5P-2 source-shape-aware multi-category prompt/query paraphrase audit
```

---

## Recommended Next Step

Run an aggressive external audit of this ZIP before using it for R0.5P-2.

Then proceed to:

```text
source_shape_profiler.py
```

with the rule:

```text
No external-clean generation before source-shape inspection.
```
