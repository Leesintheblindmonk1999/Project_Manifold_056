# R0.5 External-Clean Scripts v0.2.0 — Audit-Integrated Patch Notes

Status: **audit-integrated candidate for R0.5A-1 historical_events**.

This release incorporates the convergent findings from the DeepSeek, Gemini, and Claude audits of v0.1.9. It does **not** claim to validate SAS/κD. It stabilizes the external-clean generation pipeline before any real smoke/alpha token spend.

## Main methodological decision

R0.5 is now treated as a **track-conditioned data transformation problem**, not a monolithic prompt problem.

Initial track:

- Track: `R0.5A-1 Historical Factual Prose`
- Category: `halogen/historical_events`
- Recommended filters:
  - `--include-category "halogen/historical_events"`
  - `--skip-promptlike-sources`
  - `--skip-short-source-chars 160`
  - `--max-source-chars 1200`

Deferred tracks:

- `R0.5A-2 biographies_filtered` due to knowledge-injection risk.
- `R0.5B factual_QA` due to Q/A prompt and answer-polarity handling.
- `R0.5C reasoning_solver_style` due to solver behavior.
- `R0.5D long_summarization` due to long-context and semantic truncation risk.
- `R0.5E code_structured_claims` due to code/format-specific invariants.

## Integrated fixes

1. **Entity extraction sentence-boundary fix**
   - `r05_common.py::extract_entities` now splits text into sentence chunks before applying the entity regex.
   - Prevents false entities such as `Assam. He` or `Paris. Scholars`.

2. **Role-noun/entity stopword expansion**
   - Added role/common nouns such as `historians`, `scholars`, `researchers`, `officials`, `experts`, etc.
   - Added month names so dates are handled by numeric/date invariants rather than entity recall.
   - Added leading/trailing stopword cleanup for entities such as `The Berlin Wall` -> `Berlin Wall`.

3. **Hard/soft refusal split**
   - Hard refusal patterns still reject: `as an AI`, `I can't`, `unable to`, `cannot provide/generate`, etc.
   - Ambiguous uncertainty phrases such as `unverified claim` and `do not have confirmation` now produce warnings instead of hard rejection.

4. **Prompt-like source detection expansion**
   - Added support for `Q:`, `A:`, `Question:`, `Answer:`.
   - Added `Is this ... consistent/correct/valid ... ?` pattern for solver-style sources.

5. **API timeout**
   - Added `--timeout`, default `45.0` seconds.
   - Passed to OpenRouter and Anthropic API calls.

6. **Number/date tolerance**
   - `numbers_preserved` now tolerates limited digit-to-word equivalents such as `2` -> `two` and `50` -> `fifty`.
   - Tolerates common date reformats such as `April 5, 1990` -> `1990-04-05`.

7. **Manifest path sanitization**
   - `thresholds` now uses `sanitize_args_for_manifest(args)` instead of raw `vars(args)`.
   - Avoids leaking local absolute paths such as Windows usernames into publishable manifests.

8. **Preflight/failure JSONL cleanup**
   - `external_clean_skipped_preflight.jsonl` and `external_clean_failures.jsonl` are cleared per run if present, regardless of `--overwrite`.
   - Prevents stale/duplicated entries when reusing an output directory.

9. **Resume behavior**
   - If `C_clean` already exists and `--overwrite` is not set, generation skips it and increments `skipped_existing`.
   - Intended for any run larger than alpha-20.

10. **Zero-accepted safety**
   - Non-preflight generation returns exit code `2` if selected records were processed and zero candidates were accepted, unless `--allow-zero-accepted` is passed.
   - This enforces the stop rule before scaling.

## Stop criteria

- Preflight-only may run immediately.
- Smoke-3 should run only on v0.2.0.
- Alpha-20 should run only if smoke-3 accepts at least 2/3.
- If smoke-3 accepts 0/3, stop and inspect `rejected_candidates_private/` before spending more tokens.
