# PATCH_NOTES v0.2.3 — verifier-only B-only contamination refinement

Date: 2026-06-18
Project: SAS / Project Manifold 0.56 — R0.5 external-clean calibration
Package: `r05_external_clean_scripts_v0_2_3.zip`

## Why this patch exists

v0.2.2 introduced mojibake/encoding preflight exclusion and was tested on `R0.5P-1 Historical Query Paraphrase` over `halogen/historical_events`.

The v0.2.2 beta-250 run produced:

- raw A files: 21,008
- eligible after preflight: 18,964
- skipped by preflight: 2,044
  - `mojibake_or_encoding_artifact`: 1,232
  - `source_too_short_or_underspecified`: 812
- generated sample: 250
- accepted at generation: 248/250
- rejected at generation: 2/250
- errors: 0
- verification: 248/248 generated C files accepted

Manual inspection of the two generation rejections showed that both candidates were valid prompt paraphrases and were rejected by over-aggressive `b_only_contamination` checks.

## Two concrete false positives

### 1. `16644_A_clean.txt`

A:

```text
Tell me about the famous meeting between William Pfaender and James Hanna (trader).
```

C candidate:

```text
Describe the famous meeting between William Pfaender and James Hanna (trader).
```

Rejected reason:

```text
b_only_contamination: Trade
```

Root cause: B contained `Chicago Board of Trade`; the verifier extracted `Trade` as a B-only entity and matched it inside the source-preserved token `(trader)`.

### 2. `4633_A_clean.txt`

A:

```text
Tell me about the famous meeting between Paul Sturm and Michel Particelli dEmery.
```

C candidate:

```text
Describe the famous meeting between Paul Sturm and Michel Particelli dEmery.
```

Rejected reason:

```text
b_only_contamination: Emery
```

Root cause: B contained `d'Emery`, while A/C contained `dEmery`. Entity extraction isolated `Emery` from B and then matched it as a substring in the source-preserved `dEmery` form.

## Patch scope

This is intentionally a verifier-only patch. The generation prompt is not changed because the prompt is already working:

- smoke-3 v0.2.1: 3/3 accepted
- alpha-20 v0.2.1: 20/20 accepted
- beta-100 v0.2.1: 99/100 accepted, with the only rejection traced to mojibake
- beta-250 v0.2.2: 248/250 accepted, 248/248 generated C verified

## Code changes

In `scripts/r05_common.py`:

1. `SCRIPT_VERSION` updated to `0.2.3`.
2. Added `B_ONLY_WEAK_SINGLE_TOKEN_FRAGMENTS` for generic fragments extracted from longer B-only entities.
3. Added `_compact_entity_text()` for apostrophe/spacing-insensitive overlap checks.
4. Added `_is_weak_single_token_b_entity()`.
5. Extended `_entity_covered_by_a_entity()` to use source-text fallback, including `dEmery` / `d'Emery` style variants.
6. Updated `b_only_invariants()` to pass full A text into entity coverage.
7. Added `_entity_present_as_boundary()` so single-token B-only entities require token boundaries. This prevents `Trade` matching `trader` and `Emery` matching `dEmery`.
8. Kept strong contamination detection for genuinely new B-only numbers, dates, and non-overlapping entities.

In `scripts/generate_external_clean.py` and `scripts/verify_external_clean.py`:

- User-facing version strings updated to `0.2.3`.

## Methodological decision

Do not relax entity preservation. Do not accept corrupted or mutated names silently. Instead:

- v0.2.2 excludes mojibake sources at preflight.
- v0.2.3 prevents weak substring matches from causing false contamination rejection.

This preserves the core R0.5 principle: strict source invariants, but calibrated verifier logic.
