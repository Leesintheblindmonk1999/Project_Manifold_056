# R0.5 Phase A Decision

A-only generation remains frozen. v0.1.9 adds source eligibility and task-source controls.
