# R0.5 Design Calibration Log - v0.2.2

Project: SAS / Project Manifold 0.56  
Phase: R0.5 external-clean preparation  
Date: 2026-06-18

## Scope

This log extends the v0.2.1 calibration record with the successful smoke-3, alpha-20, beta-100, and the v0.2.2 mojibake hardening decision.

## R0 context

R0 established an infrastructure/baseline stability control under `clean_strategy=self`.

Key methodological limit:

```text
R0 is not final production validation. It is an infrastructure and baseline stability audit.
```

## R0-bis context

R0-bis showed nonlinear dependence and redundancy among baseline modules.

Key methodological limit:

```text
Correlated modules must be treated as evidence groups, not independent votes.
```

## R0.5 purpose

R0.5 tests whether the system remains useful when the clean control is no longer identity/self-copy but externally generated `C_clean_equivalent`.

Core boundary:

```text
Generation sees A_clean only.
B_hallucination is forbidden during generation and used only after generation for contamination audit.
```

## v0.2.0 finding

`v0.2.0` integrated audit patches from DeepSeek/Gemini/Claude and correctly prevented scale-up after a failed smoke.

Observed R0.5P-1 smoke-3:

```text
total_selected: 3
accepted: 0
rejected: 3
exit_code: 2
```

Rejected candidates were meta-descriptions:

```text
Dataset text regarding interaction between...
Textual reference regarding interaction between...
```

Conclusion:

```text
The model was not failing to call the API. It was following the wrong transformation objective. Prompt-like sources require request-preserving paraphrase, not inert dataset metadescription.
```

## v0.2.1 decision

Added:

```bash
--track prompt_paraphrase
```

Principle:

```text
R0.5P requires preserving illocutionary form. A request must remain a request.
```

## v0.2.1 smoke-3 result

Track: `prompt_paraphrase`  
Category: `halogen/historical_events`

```text
raw A files: 21008
eligible: 20196
skipped: 812
selected: 3
generation accepted: 3/3
generation rejected: 0/3
verification A: 3
verification C: 3
missing C: 0
verification accepted: 3
verification rejected: 0
acceptance rate: 1.0
```

Conclusion:

```text
The v0.2.1 track-conditioned patch resolved the v0.2.0 meta-description failure mode at smoke scale.
```

## v0.2.1 alpha-20 result

```text
raw A files: 21008
eligible: 20196
skipped: 812
selected: 20
generation accepted: 20/20
generation rejected: 0/20
verification A: 20
verification C: 20
missing C: 0
verification accepted: 20
verification rejected: 0
acceptance rate: 1.0
```

Qualitative sample:

```text
A_clean:
Tell me about the famous meeting between Brian Wildsmith and Samuel W. McCall.

C_clean:
Describe the famous meeting between Brian Wildsmith and Samuel W. McCall.
```

Conclusion:

```text
The outputs preserve request form, preserve named entities, avoid answering, and avoid metadescription.
```

## v0.2.1 beta-100 result

```text
raw A files: 21008
eligible: 20196
skipped: 812
selected: 100
generation accepted: 99/100
generation rejected: 1/100
generation errors: 0
verification A: 100
verification C: 99
missing C: 1
verification accepted: 99
verification rejected: 0
acceptance rate over generated C: 1.0
```

Interpretation:

```text
Generation yield: 99%
Verifier pass rate over generated C: 100%
```

## Single beta-100 rejection analysis

Rejected source:

```text
halogen/historical_events/20297_A_clean.txt
```

Source:

```text
Tell me about the famous meeting between Ellen G. White and Leif MÃƒÂ¦hle.
```

Rejected candidate:

```text
Describe the famous meeting between Ellen G. White and Leif MÃ¦hle.
```

Reason:

```text
entity_recall_below_threshold
entity_recall: 0.666667
```

Interpretation:

```text
The model conceptually paraphrased correctly, but the corrupted name surface form changed. This is a data-quality/encoding artifact, not a prompt-paraphrase failure.
```

## v0.2.2 decision

Add mojibake source exclusion during preflight.

Reason:

```text
Do not relax entity invariants. Exclude corrupted sources before generation and document them as skipped data-quality artifacts.
```

## Current status after v0.2.2

R0.5P-1 is stable through beta-100 under v0.2.1, with one known data-quality rejection now addressed by v0.2.2 preflight.

Recommended next step:

```text
Run beta-250 with v0.2.2 before scaling to larger R0.5P-1 runs.
```

## Paper-ready finding

```text
R0.5 preparation showed that external-clean generation is a track-conditioned data transformation problem. `halogen/historical_events` is not declarative factual prose but a prompt/query paraphrase track. The v0.2.1 `prompt_paraphrase` mode corrected the v0.2.0 meta-description failure mode, reaching 3/3 smoke, 20/20 alpha, and 99/100 beta generation acceptance, with 99/99 verification acceptance over generated outputs. The only beta rejection was traced to a mojibake artifact in a named entity, motivating v0.2.2 source-level encoding exclusion rather than relaxed entity matching.
```
