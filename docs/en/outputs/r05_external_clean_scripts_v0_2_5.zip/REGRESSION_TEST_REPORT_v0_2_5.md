# REGRESSION_TEST_REPORT_v0_2_5.md

# R0.5 External-Clean Scripts v0.2.5 — Regression Test Report

**Project:** SAS / Project Manifold κD-0.56  
**Release:** `v0.2.5`  
**Test script:** `tests/run_regression_tests_v0_2_5.py`  
**Result:** PASS  

---

## Summary

```text
Total tests: 29
Failures:    0
Passed:      true
```

The regression suite validates the audit-converged v0.2.5 patches:

- script version consistency;
- boundary-aware B-only contamination detection;
- apostrophe and hyphen handling;
- prompt-boundary leakage rejection;
- mojibake candidate rejection;
- retry metrics summarization;
- preflight reason observability order;
- semantic taxonomy split;
- UTF-8 JSON without BOM;
- BOM-tolerant JSON reading.

---

## Coverage

### Versioning

- `SCRIPT_VERSION == "0.2.5"`

### Boundary-aware contamination

Covered cases:

```text
Trade / trader                    -> no contamination
Trade standalone                  -> contamination
Emery / d'Emery                  -> no contamination
Emery / d’Emery                  -> no contamination
Emery standalone                 -> contamination
Brien / O'Brien                  -> no contamination
Angelo / D'Angelo                -> no contamination
Diaye / N'Diaye                  -> no contamination
Ouverture / L'Ouverture          -> no contamination
Ouverture standalone             -> contamination
```

### Malformed generation rejection

Covered cases:

```text
Human:/Assistant:/User:/System-style prompt boundary leakage
mojibake-like candidate artifacts such as PanchoÃ³
```

Expected taxonomy:

```text
malformed_generation
```

### Retry metrics

Synthetic records validate:

```text
generation_attempted_records
first_attempt_accepted
retry_attempted_records
retry_accepted_records
retry_failed_records
first_attempt_acceptance_rate
with_retry_acceptance_rate
accepted_on_attempt
temperature_attempt_counts
error_attempts
```

### Preflight order

Covered cases:

```text
short corrupted source -> mojibake_or_encoding_artifact
promptlike corrupted source -> mojibake_or_encoding_artifact
```

This confirms mojibake is reported before promptlike/short filters when `skip_mojibake=True`.

### Semantic taxonomy split

Covered mappings:

```text
semantic_similarity_below_threshold -> semantic_similarity_failure
semantic_similarity_unavailable     -> semantic_observability
semantic_truncation_risk            -> semantic_observability
```

### JSON/BOM

Covered behavior:

```text
write_json() writes UTF-8 without BOM
read_json() tolerates UTF-8 BOM
```

---

## Raw Regression Output

See:

```text
REGRESSION_TEST_OUTPUT_v0_2_5.json
```
