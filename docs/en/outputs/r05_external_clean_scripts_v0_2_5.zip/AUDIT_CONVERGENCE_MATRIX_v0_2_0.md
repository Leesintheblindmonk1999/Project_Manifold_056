# R0.5 v0.2.0 Audit Convergence Matrix

This matrix summarizes findings from the DeepSeek, Gemini, and Claude audits that led from v0.1.9 to v0.2.0.

| Finding | DeepSeek | Gemini | Claude | v0.2.0 decision |
|---|---:|---:|---:|---|
| `include-category` / `exclude-category` not passed | Yes | No | No | Classified as DeepSeek false positive; no code change needed. |
| Missing API timeout | No | Yes | Yes | Added `--timeout 45.0`; passed to OpenRouter/Anthropic calls. |
| Prompt universal is unsafe | Partial | Yes | Yes | R0.5 is track-conditioned; historical_events first. |
| `Q:` / `A:` promptlike gap | No | Yes | Yes | Added regex patterns. |
| `Is this ... consistent ... ?` solver-style gap | No | Partial | Yes | Added regex pattern before QA/reasoning tracks. |
| `numbers_preserved` too literal | Partial | Yes | Yes | Added number-word and date reformat tolerance. |
| Entity regex crosses sentence boundaries | No | No | Yes | Blocker root cause; fixed by sentence-splitting before regex. |
| Role nouns treated as entities | No | No | Yes | Expanded STOPWORDS with role/common nouns. |
| `unverified claim` false refusal | No | No | Yes | Hard/soft refusal split; ambiguous phrases become warnings. |
| Manifest absolute-path leakage | No | No | Yes | Added sanitized manifest thresholds. |
| Duplicate preflight/failure JSONL on reused out_dir | No | No | Yes | Logs are cleared per run. |
| No real resume | No | No | Yes | Added `skipped_existing` behavior. |
| Zero accepted returns success | No | No | Yes | Added nonzero exit code unless `--allow-zero-accepted`. |

## Methodological conclusion

The R0.5 preparation phase showed that external-clean generation is not a single-prompt problem but a track-conditioned data transformation problem. This was detected before large-scale token expenditure and before any production claim was made.
