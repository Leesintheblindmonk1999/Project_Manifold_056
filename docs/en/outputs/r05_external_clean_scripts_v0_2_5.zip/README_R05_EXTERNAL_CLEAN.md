# R0.5 External-Clean Scripts - v0.2.2

Project: SAS / Project Manifold 0.56  
Phase: R0.5 external-clean preparation  
Package: `r05_external_clean_scripts_v0_2_2.zip`

## Status

`v0.2.2` is a small hardening patch over `v0.2.1`.

It keeps the successful track-conditioned `prompt_paraphrase` design and adds a conservative preflight exclusion for sources with mojibake / encoding artifacts.

The patch is motivated by the R0.5P-1 beta-100 result:

```text
raw A files: 21008
eligible A after v0.2.1 preflight: 20196
skipped: 812
selected: 100
generation accepted: 99/100
generation rejected: 1/100
verification A files: 100
verification C files: 99
missing C: 1
verification accepted: 99
verification rejected: 0
verification acceptance rate over generated C: 1.0
```

The single rejected case was traced to a mojibake/encoding artifact in a named entity:

```text
A source:
Tell me about the famous meeting between Ellen G. White and Leif MÃƒÂ¦hle.

Rejected candidate:
Describe the famous meeting between Ellen G. White and Leif MÃ¦hle.

Reason:
entity_recall_below_threshold
```

This is a correct rejection. For R0.5, entity invariants should not be relaxed to hide encoding changes.

## Main changes from v0.2.1

### 1. Mojibake source preflight exclusion

`generate_external_clean.py` now supports:

```bash
--skip-mojibake-sources
--allow-mojibake-sources
```

For `--track prompt_paraphrase`, mojibake exclusion is enabled by default unless `--allow-mojibake-sources` is passed.

Detected patterns include:

```text
Ãƒ
Ã‚
Ã
Â
â€™
â€œ
â€�
â€
â€“
â€”
â€¦
ï¿½
�
```

Skipped examples are written into:

```text
external_clean_skipped_preflight.jsonl
```

with reason:

```text
mojibake_or_encoding_artifact
```

and field:

```text
mojibake_hits
```

### 2. Manifest records effective preflight flags

Generation manifests now include:

```json
"effective_preflight_flags": {
  "skip_mojibake_sources": true
}
```

### 3. Documentation integrated

This package includes the cumulative progress and calibration documents:

- `PATCH_NOTES_v0_2_2.md`
- `R05_DESIGN_CALIBRATION_LOG_v0_2_2.md`
- `R05_PROGRESS_LOG_R0_TO_R05P1_v0_2_2.md`
- `AUDIT_CONVERGENCE_MATRIX_v0_2_2.md`
- prior v0.1.9/v0.2.0/v0.2.1 notes

## Supported tracks

### `inert_dataset`

Default behavior from v0.2.0.

Use when `A_clean` is declarative or structured source text that should be paraphrased without changing factual content.

### `prompt_paraphrase`

Use when `A_clean` is itself a request/prompt.

Example:

```text
A_clean:
Tell me about the famous meeting between Brian Wildsmith and Samuel W. McCall.

Valid C_clean:
Describe the famous meeting between Brian Wildsmith and Samuel W. McCall.

Invalid C_clean:
Dataset text regarding interaction between Brian Wildsmith and Samuel W. McCall.
```

## Recommended R0.5P-1 setup

```powershell
cd "C:\Users\conno\Downloads\SAS-Semantico\SAS-V2\scripts\r05_external_clean_scripts_v0_2_2"

$REAL_CORPUS = "C:\Users\conno\Downloads\SAS-Semantico\benchmark_corpus"
$TEMP_CORPUS = Join-Path (Get-Location) "tmp_corpus_r05p1"

Remove-Item $TEMP_CORPUS -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path "$TEMP_CORPUS\halogen" | Out-Null
cmd /c mklink /J "$TEMP_CORPUS\halogen\historical_events" "$REAL_CORPUS\halogen\historical_events"
```

If your local folder really contains the accented path `SAS-Semantico` with an accented character, keep your local spelling. The README uses ASCII for portability.

## Preflight-only

```powershell
$RUN_ID = "r05p1_hist_query_preflight_v022_" + (Get-Date -Format "yyyyMMdd_HHmmss")
$RUN_DIR = Join-Path (Get-Location) "runs\$RUN_ID"
$EXTERNAL_DIR = Join-Path $RUN_DIR "external_clean"
New-Item -ItemType Directory -Force -Path $RUN_DIR | Out-Null

py -u scripts\generate_external_clean.py `
  --track prompt_paraphrase `
  --provider openrouter `
  --corpus-dir "$TEMP_CORPUS" `
  --out-dir "$EXTERNAL_DIR" `
  --include-category "halogen/historical_events" `
  --skip-short-source-chars 70 `
  --max-source-chars 1200 `
  --sample 20 `
  --seed 42 `
  --preflight-only `
  2>&1 | Tee-Object "$RUN_DIR\preflight_stdout_stderr.txt"

"PREFLIGHT_EXIT_CODE = $LASTEXITCODE"
Select-String -Path "$RUN_DIR\preflight_stdout_stderr.txt" -Pattern "discovered|mojibake|eligible|skipped|selected|preflight|ERROR|Traceback"
```

Expected shape with mojibake filtering enabled:

```text
[INFO] discovered raw A files: 21008
[INFO] mojibake/encoding artifact preflight exclusion: enabled
[INFO] eligible A files after v0.2.2 preflight: approximately 20195 or lower if more mojibake sources exist
[INFO] skipped by preflight: approximately 813 or higher
[INFO] selected A files for this run: 20
[INFO] preflight-only complete.
```

## Smoke / alpha / beta command template

Replace `--sample` as needed: `3`, `20`, `100`, `250`, or `500`.

```powershell
$env:OPENROUTER_API_KEY = "sk-or-v1-REPLACE_WITH_NEW_KEY"

$RUN_ID = "r05p1_hist_query_beta250_v022_" + (Get-Date -Format "yyyyMMdd_HHmmss")
$RUN_DIR = Join-Path (Get-Location) "runs\$RUN_ID"
$EXTERNAL_DIR = Join-Path $RUN_DIR "external_clean"
New-Item -ItemType Directory -Force -Path $RUN_DIR | Out-Null

py -u scripts\generate_external_clean.py `
  --track prompt_paraphrase `
  --provider openrouter `
  --model anthropic/claude-3.5-haiku `
  --corpus-dir "$TEMP_CORPUS" `
  --out-dir "$EXTERNAL_DIR" `
  --include-category "halogen/historical_events" `
  --skip-short-source-chars 70 `
  --max-source-chars 1200 `
  --sample 250 `
  --seed 42 `
  2>&1 | Tee-Object "$RUN_DIR\generate_stdout_stderr.txt"

"GENERATE_EXIT_CODE = $LASTEXITCODE"

py -u scripts\verify_external_clean.py `
  --track prompt_paraphrase `
  --corpus-dir "$TEMP_CORPUS" `
  --external-dir "$EXTERNAL_DIR" `
  --manifest-in "$EXTERNAL_DIR\external_clean_manifest.json" `
  --require-semantic `
  --report-out "$RUN_DIR\verification_report.json" `
  --show-failures `
  2>&1 | Tee-Object "$RUN_DIR\verify_stdout_stderr.txt"

"VERIFY_EXIT_CODE = $LASTEXITCODE"

Select-String -Path "$RUN_DIR\generate_stdout_stderr.txt" -Pattern "INFO|accepted|rejected|ERROR|Traceback|timeout|zero"
Select-String -Path "$RUN_DIR\verify_stdout_stderr.txt" -Pattern "Accepted|Rejected|Missing|Acceptance|ERROR|Traceback"
```

## Stop rules

```text
Smoke-3:
  3/3 accepted -> alpha-20
  2/3 accepted -> alpha-20 with caution
  1/3 accepted -> inspect rejects
  0/3 accepted -> stop and patch

Alpha-20:
  >= 16/20 accepted -> beta-100
  12-15/20 -> inspect rejects
  < 12/20 -> stop

Beta-100:
  >= 90/100 accepted -> stable at beta-100 scale
  80-89/100 -> inspect rejects
  < 80/100 -> stop

Beta-250 / beta-500:
  use the same acceptance-rate logic; do not jump to 1200 until rejection patterns are understood.
```

## Security note

Do not paste live API keys into chat logs. If a key is exposed, revoke it and generate a new one before continuing.

---

## v0.2.3 verifier-only patch

v0.2.3 keeps the v0.2.2 generation behavior and mojibake preflight exclusion, but refines `b_only_contamination` after beta-250 showed two false positives.

### Why v0.2.3 exists

The v0.2.2 beta-250 run on `R0.5P-1 Historical Query Paraphrase` produced:

```text
Raw A files: 21,008
Eligible after preflight: 18,964
Skipped by preflight: 2,044
  mojibake_or_encoding_artifact: 1,232
  source_too_short_or_underspecified: 812
Generation accepted: 248/250
Generation rejected: 2/250
Verification accepted: 248/248 generated C files
```

Manual inspection showed both rejected candidates were valid request paraphrases rejected by overly aggressive B-only contamination logic:

- `Trade` from B matched source-preserved `(trader)`.
- `Emery` from B `d'Emery` matched source-preserved `dEmery`.

v0.2.3 fixes those verifier false positives without relaxing entity preservation.

### Recommended next run

```powershell
$RUN_ID = "r05p1_hist_query_beta500_v023_" + (Get-Date -Format "yyyyMMdd_HHmmss")
$RUN_DIR = Join-Path (Get-Location) "runs\$RUN_ID"
$EXTERNAL_DIR = Join-Path $RUN_DIR "external_clean"
New-Item -ItemType Directory -Force -Path $RUN_DIR | Out-Null

py -u scripts\generate_external_clean.py `
  --track prompt_paraphrase `
  --provider openrouter `
  --model anthropic/claude-3.5-haiku `
  --corpus-dir "$TEMP_CORPUS" `
  --out-dir "$EXTERNAL_DIR" `
  --include-category "halogen/historical_events" `
  --skip-short-source-chars 70 `
  --max-source-chars 1200 `
  --sample 500 `
  --seed 42 `
  2>&1 | Tee-Object "$RUN_DIR\generate_stdout_stderr.txt"

"GENERATE_EXIT_CODE = $LASTEXITCODE"

py -u scripts\verify_external_clean.py `
  --track prompt_paraphrase `
  --corpus-dir "$TEMP_CORPUS" `
  --external-dir "$EXTERNAL_DIR" `
  --manifest-in "$EXTERNAL_DIR\external_clean_manifest.json" `
  --require-semantic `
  --report-out "$RUN_DIR\verification_report.json" `
  --show-failures `
  2>&1 | Tee-Object "$RUN_DIR\verify_stdout_stderr.txt"

"VERIFY_EXIT_CODE = $LASTEXITCODE"
```

### Recommended acceptance criterion

```text
>= 95% generation acceptance and 100% verification acceptance over generated C: continue scaling.
Any new rejection type: inspect before 1.2k.
```
