# Audit Convergence Matrix - v0.2.2

Project: SAS / Project Manifold 0.56  
Phase: R0.5 external-clean preparation

## Matrix

| Source | Finding | Status in v0.2.2 |
|---|---|---|
| DeepSeek | `include_categories/exclude_categories` alleged bug | False positive; filters already passed correctly |
| Gemini | API timeout needed | Integrated since v0.2.0 |
| Gemini | number/date preservation too literal | Integrated since v0.2.0 |
| Gemini | promptlike source detection incomplete | Integrated since v0.2.0 |
| Gemini | universal prompt is methodologically weak | Resolved by track-conditioned design in v0.2.1 |
| Claude | entity regex crossed sentence boundaries | Integrated since v0.2.0 |
| Claude | generic role nouns treated as entities | Integrated since v0.2.0 |
| Claude | hard/soft refusal split needed | Integrated since v0.2.0 |
| Claude | manifest path sanitization needed | Integrated since v0.2.0 |
| Local preflight | `historical_events` is prompt-like, not factual prose | Resolved as R0.5P-1 prompt/query paraphrase |
| v0.2.0 smoke | 0/3 accepted due to metadescriptions | Resolved by `--track prompt_paraphrase` in v0.2.1 |
| v0.2.1 smoke | 3/3 accepted | Passed |
| v0.2.1 alpha | 20/20 accepted | Passed |
| v0.2.1 beta | 99/100 accepted, 99/99 verified | Passed with one data-quality artifact |
| v0.2.1 beta rejection | mojibake in named entity caused entity recall failure | Resolved by v0.2.2 mojibake preflight exclusion |

## Current engineering decision

```text
v0.2.2 preserves strict entity invariants and handles encoding artifacts at source eligibility/preflight, not candidate verification relaxation.
```

## Next recommended audit

```text
Run R0.5P-1 beta-250 with v0.2.2.
If acceptance remains >= 90% and rejected cases are only data-quality artifacts, move to beta-500.
```
