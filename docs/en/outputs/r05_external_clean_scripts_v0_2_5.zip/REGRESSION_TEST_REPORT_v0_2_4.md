# REGRESSION_TEST_REPORT_v0_2_4.md

# R0.5 External-Clean v0.2.4 Regression Test Report

**Script package:** `r05_external_clean_scripts_v0_2_4.zip`  
**Base:** `r05_external_clean_scripts_v0_2_3.zip`  
**Purpose:** post-audit hardening before R0.5P-2

---

## Test Command

```bash
python3 -m py_compile scripts/*.py tests/run_regression_tests_v0_2_4.py
python3 tests/run_regression_tests_v0_2_4.py
```

---

## Test Result

```json
{
  "script_version": "0.2.4",
  "total_tests": 21,
  "failures": [],
  "passed": true
}
```

---

## Coverage

The regression suite checks the following hardening requirements:

| Requirement | Status |
|---|---:|
| `SCRIPT_VERSION == 0.2.4` | passed |
| `Trade` does not match inside `trader` | passed |
| `Trade` matches standalone `Trade` | passed |
| `Emery` does not match `d'Emery` | passed |
| `Emery` does not match `d’Emery` | passed |
| `Emery` matches standalone `Emery` | passed |
| `Brien` does not match `O'Brien` | passed |
| `Angelo` does not match `D'Angelo` | passed |
| `Diaye` does not match `N'Diaye` | passed |
| prompt-boundary leakage is rejected | passed |
| mojibake candidate is rejected | passed |
| retry metrics summarize correctly | passed |
| generated JSON has no UTF-8 BOM | passed |
| generated JSON can be read back | passed |

---

## Retry Metrics Sample

Synthetic records were used to validate manifest-level retry metrics:

```json
{
  "records_total": 3,
  "generation_attempted_records": 3,
  "accepted_records": 2,
  "rejected_records": 1,
  "first_attempt_accepted": 1,
  "retry_attempted_records": 2,
  "retry_accepted_records": 1,
  "retry_failed_records": 1,
  "first_attempt_acceptance_rate": 0.333333,
  "with_retry_acceptance_rate": 0.666667,
  "accepted_on_attempt": {
    "1": 1,
    "2": 1
  },
  "temperature_attempt_counts": {
    "0.25": 3,
    "0.35": 2
  },
  "error_attempts": 0,
  "rejected_reason_counts_final_attempt": {
    "candidate_mojibake_or_encoding_artifact": 1
  },
  "rejected_taxonomy_counts_final_attempt": {
    "malformed_generation": 1
  }
}
```

---

## Interpretation

v0.2.4 passes the regression suite required for the known post-R0.5P-1 audit findings.

The package should still receive aggressive external audit before being used as the base for R0.5P-2.

---

## Non-Claims

This regression report does not claim:

```text
full R0.5 validation
R1 validation
cross-domain correctness
absence of all possible contamination false positives
```

It only confirms that the specific v0.2.4 hardening requirements listed above pass deterministic tests.
