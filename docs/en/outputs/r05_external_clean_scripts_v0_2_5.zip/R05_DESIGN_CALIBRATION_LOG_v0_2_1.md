# R0.5 Design Calibration Log — v0.2.1

Project: SAS / Project Manifold 0.56
Phase: R0.5 external-clean preparation
Date: 2026-06-18

## Purpose

This log records the methodological calibration that led from the original R0.5 external-clean idea to the track-conditioned design used in `v0.2.1`.

The purpose is to preserve traceability, prior-art context, and decision rationale before any large-scale token expenditure.

## Baseline context

R0 established a clean-self infrastructure baseline.
R0-bis established that module dependence/redundancy must be audited before treating modules as independent votes.
R0.5 tests whether the detector remains useful when the clean control is no longer identity/self-copy, but an externally generated `C_clean_equivalent`.

## Initial R0.5 assumption

Initial assumption:

```text
A_clean can be transformed into C_clean_equivalent using a single universal A-only paraphrase prompt.
```

This assumption was rejected during calibration.

## Failure sequence and discoveries

### v0.1.3–v0.1.7

Observed pattern:

- generated candidates often expanded short sources;
- some candidates became solver-like responses;
- 0 accepted candidates appeared repeatedly;
- rejection reasons included:
  - `entity_recall_below_threshold`
  - `external_clean_too_far`
  - `external_clean_too_long`
  - `b_only_contamination`
  - `numbers_or_dates_changed`

Interpretation:

```text
The first failure mode was not evidence that SAS failed.
It showed that C_clean generation was underspecified and category-sensitive.
```

### DeepSeek audit

DeepSeek returned `APPROVE WITH PATCHES` but reported that `include_categories/exclude_categories` were not passed into `source_eligibility_reason()`.

This was later confirmed as a false positive. Local code inspection and later Gemini/Claude audits showed that the category arguments were passed correctly.

### Gemini audit

Gemini confirmed:

- missing explicit API timeout could explain apparent hangs;
- `numbers_preserved` was too literal for word-number/date formatting variants;
- `is_promptlike_source` missed `Q:`, `A:`, and related formats;
- using one universal prompt across all benchmark families was methodologically weak.

### Claude audit

Claude confirmed:

- `APPROVE WITH PATCHES` for a controlled track;
- category filters worked;
- the DeepSeek category bug was a false positive;
- `extract_entities()` had a root-cause blocker: entity regex crossed sentence boundaries and produced false entities such as `Assam. He`;
- generic role nouns such as `Historians`, `Scholars`, `Researchers` could be treated as named entities;
- `unverified claim` could trigger refusal/meta-output false positives;
- promptlike detection missed rationalization/QA patterns such as `Is this mapping consistent with the rule...?`;
- manifests risked leaking absolute Windows paths through `vars(args)`;
- real resume behavior was missing;
- exit code should stop scale-up when real generation ends with 0 accepted.

## v0.2.0 audit-integrated build

`v0.2.0` integrated:

- sentence-split before entity regex;
- expanded STOPWORDS;
- hard/soft refusal split;
- promptlike expansion;
- timeout=45s;
- number/date tolerance;
- manifest sanitization;
- skipped/failure log cleanup;
- resume behavior;
- zero-accepted exit guard.

## Corpus structure discovery

Manual inspection showed that category names alone are insufficient for track assignment.

Observed source forms:

### `halogen/historical_events`

```text
Tell me about the famous meeting between X and Y.
```

This is not declarative historical prose. It is a prompt/query source.

### `halogen/biographies`

```text
Tell me a bio of X
```

This is also prompt-like and carries knowledge-injection risk.

### `halogen/references`

```text
Find relevant scientific or academic references supporting...
```

This is instruction-like and not declarative factual prose.

### `halueval_qa`

```text
Knowledge: ...
Question: ...
Correct answer: ...
```

This is QA source structure.

### `halueval_dialogue`

```text
Knowledge: ...
Dialogue: ...
Correct response: ...
```

This is dialogue-grounded response structure.

### `halueval_summarization`

Long article + correct summary.

### `truthfulqa`

Question + correct answer.

## Track taxonomy after calibration

```text
R0.5P — Prompt / Query Paraphrase
  - halogen/historical_events
  - halogen/biographies
  - halogen/references
  - halogen/code
  - halogen/numerical_falsepresupposition

R0.5Q — QA Source Paraphrase
  - truthfulqa
  - halueval_qa

R0.5D — Dialogue Grounded Response
  - halueval_dialogue

R0.5S — Summarization / Long Context
  - halueval_summarization

R0.5R — Reasoning / Solver-style
  - halogen/rationalization_binary
  - halogen/rationalization_numerical
```

## Historical-events preflight result

With `--skip-promptlike-sources` ON:

```text
raw A files: 21008
eligible after preflight: 0
skipped: 21008
promptlike_or_task_source_skipped: 20196
source_too_short_or_underspecified: 812
```

Conclusion:

```text
The filter worked. The track assumption was wrong.
```

With `--skip-promptlike-sources` OFF for prompt paraphrase:

```text
raw A files: 21008
eligible after preflight: 20196
skipped: 812
selected: 20
```

Conclusion:

```text
halogen/historical_events is usable as R0.5P-1 Historical Query Paraphrase.
```

## v0.2.0 smoke-3 result

Generation on R0.5P-1 without track-specific prompt yielded:

```text
total_selected: 3
accepted: 0
rejected: 3
exit_code: 2
```

Rejected candidates were meta-descriptions such as:

```text
Dataset text regarding interaction between...
Textual reference regarding interaction between...
```

Interpretation:

```text
The model obeyed the inert-dataset prompt too literally.
For prompt-like sources, a prompt must be paraphrased as a prompt, not transformed into a metadescription.
```

## v0.2.1 decision

`v0.2.1` adds a dedicated prompt paraphrase track.

Core principle:

```text
R0.5P requires preserving illocutionary form.
A request must remain a request.
```

## Paper-ready finding

```text
The R0.5 preparation phase showed that external-clean generation is not a single-prompt problem but a track-conditioned data transformation problem. Category labels alone are insufficient; the actual A_clean surface form must be inspected before assigning a source family to factual prose, prompt paraphrase, QA, dialogue, summarization, or reasoning tracks.
```

## Stop rules

No scale-up is allowed after a 0-accepted smoke.

Proceed only when:

- preflight selects expected records;
- smoke-3 returns at least 2/3 accepted;
- rejected private candidates are inspected before alpha-20;
- alpha-20 precedes beta-100;
- beta-100 precedes any 1,200-record run.
