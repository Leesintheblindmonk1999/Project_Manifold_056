# Audit Convergence Matrix — R0.5 v0.2.1

| Finding | DeepSeek | Gemini | Claude | Runtime evidence | Decision |
|---|---:|---:|---:|---:|---|
| `include/exclude-category` broken | Yes | No | No | Local Select-String showed correct passing | False positive from DeepSeek |
| Missing timeout | No | Yes | Yes | v0.2.0 integrated timeout | Keep |
| Universal prompt unsafe | Partial | Yes | Yes | v0.2.0 smoke generated meta-descriptions | Replace with track-conditioned prompts |
| Entity regex crosses sentence boundary | No | No | Yes | Claude reproduced `Assam. He` | Fixed in v0.2.0 |
| Role nouns treated as entities | No | No | Yes | STOPWORDS expanded | Further expanded in v0.2.1 |
| Promptlike detection incomplete | No | Yes | Yes | Historical-events was mostly prompt-like | Use track taxonomy |
| `numbers_preserved` too literal | Partial | Yes | Yes | v0.2.0 improved 0–100 and date variants | Keep |
| B-only contamination from source-contained surnames | No | No | Runtime | `Wildsmith` flagged though `Brian Wildsmith` was in A | Fixed in v0.2.1 |
| Prompt-like source transformed into meta-description | No | No | Runtime | Smoke rejected `Dataset text regarding...` | Added `--track prompt_paraphrase` |
| Absolute path leakage in manifests | No | No | Yes | v0.2.0 sanitized args | Keep |
| 0 accepted should stop run | No | No | Yes | v0.2.0 exit code 2 worked | Keep |
| Category discovery too broad | No | No | Runtime | Full corpus scan on Windows was slow | Use temporary category-scoped corpus; optimize later |

## Current package status

`v0.2.1` is the first package that explicitly distinguishes:

- inert dataset paraphrase;
- prompt/query paraphrase.

It should be used for R0.5P-1 with:

```bash
--track prompt_paraphrase
```
