# R05 DESIGN CALIBRATION LOG v0.2.3

Project: SAS / Project Manifold 0.56
Phase: R0.5P-1 Historical Query Paraphrase
Track: `prompt_paraphrase`
Category: `halogen/historical_events`
Date: 2026-06-18

## Calibration context

R0 established a clean-self infrastructure baseline. R0-bis showed that some baseline modules are dependent and should not be counted as independent votes. R0.5 was then introduced to move from clean-self identity controls toward external-clean equivalents.

The first attempted track was initially assumed to be factual prose, but corpus inspection showed that `halogen/historical_events` contains prompt-like requests, e.g.:

```text
Tell me about the famous meeting between X and Y.
```

This led to the track-conditioned design:

```text
R0.5P-1 Historical Query Paraphrase
```

Objective: generate `C_clean` as a request-equivalent paraphrase, not an answer and not a factual prose rewrite.

## Version trajectory

### v0.2.0

- Implemented cross-audit patches from Claude/Gemini/DeepSeek review.
- Fixed sentence-boundary entity extraction bug (`Assam. He`).
- Added stronger source eligibility checks.
- Added zero-accepted guard.

Observed result on R0.5P-1 smoke-3:

```text
0/3 accepted
```

Rejected candidates were meta-descriptions such as:

```text
Dataset text regarding interaction between X and Y.
```

Conclusion: v0.2.0 was operationally correct but not track-conditioned enough for prompt-like sources.

### v0.2.1

Added `--track prompt_paraphrase` and track-specific generation/verification logic.

Observed results:

```text
smoke-3: 3/3 accepted
alpha-20: 20/20 accepted
beta-100: 99/100 accepted
```

The only beta-100 rejection was traced to mojibake/encoding mutation:

```text
Leif MÃƒÂ¦hle -> Leif MÃ¦hle
```

Decision: do not relax entity invariants; exclude corrupted sources before spending generation tokens.

### v0.2.2

Added mojibake/encoding artifact preflight exclusion.

Observed beta-250 result:

```text
Raw A files: 21,008
Eligible after preflight: 18,964
Skipped by preflight: 2,044
  mojibake_or_encoding_artifact: 1,232
  source_too_short_or_underspecified: 812
Generation accepted: 248/250
Generation rejected: 2/250
Generation errors: 0
Verification accepted: 248/248 generated C files
```

Manual inspection showed both rejections were valid prompt paraphrases falsely rejected by `b_only_contamination`.

### v0.2.3

Verifier-only patch. The generation prompt remains unchanged.

The patch refines `b_only_contamination` so that:

- generic single-token fragments such as `Trade` are not treated as strong B-only contamination;
- single-token entities require token-boundary matches, so `Trade` no longer matches `trader`;
- apostrophe/spacing variants such as `dEmery` / `d'Emery` are recognized as source-covered rather than B-only contamination;
- genuinely new B-only dates, numbers, and non-overlapping entities remain rejected.

## Design principle preserved

R0.5 should avoid two failure modes:

1. accepting corrupted/mutated source entities; and
2. rejecting valid paraphrases because of weak substring artifacts.

v0.2.3 preserves strict source invariants while reducing false positives in the contamination audit.

## Current status after v0.2.3

Ready for repeat beta-250 or beta-500 on R0.5P-1.

Expected effect:

- the two v0.2.2 false positives (`Trade` / `Emery`) should no longer reject valid candidates;
- mojibake sources remain excluded by default under `prompt_paraphrase`;
- prompt generation behavior should remain unchanged.
