# PATCH NOTES v0.2.2 - Mojibake Preflight Hardening

Date: 2026-06-18  
Project: SAS / Project Manifold 0.56  
Package: `r05_external_clean_scripts_v0_2_2.zip`

## Status

`v0.2.2` is a conservative hardening patch over `v0.2.1`.

It does not relax entity preservation. Instead, it excludes sources with visible encoding artifacts before generation when the active track is `prompt_paraphrase`.

## Motivation

`v0.2.1` successfully fixed the v0.2.0 meta-description failure mode:

```text
v0.2.0 smoke-3: 0/3 accepted
v0.2.1 smoke-3: 3/3 accepted
v0.2.1 alpha-20: 20/20 accepted
v0.2.1 beta-100: 99/100 accepted in generation, 99/99 accepted in verification
```

The only beta-100 generation rejection was:

```text
source_path: halogen/historical_events/20297_A_clean.txt
reason: entity_recall_below_threshold
```

The source contained mojibake:

```text
Tell me about the famous meeting between Ellen G. White and Leif MÃƒÂ¦hle.
```

The model returned:

```text
Describe the famous meeting between Ellen G. White and Leif MÃ¦hle.
```

This altered the corrupted entity surface form. The verifier rejected it correctly.

## Design decision

Do not normalize corrupted names during candidate acceptance.

Rationale:

```text
Entity invariants are central to R0.5. Normalizing corrupted entities during verification could hide real entity mutations. The safer choice is to exclude mojibake sources during preflight and document them as data-quality artifacts.
```

## Changes

### 1. Added mojibake detection helpers

In `scripts/r05_common.py`:

```python
MOJIBAKE_PATTERNS = [
    "Ãƒ", "Ã‚", "Ã", "Â", "â€™", "â€œ", "â€�", "â€", "â€“", "â€”", "â€¦", "ï¿½", "�"
]

def mojibake_hits(text: str) -> List[str]: ...
def has_mojibake_artifact(text: str) -> bool: ...
```

### 2. Added preflight reason

```text
mojibake_or_encoding_artifact
```

Skipped rows include:

```json
"mojibake_hits": ["Ãƒ", "Â"]
```

### 3. Added CLI flags

```bash
--skip-mojibake-sources
--allow-mojibake-sources
```

For `--track prompt_paraphrase`, mojibake exclusion is enabled by default unless `--allow-mojibake-sources` is used.

### 4. Added manifest field

```json
"effective_preflight_flags": {
  "skip_mojibake_sources": true
}
```

### 5. Updated script versions

Generation and verification reports now use:

```json
"script_version": "0.2.2"
```

## Expected impact

For `halogen/historical_events`, at least the previously observed source `20297_A_clean.txt` should now be skipped before generation, not rejected after token use.

This may slightly reduce eligible count from the v0.2.1 baseline:

```text
v0.2.1 eligible: 20196
v0.2.2 eligible: expected <= 20195 if only one mojibake source is present in the track
```

## Operational recommendation

Next run should be beta-250, not 1200.

Reason:

```text
v0.2.1 already showed 99/100 generation acceptance and 100% verification acceptance over generated C outputs. v0.2.2 should confirm that the only known beta-100 failure mode is handled by preflight exclusion before scaling further.
```
