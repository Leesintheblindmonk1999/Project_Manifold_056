#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, math
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List
from r05_common import *

def selected_a_files_from_manifest(manifest_path: Path, corpus_dir: Path) -> List[Path]:
    data = read_json(manifest_path)
    out = []
    for rec in data.get("records", []):
        sp = rec.get("source_path")
        if sp:
            out.append(corpus_dir / sp)
    return out

def main() -> int:
    ap = argparse.ArgumentParser(description="Verify R0.5 external-clean corpus. Version 0.2.5.")
    ap.add_argument("--corpus-dir", required=True, type=Path)
    ap.add_argument("--track", choices=["inert_dataset","prompt_paraphrase"], default="inert_dataset")
    ap.add_argument("--external-dir", required=True, type=Path)
    ap.add_argument("--manifest-in", type=Path, default=None)
    ap.add_argument("--report-out", type=Path, default=None)
    ap.add_argument("--a-suffix", default="_A_clean.txt")
    ap.add_argument("--b-suffix", default="_B_hallucination.txt")
    ap.add_argument("--c-suffix", default="_C_clean.txt")
    ap.add_argument("--min-len-ratio", type=float, default=0.70)
    ap.add_argument("--max-len-ratio", type=float, default=1.35)
    ap.add_argument("--min-entity-recall", type=float, default=0.90)
    ap.add_argument("--min-lexical", type=float, default=0.35)
    ap.add_argument("--max-lexical", type=float, default=0.85)
    ap.add_argument("--min-semantic", type=float, default=0.80)
    ap.add_argument("--require-semantic", action="store_true")
    ap.add_argument("--semantic-model", default="sentence-transformers/all-MiniLM-L6-v2")
    ap.add_argument("--allow-semantic-truncation", action="store_true")
    ap.add_argument("--show-failures", action="store_true")
    ap.add_argument("--fail-on-reject", action="store_true")
    args = ap.parse_args()

    corpus_dir = args.corpus_dir.resolve()
    external_dir = args.external_dir.resolve()
    report_out = args.report_out or (external_dir / "verification_report.json")

    if args.manifest_in:
        a_files = selected_a_files_from_manifest(args.manifest_in.resolve(), corpus_dir)
    else:
        a_files = sorted(corpus_dir.rglob(f"*{args.a_suffix}"))

    semantic_model = SemanticModel(args.semantic_model) if args.require_semantic else None
    results = []
    missing = []
    for a_path in a_files:
        rel = a_path.relative_to(corpus_dir)
        c_path = external_dir / rel.parent / (rel.name[:-len(args.a_suffix)] + args.c_suffix)
        if not c_path.exists():
            missing.append(rel.as_posix())
            continue
        a_text = read_text(a_path)
        c_text = read_text(c_path)
        b_path = b_path_for_a(a_path, args.a_suffix, args.b_suffix)
        b_text = read_text(b_path) if b_path.exists() else None
        check = check_candidate(
            a_text, c_text, b_text,
            min_len_ratio=args.min_len_ratio,
            max_len_ratio=args.max_len_ratio,
            min_entity_recall=args.min_entity_recall,
            min_lexical=args.min_lexical,
            max_lexical=args.max_lexical,
            semantic_model=semantic_model,
            min_semantic_warn=args.min_semantic,
            reject_semantic_truncation=args.require_semantic and not args.allow_semantic_truncation,
            allow_semantic_truncation=args.allow_semantic_truncation,
            track=args.track,
        )
        if args.require_semantic and check.semantic_similarity is None:
            check.accepted = False
            check.reasons.append("semantic_similarity_unavailable")
        if args.require_semantic and check.semantic_similarity is not None and check.semantic_similarity < args.min_semantic:
            check.accepted = False
            check.reasons.append("semantic_similarity_below_threshold")
        results.append({
            "source_path":rel.as_posix(),
            "external_path":c_path.relative_to(external_dir).as_posix(),
            "accepted":check.accepted,
            "reasons":check.reasons,
            "warnings":check.warnings,
            "source_sha256":sha256_text(a_text),
            "external_sha256":sha256_text(c_text),
            "b_sha256":sha256_text(b_text),
            **{k:v for k,v in asdict(check).items() if k not in {"accepted","reasons","warnings"}},
        })

    accepted = [r for r in results if r["accepted"]]
    rejected = [r for r in results if not r["accepted"]]
    reason_counts = {}
    taxonomy_counts = {}
    for r in rejected:
        for reason in r.get("reasons", []):
            reason_counts[reason] = reason_counts.get(reason, 0) + 1
        for bucket, count in taxonomize_reasons(r.get("reasons", [])).items():
            taxonomy_counts[bucket] = taxonomy_counts.get(bucket, 0) + count

    report = {
        "manifest_type":"R0_5_external_clean_verification_report",
        "script_version":SCRIPT_VERSION,
        "generated_utc":utc_now(),
        "corpus_dir":corpus_dir.name,
        "external_dir":external_dir.name,
        "manifest_in":args.manifest_in.name if args.manifest_in else None,
        "track":args.track,
        "thresholds":sanitize_args_for_manifest(args),
        "counts":{
            "a_files_found":len(a_files),
            "c_files_found":len(results),
            "missing_c":len(missing),
            "accepted":len(accepted),
            "rejected":len(rejected),
            "acceptance_rate":round(len(accepted)/len(results), 6) if results else 0.0,
        },
        "reason_counts":reason_counts,
        "taxonomy_counts":taxonomy_counts,
        "missing_c_examples":missing[:100],
        "results":results,
    }
    report_out.parent.mkdir(parents=True, exist_ok=True)
    write_json(report_out, report)

    print("\nR0.5 external-clean verification")
    print("--------------------------------")
    print(f"A files found:      {len(a_files)}")
    print(f"C files found:      {len(results)}")
    print(f"Missing C:          {len(missing)}")
    print(f"Accepted:           {len(accepted)}")
    print(f"Rejected:           {len(rejected)}")
    print(f"Acceptance rate:    {report['counts']['acceptance_rate']}")
    print(f"Report:             {report_out}")
    if reason_counts:
        print("\nRejection reasons:")
        for k,v in sorted(reason_counts.items(), key=lambda x: (-x[1], x[0])):
            print(f"  {k}: {v}")
    if taxonomy_counts:
        print("\nRejection taxonomy:")
        for k,v in sorted(taxonomy_counts.items(), key=lambda x: (-x[1], x[0])):
            print(f"  {k}: {v}")
    if args.show_failures and rejected:
        print("\nFailure examples:")
        for r in rejected[:50]:
            print(f"- {r['source_path']} -> {r['reasons']}")
    return 1 if args.fail_on_reject and (rejected or missing) else 0

if __name__ == "__main__":
    raise SystemExit(main())
