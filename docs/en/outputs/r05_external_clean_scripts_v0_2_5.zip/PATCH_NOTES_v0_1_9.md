# PATCH_NOTES_v0_1_9

v0.1.8 was intended to add source eligibility preflight, but the observed console output still showed the old line:

```text
[INFO] discovered eligible A files: 156217
```

That means the generated package did not actually execute the new preflight branch.

## Fix

v0.1.9 is rebuilt from scratch and must print:

```text
[INFO] discovered raw A files: ...
[INFO] eligible A files after v0.1.9 preflight: ...
[INFO] skipped by preflight: ...
[INFO] selected A files for this run: ...
```

## Added/confirmed

- Source eligibility preflight.
- `--skip-promptlike-sources`.
- `--include-category` and `--exclude-category`.
- `--preflight-only`.
- Answer polarity guard.
- Manifest-scoped verification.
- JSON serialization with `default=str`.
