# R0-bis Nonlinear Dependence and Redundancy Audit for SAS/kappa_D-0.56
## A Conservative Clean-Self Baseline Study
**Author:** Gonzalo Emir Durante  
**Project:** SAS / Project Manifold 0.56  
**Version:** v1.0.6 polished layout  
**Status:** Technical manuscript for artifact audit and Zenodo/GitHub release. Not peer reviewed.
> Scope: R0-bis audits nonlinear dependence and redundancy among baseline modules under clean_strategy=self. It is not final SAS/R1 validation.
## Abstract
This paper reports R0-bis, a nonlinear dependence and redundancy audit for SAS/kappa_D-0.56 under clean_strategy=self. Across all three sample sizes, the conservative minimal tribunal selected lexical_drift as the sole representative module. These findings are limited to clean-self controls and require R0.5 external-clean testing before any production-grade or R1 claim.
## CV and held-out F1
| Sample | Records | Train/Test | Selected module | Selected CV F1 | Full CV F1 | Selected test F1 | Full test F1 | Test gap |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2,400 | 2,400 | 1,800/600 | lexical_drift | 0.997768 | 0.998885 | 1.000000 | 1.000000 | 0.000000 |
| 6,000 | 6,000 | 4,500/1,500 | lexical_drift | 0.999629 | 1.000000 | 0.999333 | 0.999333 | 0.000000 |
| 12,000 | 12,000 | 9,000/3,000 | lexical_drift | 0.999184 | 0.999666 | 1.000000 | 0.999667 | -0.000333 |

## Dependence classification counts
| Sample | independent | partial_dependence | redundant_linear | nonlinear_dependence | borderline_dependence |
| --- | --- | --- | --- | --- | --- |
| 2,400 | 6 | 5 | 3 | 1 | 0 |
| 6,000 | 6 | 4 | 3 | 2 | 0 |
| 12,000 | 5 | 4 | 3 | 2 | 1 |

## Held-out validation
| Sample | Selected TN/FP/FN/TP | Selected P/R/F1 | Full TN/FP/FN/TP | Full P/R/F1 |
| --- | --- | --- | --- | --- |
| 2,400 | 300/0/0/300 | 1.000000/1.000000/1.000000 | 300/0/0/300 | 1.000000/1.000000/1.000000 |
| 6,000 | 750/0/1/749 | 1.000000/0.998667/0.999333 | 750/0/1/749 | 1.000000/0.998667/0.999333 |
| 12,000 | 1500/0/0/1500 | 1.000000/1.000000/1.000000 | 1500/0/1/1499 | 1.000000/0.999333/0.999667 |

## Strongest 12k pairs
| Pair | Pearson |r| | Distance corr. | NMI | Class |
| --- | --- | --- | --- | --- |
| entity_drift <-> lexical_drift | 0.967005 | 0.974625 | 0.302834 | redundant_linear |
| length_delta <-> lexical_drift | 0.923308 | 0.934779 | 0.337823 | redundant_linear |
| entity_drift <-> length_delta | 0.874608 | 0.902337 | 0.225139 | redundant_linear |
| density_delta <-> entity_drift | 0.593918 | 0.749954 | 0.206752 | nonlinear_dependence |
| density_delta <-> length_delta | 0.575665 | 0.707559 | 0.193308 | nonlinear_dependence |
| lexical_drift <-> negation_shift | 0.566097 | 0.582583 | 0.119073 | borderline_dependence |

## Conclusion
R0-bis confirms that the baseline module set contains stable linear redundancy and additional nonlinear dependence under clean-self controls. R1 must cluster dependent modules and avoid treating correlated drift signals as independent evidence.
