# CHANGELOG v1.0.6 polished layout

Generated: 2026-06-12T19:39:26.239769+00:00

Scope: presentation/layout repair only.

## What changed

- Rebuilt the paper as a native DOCX instead of a Markdown dump.
- Converted raw Markdown-style tables into formatted Word tables.
- Added a clean title page, scope statement, structured sections, captions, callouts, headers, and footers.
- Preserved all R0-bis numbers and claims from the v1.0.5 audited content.
- Preserved Claude-requested edits: randomly subsampled Distance Correlation wording and negation_shift borderline explanation.

## What did not change

- No code was modified.
- No JSON, CSV, or execution output was modified.
- No frozen output ZIP was modified.
- No numerical claim was changed except formatting/placement.
