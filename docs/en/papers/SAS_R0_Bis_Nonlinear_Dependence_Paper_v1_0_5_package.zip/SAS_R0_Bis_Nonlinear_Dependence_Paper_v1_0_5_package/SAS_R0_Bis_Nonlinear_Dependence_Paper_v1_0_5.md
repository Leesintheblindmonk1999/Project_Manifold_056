# R0-bis Nonlinear Dependence and Redundancy Audit for SAS/kappa_D-0.56: A Conservative Clean-Self Baseline Study
**Author:** Gonzalo Emir Durante  **Project:** SAS / Project Manifold 0.56  **Manuscript version:** v1.0.5-paper  **Generated:** 2026-06-12  **Status:** Technical manuscript for artifact audit and Zenodo/GitHub release. Not peer reviewed.

## Abstract
This paper reports R0-bis, a nonlinear dependence and redundancy audit for SAS/kappa_D-0.56 under clean_strategy=self. The study extends the published R0 infrastructure audit by testing whether six baseline drift modules can be treated as independent evidence votes. Three stratified balanced samples of 2,400, 6,000, and 12,000 records were evaluated with pair-level train/test splitting, repeated stratified cross-validation, Pearson correlation, Spearman correlation, Distance Correlation, and normalized mutual information. Across all three sample sizes, the conservative minimal tribunal selected lexical_drift as the sole representative module. Held-out selected-tribunal F1 was 1.000000, 0.999333, and 1.000000 respectively, while the full six-module baseline obtained 1.000000, 0.999333, and 0.999667. The audit detected stable linear redundancy and nonlinear dependence among baseline modules, showing that R1 must treat correlated modules as evidence clusters rather than independent votes. These findings are limited to clean-self controls and are not final SAS/R1 validation. R0.5 external-clean robustness testing is required before production-grade claims can be made.

**Keywords:** SAS, kappa_D, hallucination auditing, clean-self baseline, nonlinear dependence, Distance Correlation, mutual information, module redundancy, evidence clustering, R0-bis.

## 1. Introduction
SAS/kappa_D-0.56 is being developed as a traceable framework for structural coherence and hallucination auditing in generative AI systems. The prior R0 stage established infrastructure and baseline stability over a large clean-self control setup. R0-bis addresses a narrower but critical methodological question: can baseline modules be counted as independent evidence votes, or do they form correlated clusters that would inflate confidence if treated independently?
The answer matters because an audit system can appear more robust than it is if multiple correlated signals are counted as independent. R0-bis therefore tests linear and nonlinear dependence among baseline modules and applies conservative tribunal selection before any R1 claims are made.

## 2. Artifact basis and reproducibility
This manuscript is derived from two frozen artifacts and one referenced script package. No new model run was performed while writing the paper.

| Artifact | Role | SHA-256 |
|---|---|---|
| sas_r0_bis_technical_report_package_v1_0_4_report_only.zip | Corrected report package used as manuscript source | `4438117968d4568279f8859e3a46b8f943367e91518f06f3b2084eac940fb8f0` |
| sas_r0_bis_v1_0_2_outputs_20260611_191232.zip | Frozen executed R0-bis outputs | `f1f27baab03dd848214070bcc5deb0ce2f8881f1879ec7ace3d8743482f5c3b2` |
| sas_r0_bis_correlation_audit_v1_0_2.zip | Script/reference package used for execution | `8590b153008ae391594efcdb0fdb8607049b7ba31838044cae7b6029fa2cc479` |
| R0 public artifact | Prior infrastructure/baseline reference | `b1c4b2eddc7b887f8721f3f193b5d1263e4822f13efd08f8b20ae95389dd36fe` |

The R0 reference record is https://zenodo.org/records/20647532. The execution manifest records script version 1.0.2, Python 3.13.13, seed 42, sample_size=all, test_size=0.25, cv_folds=5, cv_repeats=3, and require_dcor=True.

## 3. Methods

### 3.1 Experimental status
R0-bis is a clean-self baseline audit. For the clean class, the control strategy is source equals response. This makes the audit useful for infrastructure, dependence, and redundancy analysis, but it can inflate drift-based performance. The experiment must not be interpreted as final R1 validation or production-grade hallucination detection.

### 3.2 Sampling design
Three stratified balanced runs were executed: 2,400, 6,000, and 12,000 records. Each run preserved 12 strata and a 50/50 label balance between clean and hallucination records. Train/test splitting was performed at pair level before held-out validation. Raw source/response text was excluded from exported outputs.

| Sample | Records | Train | Test | Clean records | Hallucination records | Strata |
|---:|---:|---:|---:|---:|---:|---:|
| 2,400 | 2,400 | 1,800 | 600 | 1,200 | 1,200 | 12 |
| 6,000 | 6,000 | 4,500 | 1,500 | 3,000 | 3,000 | 12 |
| 12,000 | 12,000 | 9,000 | 3,000 | 6,000 | 6,000 | 12 |

### 3.3 Baseline modules
The baseline module set contained six drift-oriented modules: density_delta, entity_drift, length_delta, lexical_drift, negation_shift, and numeric_invariant_loss. These are not presented as final SAS R1 modules; they are baseline signals used to test dependence-aware selection.

### 3.4 Dependence analysis
Pairwise module dependence was assessed with Pearson absolute correlation, Spearman correlation, Distance Correlation, and normalized mutual information. Independence for R1 candidate voting required Pearson < 0.60, Distance Correlation < 0.60, and normalized mutual information < 0.60, with a 0.02 borderline threshold margin. Linear, nonlinear, and information redundancy thresholds used 0.85. Partial dependence, nonlinear dependence, redundant pairs, and borderline pairs were blocked from independent vote counting.
Distance Correlation was required for publishable nonlinear dependence claims. In the 12k run only, Distance Correlation was randomly subsampled from 9,000 train records to 5,000 for O(N^2) memory safety; the train split itself is stratified, so the subsample approximately preserves stratum proportions. Pearson, Spearman, and normalized mutual information still used the full 9,000-record train split.

### 3.5 Minimal tribunal selection
A conservative greedy selector evaluated candidate modules using repeated stratified cross-validation on the train split only. Modules that were redundant, partially dependent, nonlinearly dependent, borderline, or otherwise unsafe for independent vote counting were blocked from being counted as independent votes alongside selected representatives. Held-out test metrics were then computed after tribunal selection.

## 4. Results

### 4.1 Execution integrity
The R0-bis run completed successfully for all three sample sizes with dcor enabled and required. No error_report.json was present in the frozen outputs. The v1.0.4 report-only package did not modify code, JSON, CSV, or the frozen v1.0.2 execution outputs.

### 4.2 Minimal tribunal and performance
Across all tested sample sizes, the conservative minimal tribunal selected lexical_drift as the sole representative module.

| Sample | Selected module | Selected CV F1 | Full CV F1 | CV gap | Selected test F1 | Full test F1 | Test gap |
|---:|---|---:|---:|---:|---:|---:|---:|
| 2,400 | lexical_drift | 0.997768 | 0.998885 | 0.001116 | 1.000000 | 1.000000 | 0.000000 |
| 6,000 | lexical_drift | 0.999629 | 1.000000 | 0.000371 | 0.999333 | 0.999333 | 0.000000 |
| 12,000 | lexical_drift | 0.999184 | 0.999666 | 0.000482 | 1.000000 | 0.999667 | -0.000333 |

The selected minimal tribunal was indistinguishable from the full baseline in the 2.4k and 6k held-out tests. In the 12k held-out test, the selected tribunal obtained F1 1.000000 while the full baseline obtained F1 0.999667, corresponding to one false negative over 3,000 held-out records. This difference should not be overclaimed; it is best interpreted as showing no material held-out advantage from the full redundant baseline under clean-self controls.

### 4.3 Held-out confusion matrices

| Sample | Model | TN | FP | FN | TP | Precision | Recall | F1 |
|---:|---|---:|---:|---:|---:|---:|---:|---:|
| 2,400 | Selected | 300 | 0 | 0 | 300 | 1.000000 | 1.000000 | 1.000000 |
| 2,400 | Full baseline | 300 | 0 | 0 | 300 | 1.000000 | 1.000000 | 1.000000 |
| 6,000 | Selected | 750 | 0 | 1 | 749 | 1.000000 | 0.998667 | 0.999333 |
| 6,000 | Full baseline | 750 | 0 | 1 | 749 | 1.000000 | 0.998667 | 0.999333 |
| 12,000 | Selected | 1500 | 0 | 0 | 1500 | 1.000000 | 1.000000 | 1.000000 |
| 12,000 | Full baseline | 1500 | 0 | 1 | 1499 | 1.000000 | 0.999333 | 0.999667 |

### 4.4 Dependence classifications
R0-bis found stable linear redundancy and scale-dependent nonlinear dependence among baseline modules.

| Sample | Independent | Partial dependence | Redundant linear | Nonlinear dependence | Borderline dependence |
|---:|---:|---:|---:|---:|---:|
| 2,400 | 6 | 5 | 3 | 1 | 0 |
| 6,000 | 6 | 4 | 3 | 2 | 0 |
| 12,000 | 5 | 4 | 3 | 2 | 1 |

The stable result across all scales is the presence of three linearly redundant pairs. Nonlinear dependence appears in one pair at 2.4k and two pairs at 6k and 12k, which directly supports the premise that Pearson alone is insufficient for R1 vote independence. The 12k run additionally blocked negation_shift from independent vote counting, because its pair with lexical_drift reached borderline_dependence (Distance Correlation 0.5826, within the 0.02 threshold margin of 0.60). This pair was classified as independent at 2.4k (dcor 0.5763) and 6k (dcor 0.5795), reflecting the scale-sensitivity of borderline classifications near the independence boundary.

### 4.5 Strongest 12k dependent pairs
The 12k run provides the clearest redundancy map.

| Pair | Pearson abs | Distance Corr | NMI | Classification |
|---|---:|---:|---:|---|
| entity_drift - lexical_drift | 0.967005 | 0.974625 | 0.302834 | redundant_linear |
| length_delta - lexical_drift | 0.923308 | 0.934779 | 0.337823 | redundant_linear |
| entity_drift - length_delta | 0.874608 | 0.902337 | 0.225139 | redundant_linear |
| density_delta - entity_drift | 0.593918 | 0.749954 | 0.206752 | nonlinear_dependence |
| density_delta - length_delta | 0.575665 | 0.707559 | 0.193308 | nonlinear_dependence |
| lexical_drift - negation_shift | 0.566097 | 0.582583 | 0.119073 | borderline_dependence |

The entity_drift, length_delta, and lexical_drift modules form a linear-redundant cluster. The correct R1 implication is not that lexical_drift should be excluded; rather, entity_drift and length_delta must not be counted as independent votes alongside lexical_drift when that representative is selected.

## 5. Discussion
R0-bis changes the interpretation of the baseline system from multi-module strength to clustered evidence. A six-module baseline can appear more diversified than it is if entity, length, lexical, and density-related drift signals are treated as independent. The dependence audit shows that conservative evidence clustering is necessary before R1.
The consistent selection of lexical_drift is expected under clean-self controls: clean responses are identical to their sources, so lexical drift is naturally strong. This is not evidence that lexical_drift is sufficient under external-clean paraphrase controls. Instead, the result identifies a baseline ceiling and motivates R0.5, where clean controls must preserve factual content while changing lexical surface form.
The strategic value of R0-bis is therefore negative-control discipline. It prevents overcounting correlated baseline modules and sets stricter requirements for future SAS modules such as source_target_guard_score, TDA-based structure scores, NIG-based scores, contradiction and grounding modules, temporal consistency modules, and category-conditioned tribunals.

## 6. Limitations
The central limitation is clean_strategy=self. The negative class uses source equals response, which can inflate drift-based separation. Therefore, R0-bis should be cited as a nonlinear dependence and redundancy audit, not as final hallucination detection validation.
Additional limits include: baseline modules are not the final SAS R1 module set; the minimal tribunal result is conditioned on self-clean controls; the 12k selected-vs-full difference corresponds to only one false negative; and external clean paraphrase controls have not yet been executed.

## 7. R0.5 and R1 roadmap
The next phase is R0.5 external-clean robustness testing. The proposed R0.5 design must generate C_clean_equivalent responses using A-only generation, verify A-C equivalence, and use B_hallucination only as a post-generation contamination antigen. This design tests whether lexical drift fails on semantically equivalent paraphrases while structure-aware SAS modules remain stable.
R1 should only proceed after R0.5. It should use real SAS modules, locked or nested validation, dependence-aware clustering, module observability, and evidence bundles. Correlated modules must be clustered and treated as supporting evidence, not independent votes.

## 8. Conclusion
R0-bis v1.0.2, reported through the v1.0.4 report-only package, successfully executed a clean-self nonlinear dependence and redundancy audit over 2.4k, 6k, and 12k stratified balanced samples. The audit found stable linear redundancy and nonlinear dependence among baseline modules. The conservative minimal tribunal selected lexical_drift across all sample sizes and did not lose held-out performance relative to the full six-module baseline under clean-self controls.
The main conclusion is methodological: SAS/R1 must use dependence-aware evidence clustering. R0-bis does not validate final SAS performance, but it strengthens the scientific foundation by preventing redundant baseline votes from being mistaken for independent evidence.

## References and artifact references
1. Gonzalo Emir Durante. R0 Infrastructure and Baseline Stability Audit for SAS/kappa_D-0.56. Zenodo record: https://zenodo.org/records/20647532.
2. sas_r0_bis_v1_0_2_outputs_20260611_191232.zip. Frozen R0-bis execution outputs. SHA-256: f1f27baab03dd848214070bcc5deb0ce2f8881f1879ec7ace3d8743482f5c3b2.
3. sas_r0_bis_technical_report_package_v1_0_4_report_only.zip. Corrected report-only package. SHA-256: 4438117968d4568279f8859e3a46b8f943367e91518f06f3b2084eac940fb8f0.
4. sas_r0_bis_correlation_audit_v1_0_2.zip. Script/reference package. SHA-256: 8590b153008ae391594efcdb0fdb8607049b7ba31838044cae7b6029fa2cc479.

## Appendix A. Reproducibility command context
The frozen run manifest records command-equivalent settings: sample_size=all, seed=42, input_jsonl=full_benchmark.jsonl, require_dcor=true, test_size=0.25, max_dependence_n=5000, cv_folds=5, cv_repeats=3, tribunal_gap_tolerance=0.005, and external_clean=false.
