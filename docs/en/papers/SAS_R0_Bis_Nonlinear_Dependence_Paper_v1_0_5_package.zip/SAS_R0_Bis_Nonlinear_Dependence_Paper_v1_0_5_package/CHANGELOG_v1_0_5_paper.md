# CHANGELOG v1.0.5-paper

Generated: 2026-06-12T18:13:57.978828+00:00

Scope: paper-only minor corrections after Claude PDF audit. No code, JSON, CSV, or frozen outputs were modified.

## Corrections

1. Replaced `stratified-subsampled` with `randomly subsampled` for the 12k Distance Correlation memory-safety subsample. Added the clarification that the train split itself is stratified.

2. Added an explanation for why `negation_shift` is blocked at 12k but not at 2.4k/6k: the `lexical_drift` x `negation_shift` pair reaches `borderline_dependence` at 12k with Distance Correlation 0.5826, within the 0.02 margin around 0.60.

## Invariant artifacts

- R0-bis outputs ZIP SHA-256: `f1f27baab03dd848214070bcc5deb0ce2f8881f1879ec7ace3d8743482f5c3b2`
- R0-bis report package v1.0.4 SHA-256: `4438117968d4568279f8859e3a46b8f943367e91518f06f3b2084eac940fb8f0`

