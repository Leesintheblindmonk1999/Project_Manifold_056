# SAS Research Code-Only Pack — v0.3 multi-audit hardened

This package integrates Claude + ChatGPT + DeepSeek audit feedback.

## v0.3 highlights

- Supports independent clean negatives via `--clean_strategy external --clean_responses_dir`.
- Keeps `clean_strategy=self` only as infrastructure baseline.
- Adds per-record `execution_time_sec`.
- Adds CV fold scores and standard deviations.
- Adds optional `--normalize` for final validation.
- Exports `test_confusion_matrix.json`.
- Includes `docs/DEEPSEEK_AUDIT_VERDICT.md`.

## Publishability rule

Results produced only with `clean_strategy=self` should be treated as infrastructure validation, not final R1 evidence. For stronger R0/R1 claims, use independent clean negatives with `--clean_strategy external`.

---

# SAS Research Code-Only Pack

Este paquete contiene solo código y estructura de carpetas para ejecutar pruebas R0 sobre tu `benchmark_corpus` local.

No incluye el benchmark pesado.

## Dónde va cada cosa

Opción recomendada:

```text
SAS/
└── sas_research/
    ├── R0_correlation_audit/
    ├── R1_tribunal_multimetrico/
    ├── R2_theta_kappa_bridge/
    ├── R3_temporal_consistency/
    ├── experimental/
    └── tools/
```

También podés copiar `R0_correlation_audit/`, `experimental/` y `tools/` directamente dentro del repo principal SAS si preferís.

## Flujo R0 local

Tu corpus local tiene esta forma mixta:

```text
benchmark_corpus/
├── halogen/
│   ├── biographies/
│   │   ├── 0000_A_clean.txt
│   │   └── 0000_B_hallucination.txt
│   └── ...
├── halueval_dialogue/
│   ├── 0000_A_clean.txt
│   └── 0000_B_hallucination.txt
└── ...
```

Primero verificá el corpus:

```bash
python tools/verify_benchmark_corpus.py --corpus_dir "C:/Users/conno/Downloads/SAS-Semantico/benchmark_corpus"
```

Después convertí a JSONL:

```bash
python R0_correlation_audit/scripts/benchmark_corpus_to_jsonl.py ^
  --corpus_dir "C:/Users/conno/Downloads/SAS-Semantico/benchmark_corpus" ^
  --out R0_correlation_audit/data/full_benchmark.jsonl
```

Crear split train/test:

```bash
cd R0_correlation_audit
python scripts/00_create_split.py --benchmark data/full_benchmark.jsonl --seed 42
```

Correr módulos baseline aislados:

```bash
python scripts/01_run_isolated.py --split data/splits/train.jsonl --registry baseline
python scripts/01_run_isolated.py --split data/splits/test.jsonl --registry baseline
```

Correlación y ablation:

```bash
python scripts/02_correlation_matrix.py --scores_dir results/module_scores
python scripts/03_marginal_contribution.py
python scripts/04_validate_test.py --yes
```

## Importante

Los módulos `baseline` son heurísticas simples para probar la infraestructura R0. No reemplazan los módulos reales de SAS.

Para conectar SAS real, editá:

```text
R0_correlation_audit/scripts/module_registry.py
```

y agregá wrappers que llamen a los módulos reales del backend.

## Estado esperado

```text
benchmark_corpus_to_jsonl.py  -> genera full_benchmark.jsonl
00_create_split.py            -> genera train/test inmutables
01_run_isolated.py            -> genera train_*.jsonl y test_*.jsonl
02_correlation_matrix.py      -> genera matrices de correlación
03_marginal_contribution.py   -> genera tribunal_candidates.json
04_validate_test.py           -> genera test_validation.json
```
