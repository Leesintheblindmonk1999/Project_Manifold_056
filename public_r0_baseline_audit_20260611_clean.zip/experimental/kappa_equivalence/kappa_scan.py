#!/usr/bin/env python
"""Safe AST κD equivalence scanner.

Detects expressions equivalent to κD = 0.56 within tolerance.
Does not execute arbitrary code.
"""

from __future__ import annotations

import argparse
import ast
import json
import math
import operator as op
from pathlib import Path

KAPPA_D = 0.56
TOLERANCE = 1e-12

OPERATORS = {
    ast.Add: op.add,
    ast.Sub: op.sub,
    ast.Mult: op.mul,
    ast.Div: op.truediv,
    ast.Pow: op.pow,
    ast.USub: op.neg,
    ast.UAdd: op.pos,
}

FUNCTIONS = {
    "sqrt": math.sqrt,
    "log": math.log,
    "log10": math.log10,
    "exp": math.exp,
    "pow": pow,
}

CONSTANTS = {
    "pi": math.pi,
    "e": math.e,
}


class UnsafeExpression(ValueError):
    pass


def check_complexity(tree: ast.AST, max_nodes=80, max_depth=20):
    nodes = list(ast.walk(tree))
    if len(nodes) > max_nodes:
        raise UnsafeExpression(f"Expression too large: {len(nodes)} nodes")

    def depth(node):
        children = list(ast.iter_child_nodes(node))
        if not children:
            return 1
        return 1 + max(depth(c) for c in children)

    d = depth(tree)
    if d > max_depth:
        raise UnsafeExpression(f"Expression too deep: {d}")


def safe_eval(node: ast.AST) -> float:
    if isinstance(node, ast.Expression):
        return safe_eval(node.body)

    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return float(node.value)

    if isinstance(node, ast.Name) and node.id in CONSTANTS:
        return float(CONSTANTS[node.id])

    if isinstance(node, ast.UnaryOp) and type(node.op) in OPERATORS:
        return float(OPERATORS[type(node.op)](safe_eval(node.operand)))

    if isinstance(node, ast.BinOp) and type(node.op) in OPERATORS:
        left = safe_eval(node.left)
        right = safe_eval(node.right)
        return float(OPERATORS[type(node.op)](left, right))

    if isinstance(node, ast.Call):
        if not isinstance(node.func, ast.Name):
            raise UnsafeExpression("Only direct whitelisted function calls are allowed")
        if node.func.id not in FUNCTIONS:
            raise UnsafeExpression(f"Function not allowed: {node.func.id}")
        args = [safe_eval(arg) for arg in node.args]
        return float(FUNCTIONS[node.func.id](*args))

    raise UnsafeExpression(f"Unsupported AST node: {type(node).__name__}")


def classify_family(expr: str) -> str:
    lower = expr.lower()
    if "/" in expr and not any(x in lower for x in ["log", "sqrt", "exp"]):
        return "fraction_or_division"
    if any(x in lower for x in ["sqrt", "**", "pow"]):
        return "root_power"
    if any(x in lower for x in ["log", "exp"]):
        return "log_exp"
    if "+" in expr or "-" in expr:
        return "additive"
    if "*" in expr:
        return "multiplicative"
    return "literal_or_other"


def scan_expression(expr: str, tolerance: float = TOLERANCE) -> dict:
    tree = ast.parse(expr, mode="eval")
    check_complexity(tree)
    value = safe_eval(tree)
    return {
        "expression": expr,
        "evaluated_value": value,
        "canonical_value": KAPPA_D,
        "tolerance": tolerance,
        "is_kappa_equivalent": bool(abs(value - KAPPA_D) <= tolerance),
        "near_threshold_055_057": bool(0.55 <= value <= 0.57),
        "method": "safe_ast_eval",
        "matched_family": classify_family(expr),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("expression", nargs="?", help="Expression to scan")
    parser.add_argument("--file", help="Optional file containing one expression per line")
    parser.add_argument("--tolerance", type=float, default=TOLERANCE)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    expressions = []
    if args.expression:
        expressions.append(args.expression)
    if args.file:
        with Path(args.file).open(encoding="utf-8") as f:
            expressions.extend(line.strip() for line in f if line.strip() and not line.startswith("#"))

    if not expressions:
        raise SystemExit("Provide an expression or --file")

    results = []
    for expr in expressions:
        try:
            results.append(scan_expression(expr, args.tolerance))
        except Exception as exc:
            results.append({"expression": expr, "error": repr(exc), "is_kappa_equivalent": False})

    if args.json:
        print(json.dumps(results, indent=2, ensure_ascii=False))
    else:
        for res in results:
            if "error" in res:
                print(f"[ERROR] {res['expression']}: {res['error']}")
            else:
                flag = "KAPPA" if res["is_kappa_equivalent"] else "NO"
                print(f"[{flag}] {res['expression']} -> {res['evaluated_value']}")


if __name__ == "__main__":
    main()
