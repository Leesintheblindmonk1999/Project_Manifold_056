#!/usr/bin/env python
"""R3 temporal consistency skeleton.

Consumes a JSON conversation and produces placeholder pair indices.
Real ISI integration should be added only after R1.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--conversation_json", required=True)
    parser.add_argument("--out", default="temporal_consistency_result.json")
    args = parser.parse_args()

    conversation = json.loads(Path(args.conversation_json).read_text(encoding="utf-8"))
    assistant_turns = [
        (i, t.get("content", ""))
        for i, t in enumerate(conversation)
        if t.get("role") == "assistant"
    ]

    result = {
        "n_turns": len(conversation),
        "n_assistant_turns": len(assistant_turns),
        "candidate_pairs": [
            {"turn_i": a[0], "turn_j": b[0]}
            for idx, a in enumerate(assistant_turns)
            for b in assistant_turns[idx + 1:]
        ],
        "status": "skeleton_only",
        "warning": "Contradiction scoring requires ISI or R1 tribunal integration.",
    }

    Path(args.out).write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
