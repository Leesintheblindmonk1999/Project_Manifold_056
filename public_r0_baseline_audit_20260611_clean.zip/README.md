# R0 Baseline Stability Audit — Public Curated Artifact

Date: 2026-06-11  
Project: SAS / Project Manifold 0.56  
Mode: clean-self control  
Seed: 42  
Discovered complete A/B pairs: 152,525  
Generated local clean-self records: 305,050  

## What this artifact contains

This curated package contains scripts, documentation, manifests, aggregate metrics, correlation summaries, confusion matrices, findings, and error-analysis summaries.

## What this artifact intentionally excludes

Raw benchmark texts and generated JSONL files containing full `source` / `response` text are excluded.

Excluded examples:

- `full_benchmark.jsonl`
- `sample_*.jsonl`
- `sample_strat_*.jsonl`
- `data/splits/*.jsonl`
- archived run split JSONL files
- per-record module-score JSONL files

## Stratified baseline runs

| Run | Records | Pairs/category | Train/Test | Minimal module | Minimal F1 | Full F1 | Gap |
|---|---:|---:|---:|---|---:|---:|---:|
| sample_strat_2400 | 2,400 | 100 | 1,800 / 600 | lexical_drift | 0.9983 | 1.0000 | 0.0017 |
| sample_strat_6000 | 6,000 | 250 | 4,500 / 1,500 | lexical_drift | 0.9987 | 1.0000 | 0.0013 |
| sample_strat_12000 | 12,000 | 500 | 9,000 / 3,000 | entity_drift | 0.9993 | 1.0000 | 0.0007 |

## Interpretation

This is an R0 infrastructure and baseline-stability audit. It validates reproducible local execution, stratified sampling, module-correlation analysis, minimal-tribunal selection, runtime logging, and error analysis under a clean-self control condition.

It does **not** claim final production-grade SAS/R1 validation.

## Key limitation

`clean_strategy=self` creates negative controls as:

```text
source = A_clean
response = A_clean
```

This can inflate detection performance and should be interpreted as an infrastructure baseline, not final R1 evidence.

## Next steps

- connect real SAS modules to `module_registry.py`;
- repeat stratified R0 with SAS modules;
- use independent clean negatives with `clean_strategy=external`;
- prepare R1 multimetric tribunal evaluation.
