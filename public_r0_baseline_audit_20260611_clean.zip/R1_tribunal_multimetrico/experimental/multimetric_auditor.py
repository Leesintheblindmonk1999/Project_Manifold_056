#!/usr/bin/env python
"""Experimental R1 multimetric auditor skeleton.

Do not expose as stable API until R0 confirms metric independence and thresholds.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List


@dataclass
class MetricSignal:
    name: str
    score: float
    threshold: float
    direction: str = "above"  # "above" means score > threshold signals rupture

    @property
    def signal(self) -> bool:
        if self.direction == "above":
            return self.score > self.threshold
        if self.direction == "below":
            return self.score < self.threshold
        raise ValueError(f"Unknown direction: {self.direction}")

    @property
    def margin(self) -> float:
        if self.direction == "above":
            return self.score - self.threshold
        return self.threshold - self.score


def multimetric_verdict(metrics: List[MetricSignal], min_signals: int = 3) -> Dict:
    signals = [m for m in metrics if m.signal]
    agreement = len(signals) / max(len(metrics), 1)
    avg_margin = sum(max(m.margin, 0.0) for m in metrics) / max(len(metrics), 1)
    dispersion = 0.0
    if metrics:
        mean_score = sum(m.score for m in metrics) / len(metrics)
        dispersion = sum((m.score - mean_score) ** 2 for m in metrics) / len(metrics)

    if len(signals) >= min_signals:
        verdict = "INESTABLE"
    elif len(signals) >= 1:
        verdict = "REVIEW"
    else:
        verdict = "STABLE"

    confidence = max(0.0, min(1.0, (agreement * 0.6) + (avg_margin * 0.4) - (dispersion * 0.1)))

    return {
        "verdict": verdict,
        "confidence": confidence,
        "min_signals": min_signals,
        "n_metrics": len(metrics),
        "n_signals": len(signals),
        "metrics": {
            m.name: {
                "score": m.score,
                "threshold": m.threshold,
                "direction": m.direction,
                "signal": m.signal,
                "margin": m.margin,
            }
            for m in metrics
        },
        "warning": "Experimental skeleton. Thresholds must be calibrated in R1.",
    }
