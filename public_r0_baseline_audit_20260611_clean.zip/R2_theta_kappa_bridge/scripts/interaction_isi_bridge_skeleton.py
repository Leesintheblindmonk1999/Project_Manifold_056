#!/usr/bin/env python
"""R2 exploratory skeleton for comparing interaction stability and ISI.

This script is a placeholder for later use with interaction.db exports.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_csv", required=True,
                        help="CSV with columns: sigma_t, chi_t, isi_t")
    parser.add_argument("--out", default="r2_bridge_summary.json")
    args = parser.parse_args()

    df = pd.read_csv(args.input_csv)
    required = {"sigma_t", "chi_t", "isi_t"}
    missing = required - set(df.columns)
    if missing:
        raise SystemExit(f"Missing columns: {sorted(missing)}")

    summary = {
        "n": int(len(df)),
        "pearson_sigma_isi": float(df["sigma_t"].corr(df["isi_t"], method="pearson")),
        "pearson_chi_isi": float(df["chi_t"].corr(df["isi_t"], method="pearson")),
        "status": "exploratory",
        "warning": "Do not claim equivalence between Ω_t and ISI_t without held-out validation.",
    }
    Path(args.out).write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
