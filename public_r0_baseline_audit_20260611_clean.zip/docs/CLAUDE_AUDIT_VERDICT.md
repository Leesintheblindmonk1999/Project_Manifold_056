# External Audit Verdict — Claude Review

**Reviewed package:** `sas_research_code_only.zip`  
**Integrated package:** `sas_research_code_only_v0_2_audit_integrated.zip`  
**Audit status:** Passed for local testing with required documentation and minor fixes  
**Benchmark included:** No  
**Purpose:** Preserve external audit findings and integrate them into the R0 execution plan.

---

## 1. Executive Summary

The external audit concluded:

```text
The package is apt for local testing with the synthetic corpus without modifications.
For the real corpus, there are 2 mandatory fixes and 1 important methodological limitation that must be documented before scientific interpretation.
No security problems were found.
The R0 infrastructure works end-to-end.
The bugs found are minor and do not block execution, but they affect output quality if not corrected.
```

This v0.2 audit-integrated package incorporates those findings.

---

## 2. Security Verdict

The audit found no meaningful security risk.

| Vector | Result |
|---|---|
| `eval()` / `exec()` | Not present |
| `subprocess` / `os.system` | Not present |
| Network calls | Not present |
| Destructive deletion | Not present |
| Hardcoded credentials | Not present |
| `.env` / private keys | Not present |
| Arbitrary code execution in `kappa_scan.py` | Not found |

`kappa_scan.py` uses `ast.parse(expr, mode="eval")` only for parsing and then evaluates through a restricted whitelist of nodes, operators, functions, and constants.

---

## 3. Core Methodological Concern

### CONCERN-1 — Clean-self negative controls inflate F1

With:

```text
--clean_strategy self
```

negative samples are created as:

```text
A_clean → A_clean
```

This means:

```text
source == response
```

for label `0`.

Any module measuring difference between source and response may separate classes trivially.

Examples:

```text
lexical_drift
entity_drift
length_delta
numeric_invariant_loss
```

The external audit confirmed that these baseline modules can reach `F1=1.0` in the synthetic test due to this construction.

### Decision

The clean-self strategy is accepted only as:

```text
infrastructure baseline
negative-control smoke test
pipeline verification
```

It must not be presented as:

```text
production-grade validation
final R1 module selection
real-world generalization
```

unless stronger independent clean negatives are added.

---

## 4. Bugs and Fixes Integrated

### BUG-1 — UndefinedMetricWarning noise

Affected files:

```text
03_marginal_contribution.py
04_validate_test.py
```

Problem:

```text
precision_score() and recall_score() emitted warnings when a model predicted only one class.
```

Integrated fix:

```text
zero_division=0
```

was added through sklearn scorers and final validation metrics.

---

### BUG-2 — Relative findings path in validator

Affected file:

```text
04_validate_test.py
```

Problem:

```text
findings_dir = Path("findings")
```

depended on the current working directory.

Integrated fix:

```python
findings_dir = Path(__file__).resolve().parent.parent / "findings"
```

This ensures findings are written to:

```text
R0_correlation_audit/findings/
```

regardless of whether the command is executed from the R0 root or scripts folder.

---

### BUG-3 — Absolute local paths in JSONL

Affected file:

```text
benchmark_corpus_to_jsonl.py
```

Problem:

```json
"clean_file": "C:/Users/..."
"hallucination_file": "C:/Users/..."
```

could leak local filesystem paths if the JSONL is published.

Integrated fix:

```text
clean_file and hallucination_file are now stored relative to corpus_dir.
```

Example:

```json
{
  "clean_file": "halogen/biographies/0000_A_clean.txt",
  "hallucination_file": "halogen/biographies/0000_B_hallucination.txt"
}
```

---

## 5. Additional Improvement Integrated

### Constant-feature warning suppression

The correlation script may produce warnings when a module returns constant scores.

This is expected for weak or inactive modules.

The updated version suppresses the specific sklearn warning:

```text
Feature 0 is constant
```

inside the Mutual Information discretization scope only.

---

## 6. Final Classification

| Category | Result |
|---|---|
| `research_scaffold` | valid |
| `benchmark_converter` | valid |
| `r0_execution_ready` | partial |
| `sas_real_module_integration` | partial |
| `safe_to_run_locally` | yes |

---

## 7. Execution Decision

```text
Apto para prueba local.
```

Synthetic demo:

```text
OK to run.
```

Real corpus:

```text
OK to run after documenting clean-self limitations and preserving benchmark manifest.
```

Scientific interpretation:

```text
Do not treat clean-self R0 results as production-grade R1 selection evidence.
```

---

## 8. Integrated Status

This package integrates:

```text
BUG-1 fixed
BUG-2 fixed
BUG-3 fixed
CONCERN-1 documented
clean-self warning added to conversion manifest
R0 documentation updated
issue tracker updated
ground truth definition added
```
