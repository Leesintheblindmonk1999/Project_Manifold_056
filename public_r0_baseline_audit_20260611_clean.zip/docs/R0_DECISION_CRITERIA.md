# R0 Decision Criteria

**Project:** SAS — Symbiotic Autoprotection System  
**Phase:** R0 Correlation Audit  
**Pre-registration:** DOI `10.5281/zenodo.20573121`  
**Status:** Audit-integrated decision rules

---

## 1. Core Decision Table

| Resultado | Decisión |
|-----------|----------|
| ≥ 3 módulos con ρ < 0.60 | Avanzar a R1 con los módulos independientes identificados. |
| Tribunal mínimo viable F1 > 0.95 con ≤ 3 módulos | R1 se simplifica. Validar el mínimo. |
| F1 mínimo < F1 pipeline completo − 0.05 | Documentar tradeoff. El tribunal mínimo puede no ser óptimo. |
| ρ > 0.85 entre todos los pares | No avanzar a R1 con módulos actuales. Activar IDEA-01/02 y R0-bis. |
| Detección de leakage o negativos débiles | Corregir dataset antes de publicar resultados. |

---

## 2. Clean-Self Override Rule

If R0 uses:

```text
A_clean → A_clean
```

as the main negative-control strategy, then performance metrics must be classified as:

```text
infrastructure baseline
```

unless an independent clean-negative validation is also provided.

Even if F1 is high, clean-self results alone cannot justify production R1 module selection.

---

## 3. Required Evidence Before R1

R1 requires:

```text
frozen split metadata
module score files
Pearson matrix
Spearman matrix
Mutual Information matrix
Distance Correlation matrix
marginal contribution report
held-out test validation
leakage check note
ground truth definition
clean-negative limitation note
decision note
```

---

## 4. R0-bis Activation Rule

Activate R0-bis if:

```text
all modules are highly correlated
clean-self negatives dominate performance
data leakage is detected
ground truth is insufficiently defined
module outputs are unstable
benchmark is too small or too narrow
```

R0-bis should revise:

```text
module set
dataset construction
negative-control strategy
ground truth definition
sampling procedure
threshold calibration
```

---

## 5. Publication Language

If R0 succeeds with strong negatives:

```text
R0 supports advancement toward R1 under the pre-registered criteria. Results indicate that a subset of SAS modules provides partially independent evidence for structural rupture detection.
```

If R0 succeeds only with clean-self negatives:

```text
R0 validates the infrastructure and preliminary module behavior under a clean-self baseline. These results are not treated as production-grade R1 selection evidence until independent clean negatives are evaluated.
```

If R0 is inconclusive:

```text
R0 did not provide sufficient evidence to justify R1 promotion with the current module set. The project will proceed with Plan B / R0-bis before making stronger claims.
```

If leakage or weak negatives are detected:

```text
R0 identified methodological risks in dataset construction. Results are retained for internal audit but are not used as external validation until the dataset is corrected.
```
