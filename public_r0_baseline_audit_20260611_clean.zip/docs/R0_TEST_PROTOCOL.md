# R0 Correlation Audit — Test Protocol

**Project:** SAS — Symbiotic Autoprotection System  
**Phase:** R0 Correlation Audit  
**Pre-registration:** DOI `10.5281/zenodo.20573121`  
**Roadmap alignment:** Roadmap v4 — Research-to-API Translation Layer  
**Status:** Audit-integrated execution protocol  
**Package:** `sas_research_code_only_v0_2_audit_integrated.zip`

---

## 1. Objective

R0 evaluates whether candidate SAS modules provide independent evidence for structural rupture / hallucination detection, or whether the current module family is too redundant to justify R1 Tribunal Multimétrico.

R0 does not prove the full SAS standard. It answers a narrower methodological question:

> Do candidate SAS modules provide enough independent signal to justify advancing toward R1?

---

## 2. Expected Corpus Structure

Expected benchmark target:

```text
2,000 paired samples
├── 1,000 hallucination / rupture cases
└── 1,000 clean / non-rupture controls
```

Registered split target:

```text
train/calibration: 1,500 samples
test/held-out:      500 samples
```

The split must be created once and treated as immutable after generation.

---

## 3. Expected Local Layout

Nested example:

```text
benchmark_corpus/
└── halogen/
    └── biographies/
        ├── 0000_A_clean.txt
        └── 0000_B_hallucination.txt
```

Direct examples:

```text
benchmark_corpus/
├── halueval_dialogue/
│   ├── 0000_A_clean.txt
│   └── 0000_B_hallucination.txt
├── halueval_general/
├── halueval_qa/
├── halueval_summarization/
└── truthfulqa/
```

The converter must recursively pair:

```text
*_A_clean.txt
*_B_hallucination.txt
```

---

## 4. Baseline Strategy: Clean-Self

For each complete A/B pair:

```text
A_clean → B_hallucination
```

is treated as a positive rupture case.

The initial negative-control baseline is:

```text
A_clean → A_clean
```

This is called **clean-self**.

### 4.1 Clean-self limitation

External audit identified clean-self as the main methodological concern.

Because clean-self creates:

```text
source == response
```

for label `0`, modules based on source/response dissimilarity may separate classes too easily.

Therefore clean-self R0 results must be interpreted as:

```text
infrastructure validation
baseline control
pipeline smoke test
```

not as:

```text
production-grade validation
final R1 module-selection evidence
real-world generalization
```

unless independent clean negatives are added.

---

## 5. Candidate SAS Modules

R0 targets:

```text
TDA
NIG
negation_probe
SourceTargetGuard
flow_coherence
E9
E10
E11
E12
```

Each module must run in isolation and output:

```json
{
  "pair_id": "string",
  "module": "string",
  "score": 0.0,
  "label": 0,
  "corpus": "string",
  "category": "string",
  "evidence": {},
  "error": null
}
```

---

## 6. Correlation Metrics

R0 uses:

```text
Pearson correlation
Spearman correlation
Mutual Information
Distance Correlation
```

Primary thresholds:

```text
ρ < 0.60  → potential independent evidence
ρ > 0.85  → high redundancy warning
```

Non-linear dependence warning:

```text
abs(Pearson) < 0.30
and
Distance Correlation > 0.40
```

---

## 7. Marginal Contribution

Procedure:

1. Evaluate each module independently on train.
2. Select strongest individual module.
3. Add module with highest marginal F1 gain.
4. Repeat until gain is negligible.
5. Freeze selected tribunal.
6. Read held-out test only after selection is frozen.
7. Compare minimal tribunal vs full pipeline.

---

## 8. Decision Criteria

| Result | Decision |
|---|---|
| ≥ 3 modules or module pairs with ρ < 0.60 | Advance to R1 with identified independent modules. |
| Minimal viable tribunal F1 > 0.95 with ≤ 3 modules | Simplify R1. Validate the minimum. |
| Minimal tribunal F1 < full pipeline F1 − 0.05 | Document tradeoff. |
| ρ > 0.85 between all module pairs | Do not advance to R1. Activate IDEA-01/02 and R0-bis. |
| Leakage or weak negatives detected | Correct dataset before publishing. |

---

## 9. Example Commands

### Install dependencies

```bash
pip install -r requirements-r0.txt
```

### Synthetic demo

```bash
cd R0_correlation_audit
python scripts/make_synthetic_demo.py --out data/demo_benchmark.jsonl --n 80
python scripts/00_create_split.py --benchmark data/demo_benchmark.jsonl --seed 42 --force
python scripts/01_run_isolated.py --split data/splits/train.jsonl --registry baseline
python scripts/01_run_isolated.py --split data/splits/test.jsonl --registry baseline
python scripts/02_correlation_matrix.py
python scripts/03_marginal_contribution.py
python scripts/04_validate_test.py --yes
```

### Verify real corpus without converting

```bash
python tools/verify_benchmark_corpus.py \
  --corpus_dir "ruta/a/tu/benchmark_corpus" \
  --show_missing
```

### Convert real corpus

```bash
python R0_correlation_audit/scripts/benchmark_corpus_to_jsonl.py \
  --corpus_dir "ruta/a/tu/benchmark_corpus" \
  --out R0_correlation_audit/data/full_benchmark.jsonl \
  --clean_strategy self
```

### Create frozen split

```bash
cd R0_correlation_audit

python scripts/00_create_split.py \
  --benchmark data/full_benchmark.jsonl \
  --seed 42 \
  --test_ratio 0.25
```

### Run real SAS modules after wrappers are connected

```bash
python scripts/01_run_isolated.py --split data/splits/train.jsonl --registry sas
python scripts/01_run_isolated.py --split data/splits/test.jsonl --registry sas
```

### Correlation + contribution + final validation

```bash
python scripts/02_correlation_matrix.py --scores_dir results/module_scores
python scripts/03_marginal_contribution.py
python scripts/04_validate_test.py --yes
```

---

## 10. Risks

Main risks:

```text
benchmark circularity
clean-self negative inflation
small or narrow corpus
ambiguous ground truth
train/test leakage
duplicate samples
overinterpreting baseline heuristics
```

Mitigation:

```text
freeze split
preserve manifest
document clean-self limitation
avoid test during selection
report limitations
do not publish clean-self results as production validation
```

---

## 11. Publication Rule

Do not publish R0 as external validation unless:

```text
code audit is complete
corpus manifest is preserved
split is frozen
clean-self limitation is disclosed
leakage checks are documented
correlation matrices are published
R1 / Plan B decision is stated
```

---

## External Clean Negative Mode

For publishable R0/R1-oriented evidence, prefer independent clean negatives:

```bash
python R0_correlation_audit/scripts/benchmark_corpus_to_jsonl.py \
  --corpus_dir "ruta/a/benchmark_corpus" \
  --clean_strategy external \
  --clean_responses_dir "ruta/a/clean_responses" \
  --out R0_correlation_audit/data/full_benchmark.jsonl
```

Clean-self mode remains available only for infrastructure validation:

```bash
--clean_strategy self
```

Validation can optionally normalize module scores:

```bash
python scripts/04_validate_test.py --yes --normalize
```

The validator now exports:

```text
results/test_confusion_matrix.json
```

