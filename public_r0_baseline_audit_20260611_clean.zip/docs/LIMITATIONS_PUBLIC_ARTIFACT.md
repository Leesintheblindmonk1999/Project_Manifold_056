# Limitations

This public artifact is intentionally conservative.

## Clean-self limitation

The reported runs use `clean_strategy=self`, where clean controls use identical source and response text. This is useful for infrastructure validation and module-behavior analysis, but it may inflate F1 for dissimilarity-based modules.

## Dataset redistribution limitation

Raw benchmark text and generated JSONL files containing full source/response text are not included in this public artifact. This avoids redistributing corpus content without a separate license review.

## Valid claim boundary

Supported:

- reproducible R0 infrastructure;
- stratified sampling over discovered corpus categories;
- module-correlation behavior;
- minimal vs full baseline comparison;
- runtime and error-analysis traces.

Not supported yet:

- final production-grade SAS validation;
- R1 tribunal validation;
- claims based on independent clean negatives.
