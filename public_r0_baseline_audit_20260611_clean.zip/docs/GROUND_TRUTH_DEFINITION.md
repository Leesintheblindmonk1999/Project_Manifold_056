# Ground Truth Definition — R0 Correlation Audit

**Project:** SAS — Symbiotic Autoprotection System  
**Phase:** R0  
**Purpose:** Define labels, negative controls, and publication boundaries.

---

## 1. Positive Label

### Label 1 — Hallucination / Structural Rupture

A sample is labeled `1` when:

```text
source = A_clean
response = B_hallucination
```

The response contains one or more of:

- factual mutation;
- entity substitution;
- number/date mutation;
- contradiction against source;
- unsupported claim;
- semantic rupture;
- structural inconsistency.

---

## 2. Negative Labels

### 2.1 Clean-self negative

A sample is labeled `0` with clean-self when:

```text
source = A_clean
response = A_clean
```

This is useful for:

```text
infrastructure validation
baseline control
smoke testing
```

but can inflate F1 because:

```text
source == response
```

Any dissimilarity module may separate clean-self negatives trivially.

### 2.2 External clean negative

A sample is labeled `0` with external clean response when:

```text
source = A_clean
response = C_clean
```

or another independently verified clean response.

This is preferred for:

```text
publishable R0 evidence
R1 module selection
generalization claims
```

---

## 3. Implementation

Clean-self mode:

```bash
--clean_strategy self
```

External clean mode:

```bash
--clean_strategy external --clean_responses_dir "ruta/a/clean_responses"
```

Supported external clean filenames:

```text
<prefix>_C_clean.txt
<prefix>_B_clean.txt
<prefix>_clean_response.txt
<prefix>_response_clean.txt
<prefix>.txt
```

---

## 4. Required Disclosure

If using clean-self:

```text
Negative controls were generated using clean_strategy=self, where A_clean is used as both source and response. This is an infrastructure baseline and may inflate F1. It is not treated as production-grade R1 selection evidence.
```

If using external clean responses:

```text
Negative controls used independent clean responses from clean_responses_dir. The response differs from the source while preserving the clean/non-rupture label.
```

---

## 5. Publication Constraint

Clean-self only:

```text
publish as preliminary infrastructure audit only
```

External clean negatives:

```text
eligible for stronger R0/R1 interpretation, subject to leakage and ground-truth checks
```
