# R0 Correlation Audit — Pending Issues

---

## A. Audit integration

- [x] Audit code-only pack before execution.
- [x] Confirm no destructive file operations.
- [x] Confirm no network calls during R0 execution.
- [x] Confirm no unsafe `eval`, `exec`, `os.system`, or uncontrolled `subprocess`.
- [x] Confirm `kappa_scan.py` uses safe AST evaluation only.
- [x] Fix BUG-1: add `zero_division=0`.
- [x] Fix BUG-2: make validator findings path independent of CWD.
- [x] Fix BUG-3: remove absolute local paths from JSONL outputs.
- [x] Document CONCERN-1: clean-self may inflate F1.

---

## B. Unit tests

- [ ] Add unit tests for benchmark converter.
- [ ] Add unit tests for recursive corpus discovery.
- [ ] Add unit tests for missing A/B pair detection.
- [ ] Add unit tests for JSONL output schema.
- [ ] Add unit tests for split reproducibility.
- [ ] Add unit tests for module score output format.
- [ ] Add unit tests for correlation JSON serialization.
- [ ] Add unit tests for κD AST equivalence scanner.

---

## C. Corpus validation

- [ ] Verify local `benchmark_corpus` structure.
- [ ] Count complete A/B pairs.
- [ ] Count missing B files.
- [ ] Count B files without matching A.
- [ ] Generate corpus manifest.
- [ ] Generate `full_benchmark.jsonl`.
- [ ] Confirm approximately 2,000 records.
- [ ] Confirm label balance.
- [ ] Confirm category distribution.
- [ ] Document corpus source and construction rules.

---

## D. Negative-control strategy

- [x] Mark current clean-self strategy as baseline-only.
- [x] Document limitation of clean-self negatives.
- [ ] Define clean negative strategy beyond `A_clean -> A_clean`.
- [ ] Evaluate whether independent clean responses are available.
- [ ] Decide whether R0-bis requires stronger negative controls.
- [ ] Add duplicate/leakage detector.

---

## E. SAS module integration

- [ ] Connect real SAS modules through `module_registry.py`.
- [ ] Add wrapper for TDA.
- [ ] Add wrapper for NIG.
- [ ] Add wrapper for `negation_probe`.
- [ ] Add wrapper for `SourceTargetGuard`.
- [ ] Add wrapper for `flow_coherence`.
- [ ] Add wrapper for E9.
- [ ] Add wrapper for E10.
- [ ] Add wrapper for E11.
- [ ] Add wrapper for E12.
- [ ] Normalize module score outputs.
- [ ] Preserve evidence payloads.
- [ ] Record module errors without stopping full execution.

---

## F. Staged execution

- [ ] Run synthetic demo.
- [ ] Run R0 on 20-pair sample.
- [ ] Inspect outputs from 20-pair sample.
- [ ] Run R0 on 200-pair sample.
- [ ] Inspect outputs from 200-pair sample.
- [ ] Freeze full benchmark split.
- [ ] Run full R0 benchmark.
- [ ] Preserve logs from each execution stage.

---

## G. Correlation and contribution analysis

- [ ] Generate Pearson correlation matrix.
- [ ] Generate Spearman correlation matrix.
- [ ] Generate Mutual Information matrix.
- [ ] Generate Distance Correlation matrix.
- [ ] Publish correlation matrix with confidence intervals.
- [ ] Identify module pairs with ρ < 0.60.
- [ ] Identify module pairs with ρ > 0.85.
- [ ] Flag possible non-linear dependence.
- [ ] Run marginal contribution analysis.
- [ ] Freeze selected tribunal before reading test.

---

## H. Final validation and publication

- [ ] Validate selected tribunal on held-out test.
- [ ] Compare minimal tribunal F1 against full pipeline F1.
- [ ] Check whether minimal tribunal F1 > 0.95 with ≤ 3 modules.
- [ ] Check whether minimal tribunal F1 < full pipeline F1 − 0.05.
- [ ] Write `FINDING_R0_RESULT.md`.
- [ ] Publish decision on R1.
- [ ] If needed, activate Plan B / R0-bis.
- [ ] Archive final R0 artifact bundle.

---

## K. DeepSeek audit integration

- [x] Implement `--clean_responses_dir`.
- [x] Implement `--clean_strategy external`.
- [x] Add `--allow_missing_external_clean`.
- [x] Add `execution_time_sec` to module score rows.
- [x] Add per-module runtime metadata.
- [x] Add CV fold scores and standard deviations.
- [x] Add optional validation normalization.
- [x] Add test confusion matrix export.
- [x] Document external clean negative strategy.
- [ ] Run synthetic demo on v0.3.
- [ ] Run 20-pair sample on v0.3.
- [ ] Run 200-pair sample on v0.3.
- [ ] Run full corpus with `clean_strategy external` if clean responses are available.
