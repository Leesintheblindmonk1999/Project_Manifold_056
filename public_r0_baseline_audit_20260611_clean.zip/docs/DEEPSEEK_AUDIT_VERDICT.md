# External Audit Verdict — DeepSeek Review

**Reviewed package:** `sas_research_code_only_v0_2_audit_integrated.zip`  
**Integrated package:** `sas_research_code_only_v0_3_multi_audit_hardened.zip`  
**Status:** Multi-audit hardening integrated  
**Benchmark included:** No

---

## 1. Executive Summary

DeepSeek's verdict:

```text
The code is safe, functional, and faithfully reproduces the pre-registered methodology.
The limitations are well documented.
There are no blockers to executing R0 with the real corpus, as long as warnings about clean_strategy=self are respected.
However, 3 mandatory improvements and 5 strategic recommendations should be integrated before publishing results.
```

This package integrates those improvements.

---

## 2. Security Confirmation

| Vector | Status |
|---|---|
| `eval()` / `exec()` | Not present |
| `subprocess` / `os.system` | Not present |
| Network calls | Not present |
| Destructive writes | Not present |
| Absolute paths in JSONL | Fixed |
| Credentials / `.env` | Not present |
| `kappa_scan.py` arbitrary code execution | Not found |

Security verdict:

```text
Clean. Safe for local execution.
```

---

## 3. Methodological Confirmation

The audit confirmed that the package aligns with R0/R1 pre-registration:

- frozen train/test split;
- isolated module execution;
- Pearson / Spearman / MI / Distance Correlation;
- Pearson confidence intervals;
- greedy marginal contribution on train only;
- final validation on held-out test;
- clean-self limitation documented.

---

## 4. Improvements Integrated

### MEJORA-1 — Independent clean negatives

Implemented:

```text
--clean_responses_dir
--clean_strategy external
--allow_missing_external_clean
```

This allows negative controls such as:

```text
A_clean → C_clean
```

instead of only:

```text
A_clean → A_clean
```

Recommended publishable mode:

```bash
python R0_correlation_audit/scripts/benchmark_corpus_to_jsonl.py \
  --corpus_dir "ruta/a/benchmark_corpus" \
  --clean_strategy external \
  --clean_responses_dir "ruta/a/clean_responses" \
  --out R0_correlation_audit/data/full_benchmark.jsonl
```

Clean-self remains available for infrastructure testing:

```bash
--clean_strategy self
```

but must be reported as baseline-only.

---

### MEJORA-2 — Structured execution time

Implemented in:

```text
R0_correlation_audit/scripts/01_run_isolated.py
```

Each module-score row now includes:

```json
{
  "execution_time_sec": 0.000123
}
```

Run metadata also includes per-module timing:

```json
{
  "module_runtime_sec": {
    "module_name": {
      "total": 0.0,
      "mean_per_record": 0.0,
      "min_per_record": 0.0,
      "max_per_record": 0.0,
      "ok": 0,
      "err": 0
    }
  }
}
```

---

### MEJORA-3 — Cross-validation fold details

Implemented in:

```text
R0_correlation_audit/scripts/03_marginal_contribution.py
```

The output now includes:

```text
f1_mean
f1_std
f1_folds
precision_mean
precision_std
precision_folds
recall_mean
recall_std
recall_folds
```

---

## 5. Strategic Recommendations Integrated

### Optional normalization

Implemented in:

```text
R0_correlation_audit/scripts/04_validate_test.py
```

Use:

```bash
python scripts/04_validate_test.py --yes --normalize
```

This applies:

```text
StandardScaler + LogisticRegression
```

### Confusion matrix export

Implemented in:

```text
results/test_confusion_matrix.json
```

and embedded into:

```text
findings/FINDING_R0_RESULT.md
```

### Manifest regeneration

`tools/generate_code_manifest.py` remains available and captures all files under the package root, including documentation, when run from the package root.

### Clean-self publication guard

Documentation now separates:

```text
infrastructure R0
```

from:

```text
publishable R0/R1 evidence
```

### External clean response mode

Independent clean responses are now supported for stronger R0 evidence.

---

## 6. Final Integrated Verdict

| Category | Result |
|---|---|
| Security | Clean |
| Local execution | Ready |
| Synthetic demo | Ready |
| Real corpus infrastructure run | Ready |
| Publishable R0 with clean-self only | Not recommended |
| Publishable R0 with independent clean negatives | Supported by v0.3 |
| R1 evidence | Requires external clean negatives or additional validation |

Final status:

```text
v0.3 is ready for staged R0 execution.
```
