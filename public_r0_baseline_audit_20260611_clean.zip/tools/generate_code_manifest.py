#!/usr/bin/env python
"""Generate SHA-256 manifest for this code-only pack."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--out", default="CODE_MANIFEST.json")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    entries = []
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.name != Path(args.out).name:
            rel = path.relative_to(root).as_posix()
            data = path.read_bytes()
            entries.append({
                "path": rel,
                "sha256": hashlib.sha256(data).hexdigest(),
                "size_bytes": len(data),
            })

    master_input = "\n".join(f"{e['sha256']}  {e['path']}" for e in entries).encode("utf-8")
    manifest = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "root": str(root),
        "algorithm": "SHA-256",
        "master_digest": hashlib.sha256(master_input).hexdigest(),
        "files": entries,
    }
    Path(args.out).write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {args.out}")
    print(f"Master digest: {manifest['master_digest']}")


if __name__ == "__main__":
    main()
