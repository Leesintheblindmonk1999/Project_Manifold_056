#!/usr/bin/env python
"""Verify mixed SAS benchmark corpus layout without loading it into memory.

Supports:
  benchmark_corpus/halogen/<category>/0000_A_clean.txt
  benchmark_corpus/halueval_dialogue/0000_A_clean.txt
  benchmark_corpus/<any>/<prefix>_A_clean.txt

Pairs are discovered recursively by matching:
  *_A_clean.txt  <->  *_B_hallucination.txt
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from pathlib import Path


def discover_pairs(corpus_dir: Path):
    a_files = sorted(corpus_dir.rglob("*_A_clean.txt"))
    pairs = []
    missing_b = []

    for a_path in a_files:
        b_path = a_path.with_name(a_path.name.replace("_A_clean.txt", "_B_hallucination.txt"))
        rel_parent = a_path.parent.relative_to(corpus_dir)
        parts = rel_parent.parts
        corpus = parts[0] if parts else "root"
        category = "/".join(parts[1:]) if len(parts) > 1 else "direct"

        record = {
            "prefix": a_path.name.replace("_A_clean.txt", ""),
            "a_path": a_path,
            "b_path": b_path,
            "corpus": corpus,
            "category": category,
            "has_b": b_path.exists(),
        }
        pairs.append(record)
        if not b_path.exists():
            missing_b.append(record)

    b_files = sorted(corpus_dir.rglob("*_B_hallucination.txt"))
    b_without_a = []
    for b_path in b_files:
        a_path = b_path.with_name(b_path.name.replace("_B_hallucination.txt", "_A_clean.txt"))
        if not a_path.exists():
            rel_parent = b_path.parent.relative_to(corpus_dir)
            parts = rel_parent.parts
            b_without_a.append({
                "prefix": b_path.name.replace("_B_hallucination.txt", ""),
                "b_path": b_path,
                "corpus": parts[0] if parts else "root",
                "category": "/".join(parts[1:]) if len(parts) > 1 else "direct",
            })

    return pairs, missing_b, b_without_a


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--corpus_dir", required=True, help="Path to benchmark_corpus")
    parser.add_argument("--show_missing", action="store_true")
    args = parser.parse_args()

    corpus_dir = Path(args.corpus_dir)
    if not corpus_dir.exists():
        raise SystemExit(f"Corpus dir not found: {corpus_dir}")

    pairs, missing_b, b_without_a = discover_pairs(corpus_dir)
    complete = [p for p in pairs if p["has_b"]]

    by_corpus = Counter(p["corpus"] for p in complete)
    by_category = Counter(f'{p["corpus"]}/{p["category"]}' for p in complete)

    print("=" * 72)
    print("SAS benchmark corpus verification")
    print("=" * 72)
    print(f"Corpus dir:       {corpus_dir}")
    print(f"A clean files:    {len(pairs)}")
    print(f"Complete A/B:     {len(complete)}")
    print(f"Missing B files:  {len(missing_b)}")
    print(f"B without A:      {len(b_without_a)}")

    print("\nBy corpus:")
    for k, v in sorted(by_corpus.items()):
        print(f"  {k}: {v} complete pairs")

    print("\nBy category:")
    for k, v in sorted(by_category.items()):
        print(f"  {k}: {v}")

    if args.show_missing:
        if missing_b:
            print("\nMissing B examples:")
            for item in missing_b[:50]:
                print(f"  {item['a_path']}")
        if b_without_a:
            print("\nB without A examples:")
            for item in b_without_a[:50]:
                print(f"  {item['b_path']}")


if __name__ == "__main__":
    main()
