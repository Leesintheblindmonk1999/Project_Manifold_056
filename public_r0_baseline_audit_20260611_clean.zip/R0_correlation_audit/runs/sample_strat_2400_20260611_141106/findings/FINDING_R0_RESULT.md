# R0 Test Validation Result

Generated: 2026-06-11T17:10:33.413037+00:00

Selected modules: `['lexical_drift']`

Normalize: `False`

Minimal tribunal F1: `0.9983`

Full pipeline F1: `1.0000`

F1 gap: `0.0017`

## Minimal Tribunal Confusion Matrix

`{'labels': [0, 1], 'matrix': [[300, 0], [1, 299]], 'tn': 300, 'fp': 0, 'fn': 1, 'tp': 299}`

## Full Pipeline Confusion Matrix

`{'labels': [0, 1], 'matrix': [[300, 0], [0, 300]], 'tn': 300, 'fp': 0, 'fn': 0, 'tp': 300}`

