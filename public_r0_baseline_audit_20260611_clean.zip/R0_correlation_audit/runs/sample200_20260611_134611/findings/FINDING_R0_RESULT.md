# R0 Test Validation Result

Generated: 2026-06-11T16:45:41.149489+00:00

Selected modules: `['entity_drift']`

Normalize: `False`

Minimal tribunal F1: `1.0000`

Full pipeline F1: `1.0000`

F1 gap: `0.0000`

## Minimal Tribunal Confusion Matrix

`{'labels': [0, 1], 'matrix': [[25, 0], [0, 25]], 'tn': 25, 'fp': 0, 'fn': 0, 'tp': 25}`

## Full Pipeline Confusion Matrix

`{'labels': [0, 1], 'matrix': [[25, 0], [0, 25]], 'tn': 25, 'fp': 0, 'fn': 0, 'tp': 25}`

