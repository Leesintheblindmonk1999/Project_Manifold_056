# R0 Test Validation Result

Generated: 2026-06-11T17:15:02.353797+00:00

Selected modules: `['lexical_drift']`

Normalize: `False`

Minimal tribunal F1: `0.9987`

Full pipeline F1: `1.0000`

F1 gap: `0.0013`

## Minimal Tribunal Confusion Matrix

`{'labels': [0, 1], 'matrix': [[750, 0], [2, 748]], 'tn': 750, 'fp': 0, 'fn': 2, 'tp': 748}`

## Full Pipeline Confusion Matrix

`{'labels': [0, 1], 'matrix': [[750, 0], [0, 750]], 'tn': 750, 'fp': 0, 'fn': 0, 'tp': 750}`

