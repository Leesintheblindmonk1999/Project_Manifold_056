# R0 Test Validation Result

Generated: 2026-06-11T16:37:38.496962+00:00

Selected modules: `['entity_drift']`

Normalize: `False`

Minimal tribunal F1: `1.0000`

Full pipeline F1: `1.0000`

F1 gap: `0.0000`

## Minimal Tribunal Confusion Matrix

`{'labels': [0, 1], 'matrix': [[2, 0], [0, 2]], 'tn': 2, 'fp': 0, 'fn': 0, 'tp': 2}`

## Full Pipeline Confusion Matrix

`{'labels': [0, 1], 'matrix': [[2, 0], [0, 2]], 'tn': 2, 'fp': 0, 'fn': 0, 'tp': 2}`

