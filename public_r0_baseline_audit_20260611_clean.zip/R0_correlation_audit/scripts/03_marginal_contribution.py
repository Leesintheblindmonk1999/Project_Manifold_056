#!/usr/bin/env python
"""R0 Step 3: Marginal contribution via greedy forward selection.

Stores mean, standard deviation, and per-fold CV scores for reproducibility.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score, precision_score, recall_score, make_scorer
from sklearn.model_selection import StratifiedKFold, cross_val_score


def load_scores(scores_dir: Path, split_prefix: str = "train") -> pd.DataFrame:
    dfs = []
    for f in sorted(scores_dir.glob(f"{split_prefix}_*.jsonl")):
        module_name = f.stem.replace(f"{split_prefix}_", "")
        records = []
        with f.open(encoding="utf-8") as fh:
            for line in fh:
                row = json.loads(line)
                if row.get("score") is not None:
                    records.append(
                        {
                            "pair_id": row["pair_id"],
                            "label": int(row["label"]),
                            module_name: float(row["score"]),
                        }
                    )
        if records:
            dfs.append(pd.DataFrame(records).set_index("pair_id"))

    if not dfs:
        raise RuntimeError(f"No score files found in {scores_dir}")

    df = dfs[0]
    for other in dfs[1:]:
        df = df.join(other.drop(columns=["label"], errors="ignore"), how="inner")
    return df.dropna()


def safe_cv(y, max_cv=5):
    counts = pd.Series(y).value_counts()
    min_class = int(counts.min())
    return max(2, min(max_cv, min_class))


def evaluate_combination(df: pd.DataFrame, modules: list) -> dict:
    x = df[modules].values
    y = df["label"].values
    cv_n = safe_cv(y)
    model = LogisticRegression(max_iter=1000, random_state=42)
    cv = StratifiedKFold(n_splits=cv_n, shuffle=True, random_state=42)

    f1_scorer = make_scorer(f1_score, zero_division=0)
    precision_scorer = make_scorer(precision_score, zero_division=0)
    recall_scorer = make_scorer(recall_score, zero_division=0)

    f1_scores = cross_val_score(model, x, y, cv=cv, scoring=f1_scorer)
    precision_scores = cross_val_score(model, x, y, cv=cv, scoring=precision_scorer)
    recall_scores = cross_val_score(model, x, y, cv=cv, scoring=recall_scorer)

    return {
        "modules": modules,
        "n_modules": len(modules),
        "cv": cv_n,
        "f1_mean": float(f1_scores.mean()),
        "f1_std": float(f1_scores.std()),
        "f1_folds": [float(v) for v in f1_scores],
        "precision_mean": float(precision_scores.mean()),
        "precision_std": float(precision_scores.std()),
        "precision_folds": [float(v) for v in precision_scores],
        "recall_mean": float(recall_scores.mean()),
        "recall_std": float(recall_scores.std()),
        "recall_folds": [float(v) for v in recall_scores],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scores_dir", default="results/module_scores")
    parser.add_argument("--out_dir", default="results")
    parser.add_argument("--improvement_threshold", type=float, default=0.005)
    args = parser.parse_args()

    scores_dir = Path(args.scores_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    df = load_scores(scores_dir, "train")
    modules = [c for c in df.columns if c != "label"]

    results = []
    individual = {}
    print("=" * 72)
    print("Individual module F1")
    print("=" * 72)
    for module in modules:
        ev = evaluate_combination(df, [module])
        individual[module] = ev["f1_mean"]
        results.append({**ev, "step": 0, "added_module": module, "marginal_gain": None})
        print(f"{module}: F1={ev['f1_mean']:.4f} ± {ev['f1_std']:.4f}")

    selected = []
    remaining = list(modules)
    best_f1 = 0.0
    step = 1

    print("\nGreedy forward selection")
    print("=" * 72)
    while remaining:
        best_candidate = None
        best_ev = None
        best_gain = -1.0

        for candidate in remaining:
            trial = selected + [candidate]
            ev = evaluate_combination(df, trial)
            gain = ev["f1_mean"] - best_f1
            if gain > best_gain:
                best_candidate = candidate
                best_ev = ev
                best_gain = gain

        if best_candidate is None or best_gain < args.improvement_threshold:
            print(f"Stop: no module improves F1 by >= {args.improvement_threshold}")
            break

        selected.append(best_candidate)
        remaining.remove(best_candidate)
        best_f1 = best_ev["f1_mean"]
        results.append(
            {**best_ev, "step": step, "added_module": best_candidate, "marginal_gain": float(best_gain)}
        )
        print(
            f"Step {step}: +{best_candidate} "
            f"F1={best_f1:.4f} ± {best_ev['f1_std']:.4f} gain={best_gain:.4f}"
        )
        step += 1

    if not selected:
        selected = [max(individual, key=individual.get)]

    pd.DataFrame(results).to_csv(out_dir / "marginal_contribution.csv", index=False)
    candidates = {
        "selected_modules": selected,
        "all_modules": modules,
        "individual_f1": individual,
        "improvement_threshold": args.improvement_threshold,
        "cv_results": results,
        "note": "Selected on train split only. Test split must remain unseen until 04_validate_test.py.",
    }
    (out_dir / "tribunal_candidates.json").write_text(
        json.dumps(candidates, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    print("\nSelected modules:", selected)
    print(f"Outputs: {out_dir / 'marginal_contribution.csv'}, {out_dir / 'tribunal_candidates.json'}")


if __name__ == "__main__":
    main()
