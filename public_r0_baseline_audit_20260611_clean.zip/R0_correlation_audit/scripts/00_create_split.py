#!/usr/bin/env python
"""R0 Step 0: Create immutable train/test split.

Run before any module analysis.
"""

from __future__ import annotations

import argparse
import json
import random
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


def read_jsonl(path: Path):
    with path.open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def write_jsonl(path: Path, records):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for rec in records:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--benchmark", required=True, help="Path to full benchmark JSONL")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--test_ratio", type=float, default=0.25)
    parser.add_argument("--out_dir", default="data/splits")
    parser.add_argument("--force", action="store_true",
                        help="Overwrite existing split. Use only before seeing module results.")
    args = parser.parse_args()

    benchmark = Path(args.benchmark)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    train_path = out_dir / "train.jsonl"
    test_path = out_dir / "test.jsonl"
    meta_path = out_dir / "split_meta.json"

    if train_path.exists() and not args.force:
        raise RuntimeError(
            f"Split already exists at {train_path}. "
            "Use --force only if no module results have been inspected."
        )

    pairs = read_jsonl(benchmark)
    if not pairs:
        raise RuntimeError(f"No records found in {benchmark}")

    by_label = {}
    for rec in pairs:
        label = int(rec.get("label"))
        by_label.setdefault(label, []).append(rec)

    rng = random.Random(args.seed)
    train = []
    test = []

    label_counts = {}
    for label, records in sorted(by_label.items()):
        rng.shuffle(records)
        n_test = int(len(records) * args.test_ratio)
        test_part = records[:n_test]
        train_part = records[n_test:]
        test.extend(test_part)
        train.extend(train_part)
        label_counts[str(label)] = {
            "total": len(records),
            "train": len(train_part),
            "test": len(test_part),
        }

    rng.shuffle(train)
    rng.shuffle(test)

    write_jsonl(train_path, train)
    write_jsonl(test_path, test)

    meta = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "benchmark_source": str(benchmark),
        "seed": args.seed,
        "test_ratio": args.test_ratio,
        "total": len(pairs),
        "train_total": len(train),
        "test_total": len(test),
        "label_counts": label_counts,
        "train_labels": dict(Counter(int(r["label"]) for r in train)),
        "test_labels": dict(Counter(int(r["label"]) for r in test)),
        "warning": "Immutable split. Do not regenerate after inspecting module outputs.",
    }
    meta_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")

    print("=" * 72)
    print("R0 split created")
    print("=" * 72)
    print(f"Total: {len(pairs)}")
    print(f"Train: {len(train)}")
    print(f"Test:  {len(test)}")
    print(f"Seed:  {args.seed}")
    print(f"Files: {train_path}, {test_path}, {meta_path}")


if __name__ == "__main__":
    main()
