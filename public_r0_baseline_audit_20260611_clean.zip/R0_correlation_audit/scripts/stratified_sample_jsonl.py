﻿#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import random
from collections import defaultdict, Counter
from pathlib import Path


def process_group(group, reservoirs, counts, pairs_per_category, rng):
    if not group:
        return

    labels = {int(r.get("label")) for r in group}
    if labels != {0, 1}:
        return

    first = group[0]
    category_key = f"{first.get('corpus')}/{first.get('category')}"
    counts[category_key] += 1
    n = counts[category_key]

    if len(reservoirs[category_key]) < pairs_per_category:
        reservoirs[category_key].append(group)
    else:
        j = rng.randint(1, n)
        if j <= pairs_per_category:
            reservoirs[category_key][j - 1] = group


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--pairs_per_category", type=int, default=100)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    rng = random.Random(args.seed)
    input_path = Path(args.input)
    out_path = Path(args.out)
    manifest_path = out_path.with_suffix(".manifest.json")

    reservoirs = defaultdict(list)
    counts = Counter()

    current_pair_id = None
    current_group = []

    with input_path.open("r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue

            rec = json.loads(line)
            pair_group_id = rec.get("pair_group_id") or rec.get("pair_id")

            if current_pair_id is None:
                current_pair_id = pair_group_id

            if pair_group_id != current_pair_id:
                process_group(
                    current_group,
                    reservoirs,
                    counts,
                    args.pairs_per_category,
                    rng,
                )
                current_pair_id = pair_group_id
                current_group = []

            current_group.append(rec)

    process_group(
        current_group,
        reservoirs,
        counts,
        args.pairs_per_category,
        rng,
    )

    selected_groups = []
    for category_key in sorted(reservoirs):
        selected_groups.extend(reservoirs[category_key])

    rng.shuffle(selected_groups)

    out_path.parent.mkdir(parents=True, exist_ok=True)

    label_counts = Counter()
    category_counts = Counter()
    records_written = 0
    pairs_written = 0

    with out_path.open("w", encoding="utf-8") as f:
        for group in selected_groups:
            pairs_written += 1
            first = group[0]
            category_key = f"{first.get('corpus')}/{first.get('category')}"
            category_counts[category_key] += 1

            for rec in group:
                label_counts[str(rec.get("label"))] += 1
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
                records_written += 1

    manifest = {
        "input": str(input_path),
        "out": str(out_path),
        "seed": args.seed,
        "pairs_per_category_target": args.pairs_per_category,
        "pairs_seen_by_category": dict(sorted(counts.items())),
        "pairs_written_by_category": dict(sorted(category_counts.items())),
        "pairs_written": pairs_written,
        "records_written": records_written,
        "label_counts": dict(sorted(label_counts.items())),
        "note": "Stratified reservoir sample by corpus/category, preserving label 0/1 pair groups.",
    }

    manifest_path.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    print("=" * 72)
    print("Stratified sample created")
    print("=" * 72)
    print(f"Input:              {input_path}")
    print(f"Output:             {out_path}")
    print(f"Pairs/category:     {args.pairs_per_category}")
    print(f"Pairs written:      {pairs_written}")
    print(f"Records written:    {records_written}")
    print(f"Label counts:       {dict(sorted(label_counts.items()))}")
    print(f"Manifest:           {manifest_path}")
    print()
    print("Pairs written by category:")
    for k, v in sorted(category_counts.items()):
        print(f"  {k}: {v}")


if __name__ == "__main__":
    main()
