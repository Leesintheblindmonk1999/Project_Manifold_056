﻿#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score, precision_score, recall_score, confusion_matrix


def read_jsonl(path: Path):
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                yield json.loads(line)


def load_split(path: Path) -> pd.DataFrame:
    rows = []
    for r in read_jsonl(path):
        rows.append({
            "pair_id": r.get("pair_id") or r.get("id"),
            "label": int(r["label"]),
            "corpus": r.get("corpus"),
            "category": r.get("category"),
            "prefix": r.get("prefix"),
            "clean_file": r.get("clean_file"),
            "hallucination_file": r.get("hallucination_file"),
        })
    return pd.DataFrame(rows)


def load_scores(scores_dir: Path, split: str, modules: list[str]) -> pd.DataFrame:
    df = None
    for module in modules:
        path = scores_dir / f"{split}_{module}.jsonl"
        rows = []
        for r in read_jsonl(path):
            rows.append({
                "pair_id": r["pair_id"],
                module: float(r["score"]) if r.get("score") is not None else None,
            })
        mdf = pd.DataFrame(rows)
        df = mdf if df is None else df.merge(mdf, on="pair_id", how="inner")
    return df.dropna()


def metrics(y, pred):
    cm = confusion_matrix(y, pred, labels=[0, 1])
    return {
        "n": int(len(y)),
        "f1": float(f1_score(y, pred, zero_division=0)),
        "precision": float(precision_score(y, pred, zero_division=0)),
        "recall": float(recall_score(y, pred, zero_division=0)),
        "tn": int(cm[0][0]),
        "fp": int(cm[0][1]),
        "fn": int(cm[1][0]),
        "tp": int(cm[1][1]),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", default="data")
    parser.add_argument("--scores_dir", default="results/module_scores")
    parser.add_argument("--results_dir", default="results")
    parser.add_argument("--out_dir", default="results/error_analysis")
    args = parser.parse_args()

    data_dir = Path(args.data_dir)
    scores_dir = Path(args.scores_dir)
    results_dir = Path(args.results_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    candidates = json.loads((results_dir / "tribunal_candidates.json").read_text(encoding="utf-8"))
    selected = candidates["selected_modules"]
    all_modules = candidates["all_modules"]

    train_meta = load_split(data_dir / "splits/train.jsonl")
    test_meta = load_split(data_dir / "splits/test.jsonl")

    train_scores_min = load_scores(scores_dir, "train", selected)
    test_scores_min = load_scores(scores_dir, "test", selected)

    train = train_meta.merge(train_scores_min, on="pair_id", how="inner")
    test = test_meta.merge(test_scores_min, on="pair_id", how="inner")

    model = LogisticRegression(max_iter=1000, random_state=42)
    model.fit(train[selected].values, train["label"].values)

    test["pred"] = model.predict(test[selected].values)
    test["correct"] = test["pred"] == test["label"]
    test["category_key"] = test["corpus"].astype(str) + "/" + test["category"].astype(str)

    global_metrics = metrics(test["label"].values, test["pred"].values)

    category_rows = []
    for key, group in test.groupby("category_key"):
        m = metrics(group["label"].values, group["pred"].values)
        m["category_key"] = key
        category_rows.append(m)

    category_df = pd.DataFrame(category_rows).sort_values(["f1", "recall", "category_key"])

    errors = test[test["correct"] == False].copy()
    errors = errors.sort_values(["category_key", "label", "prefix"])

    summary = {
        "selected_modules": selected,
        "all_modules": all_modules,
        "global_metrics": global_metrics,
        "error_count": int(len(errors)),
        "note": "Metrics reproduce 04_validate_test.py for the selected minimal tribunal and break results down by category.",
    }

    (out_dir / "error_analysis_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    category_df.to_csv(out_dir / "category_metrics.csv", index=False)
    errors.to_csv(out_dir / "errors.csv", index=False)

    print("=" * 72)
    print("R0 error/category analysis complete")
    print("=" * 72)
    print(f"Selected modules: {selected}")
    print(f"Global metrics:   {global_metrics}")
    print(f"Errors:           {len(errors)}")
    print(f"Output dir:       {out_dir}")
    print()
    print("Worst categories:")
    print(category_df.head(12).to_string(index=False))


if __name__ == "__main__":
    main()
