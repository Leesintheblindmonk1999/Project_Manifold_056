"""Module registry for R0 isolated execution.

This file provides baseline modules for infrastructure testing and a place to connect
real SAS modules later.

Baseline modules are NOT official SAS metrics. They are simple heuristics that let
you verify the R0 pipeline without touching the production API.
"""

from __future__ import annotations

import math
import re
from typing import Callable, Dict, Tuple, Any


ModuleResult = Tuple[float, dict]
ModuleFn = Callable[[str, str], ModuleResult]


TOKEN_RE = re.compile(r"\b[\wáéíóúñüÁÉÍÓÚÑÜ-]+\b", re.UNICODE)
NUMBER_RE = re.compile(r"(?<!\w)[+-]?\d+(?:[.,]\d+)?(?:%|\b)")
CAP_ENTITY_RE = re.compile(r"\b[A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]+(?:\s+[A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]+)*\b")
NEGATIONS = {
    "no", "not", "never", "none", "nobody", "nothing", "neither", "nor",
    "sin", "nunca", "jamás", "nadie", "ninguno", "ninguna", "tampoco",
}


def tokens(text: str):
    return [t.lower() for t in TOKEN_RE.findall(text or "")]


def jaccard_distance(a, b) -> float:
    sa = set(a)
    sb = set(b)
    if not sa and not sb:
        return 0.0
    return 1.0 - (len(sa & sb) / max(len(sa | sb), 1))


def clipped(x: float) -> float:
    return max(0.0, min(1.0, float(x)))


def lexical_drift(source: str, response: str) -> ModuleResult:
    st = tokens(source)
    rt = tokens(response)
    score = jaccard_distance(st, rt)
    return clipped(score), {"source_tokens": len(st), "response_tokens": len(rt)}


def numeric_invariant_loss(source: str, response: str) -> ModuleResult:
    sn = [n.replace(",", ".") for n in NUMBER_RE.findall(source or "")]
    rn = [n.replace(",", ".") for n in NUMBER_RE.findall(response or "")]
    score = jaccard_distance(sn, rn)
    return clipped(score), {"source_numbers": sn, "response_numbers": rn}


def entity_drift(source: str, response: str) -> ModuleResult:
    se = CAP_ENTITY_RE.findall(source or "")
    re_ = CAP_ENTITY_RE.findall(response or "")
    score = jaccard_distance(se, re_)
    return clipped(score), {"source_entities": se[:25], "response_entities": re_[:25]}


def negation_shift(source: str, response: str) -> ModuleResult:
    st = set(tokens(source))
    rt = set(tokens(response))
    sneg = sorted(st & NEGATIONS)
    rneg = sorted(rt & NEGATIONS)
    score = 0.0 if bool(sneg) == bool(rneg) else 1.0
    return score, {"source_negations": sneg, "response_negations": rneg}


def length_delta(source: str, response: str) -> ModuleResult:
    ls = len(source or "")
    lr = len(response or "")
    denom = max(ls, lr, 1)
    score = abs(ls - lr) / denom
    return clipped(score), {"source_chars": ls, "response_chars": lr}


def density_delta(source: str, response: str) -> ModuleResult:
    st = tokens(source)
    rt = tokens(response)

    def density(ts):
        if not ts:
            return 0.0
        return len(set(ts)) / len(ts)

    ds = density(st)
    dr = density(rt)
    return clipped(abs(ds - dr)), {"source_density": ds, "response_density": dr}


def get_baseline_registry() -> Dict[str, ModuleFn]:
    return {
        "lexical_drift": lexical_drift,
        "numeric_invariant_loss": numeric_invariant_loss,
        "entity_drift": entity_drift,
        "negation_shift": negation_shift,
        "length_delta": length_delta,
        "density_delta": density_delta,
    }


def get_sas_registry() -> Dict[str, ModuleFn]:
    """Connect real SAS modules here.

    Example shape expected by 01_run_isolated.py:

        def source_target_guard_wrapper(source: str, response: str):
            result = real_sas_function(source, response)
            return result.score, result.evidence

        return {"source_target_guard": source_target_guard_wrapper}

    Keep wrappers side-effect free. They should not call external APIs during R0 unless
    explicitly documented.
    """
    return {}


def get_registry(name: str) -> Dict[str, ModuleFn]:
    if name == "baseline":
        return get_baseline_registry()
    if name == "sas":
        return get_sas_registry()
    raise ValueError(f"Unknown registry: {name}")
