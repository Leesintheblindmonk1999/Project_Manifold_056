#!/usr/bin/env python
"""R0 Step 2: Correlation matrix + nonlinear dependence.

Patched to avoid numpy.bool_ JSON serialization issues.
"""

from __future__ import annotations

import argparse
import itertools
import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import mutual_info_score
from sklearn.preprocessing import KBinsDiscretizer


def to_jsonable(value):
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        if np.isnan(value):
            return None
        return float(value)
    if isinstance(value, dict):
        return {k: to_jsonable(v) for k, v in value.items()}
    if isinstance(value, list):
        return [to_jsonable(v) for v in value]
    return value


def distance_covariance_sq(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    a = np.abs(x[:, None] - x[None, :])
    b = np.abs(y[:, None] - y[None, :])
    a = a - a.mean(axis=1, keepdims=True) - a.mean(axis=0, keepdims=True) + a.mean()
    b = b - b.mean(axis=1, keepdims=True) - b.mean(axis=0, keepdims=True) + b.mean()
    return float((a * b).mean())


def distance_correlation(x, y):
    dcov_xy = distance_covariance_sq(x, y)
    dcov_xx = distance_covariance_sq(x, x)
    dcov_yy = distance_covariance_sq(y, y)
    denom = np.sqrt(dcov_xx * dcov_yy)
    if denom < 1e-12:
        return 0.0
    return float(np.sqrt(max(dcov_xy / denom, 0.0)))


def mutual_information_continuous(x, y, n_bins=10):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    bins = max(2, min(n_bins, len(x) // 5 if len(x) >= 20 else 2))
    discretizer = KBinsDiscretizer(n_bins=bins, encode="ordinal", strategy="uniform")
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message=".*Feature 0 is constant.*")
        x_disc = discretizer.fit_transform(x.reshape(-1, 1)).ravel().astype(int)
        y_disc = discretizer.fit_transform(y.reshape(-1, 1)).ravel().astype(int)
    return float(mutual_info_score(x_disc, y_disc))


def pearson_ci(r, n, alpha=0.05):
    if n <= 3 or abs(r) >= 0.999999:
        return float(r), float(r)
    r = float(np.clip(r, -0.999999, 0.999999))
    z = np.arctanh(r)
    se = 1 / np.sqrt(n - 3)
    zcrit = stats.norm.ppf(1 - alpha / 2)
    return float(np.tanh(z - zcrit * se)), float(np.tanh(z + zcrit * se))


def load_module_scores(scores_dir: Path, split_prefix: str = "train") -> pd.DataFrame:
    dfs = []
    for f in sorted(scores_dir.glob(f"{split_prefix}_*.jsonl")):
        module_name = f.stem.replace(f"{split_prefix}_", "")
        records = []
        with f.open(encoding="utf-8") as fh:
            for line in fh:
                row = json.loads(line)
                if row.get("score") is not None:
                    records.append({
                        "pair_id": row["pair_id"],
                        "label": int(row["label"]),
                        module_name: float(row["score"]),
                    })
        if records:
            dfs.append(pd.DataFrame(records).set_index("pair_id"))

    if not dfs:
        raise RuntimeError(f"No score files found in {scores_dir}")

    df = dfs[0]
    for other in dfs[1:]:
        df = df.join(other.drop(columns=["label"], errors="ignore"), how="inner")

    return df.dropna()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scores_dir", default="results/module_scores")
    parser.add_argument("--split_prefix", default="train")
    parser.add_argument("--out_dir", default="results")
    args = parser.parse_args()

    scores_dir = Path(args.scores_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    df = load_module_scores(scores_dir, args.split_prefix)
    modules = [c for c in df.columns if c != "label"]

    if len(modules) < 2:
        raise RuntimeError("Need at least two modules to compute correlation matrix.")

    pearson = df[modules].corr(method="pearson")
    spearman = df[modules].corr(method="spearman")
    mi = pd.DataFrame(index=modules, columns=modules, dtype=float)
    dc = pd.DataFrame(index=modules, columns=modules, dtype=float)

    pair_summary = []
    for a, b in itertools.product(modules, modules):
        x = df[a].values
        y = df[b].values
        if a == b:
            mi.loc[a, b] = 1.0
            dc.loc[a, b] = 1.0
        else:
            mi.loc[a, b] = mutual_information_continuous(x, y)
            dc.loc[a, b] = distance_correlation(x, y)

    for a, b in itertools.combinations(modules, 2):
        r = float(pearson.loc[a, b])
        s = float(spearman.loc[a, b])
        dcor = float(dc.loc[a, b])
        mi_val = float(mi.loc[a, b])
        ci_lo, ci_hi = pearson_ci(r, len(df))
        nonlinear_flag = bool((abs(float(r)) < 0.30) and (float(dcor) > 0.40))

        pair_summary.append({
            "module_a": a,
            "module_b": b,
            "pearson": r,
            "pearson_ci95": [ci_lo, ci_hi],
            "spearman": s,
            "mutual_information": mi_val,
            "distance_correlation": dcor,
            "potential_nonlinear_dependence": nonlinear_flag,
            "high_linear_correlation": bool(abs(r) > 0.85),
            "moderate_or_low_correlation": bool(abs(r) < 0.60),
        })

    pearson.to_csv(out_dir / "pearson_matrix.csv")
    spearman.to_csv(out_dir / "spearman_matrix.csv")
    mi.to_csv(out_dir / "mi_matrix.csv")
    dc.to_csv(out_dir / "distance_corr_matrix.csv")

    low_pairs = [p for p in pair_summary if p["moderate_or_low_correlation"]]
    high_pairs = [p for p in pair_summary if p["high_linear_correlation"]]
    all_high = len(high_pairs) == len(pair_summary) if pair_summary else False

    summary = {
        "n_pairs": int(len(df)),
        "modules": modules,
        "n_modules": len(modules),
        "pair_summary": pair_summary,
        "r0_exit_indicators": {
            "at_least_3_low_corr_pairs": bool(len(low_pairs) >= 3),
            "all_pairs_high_corr_gt_085": bool(all_high),
            "low_corr_pair_count": int(len(low_pairs)),
            "high_corr_pair_count": int(len(high_pairs)),
        },
    }
    (out_dir / "correlation_summary.json").write_text(
        json.dumps(to_jsonable(summary), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    print("=" * 72)
    print("Correlation analysis complete")
    print("=" * 72)
    print(f"Rows used: {len(df)}")
    print(f"Modules: {modules}")
    print(f"Low-correlation pairs (<0.60): {len(low_pairs)}")
    print(f"High-correlation pairs (>0.85): {len(high_pairs)}")
    print(f"Output dir: {out_dir}")


if __name__ == "__main__":
    main()
