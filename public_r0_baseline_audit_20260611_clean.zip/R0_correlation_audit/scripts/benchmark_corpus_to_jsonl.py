#!/usr/bin/env python
"""Convert local mixed A/B benchmark corpus into SAS R0 JSONL.

Input layout supported recursively:

  benchmark_corpus/halogen/biographies/0000_A_clean.txt
  benchmark_corpus/halogen/biographies/0000_B_hallucination.txt
  benchmark_corpus/halueval_dialogue/0000_A_clean.txt
  benchmark_corpus/halueval_dialogue/0000_B_hallucination.txt

Default output can create two records per complete A/B pair:
  label=1: source=A_clean, response=B_hallucination
  label=0: source=A_clean, response=A_clean

This default is a clean-self infrastructure baseline. It is useful for smoke testing
but can inflate F1 and must not be treated as production-grade validation.

For stronger negatives, pass --clean_responses_dir and --clean_strategy external.
The script will look for independent clean response files using the same relative
directory and prefix.

Supported external clean filenames for each prefix:
  <prefix>_C_clean.txt
  <prefix>_B_clean.txt
  <prefix>_clean_response.txt
  <prefix>_response_clean.txt
  <prefix>.txt
"""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


EXTERNAL_CLEAN_SUFFIXES = [
    "_C_clean.txt",
    "_B_clean.txt",
    "_clean_response.txt",
    "_response_clean.txt",
    ".txt",
]


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace").strip()


def discover_complete_pairs(corpus_dir: Path):
    a_files = sorted(corpus_dir.rglob("*_A_clean.txt"))
    for a_path in a_files:
        b_path = a_path.with_name(a_path.name.replace("_A_clean.txt", "_B_hallucination.txt"))
        if not b_path.exists():
            continue

        rel_parent = a_path.parent.relative_to(corpus_dir)
        parts = rel_parent.parts
        corpus = parts[0] if parts else "root"
        category = "/".join(parts[1:]) if len(parts) > 1 else "direct"
        prefix = a_path.name.replace("_A_clean.txt", "")

        yield {
            "prefix": prefix,
            "a_path": a_path,
            "b_path": b_path,
            "corpus": corpus,
            "category": category,
            "relative_dir": rel_parent.as_posix(),
        }


def find_external_clean_response(pair: dict, clean_responses_dir: Path) -> Path | None:
    """Find an independent clean response for a pair.

    Lookup order:
      1. clean_responses_dir/<relative_dir>/<prefix><suffix>
      2. clean_responses_dir/<prefix><suffix>
      3. recursive fallback: **/<prefix><suffix>

    The recursive fallback is convenient but can be ambiguous. If multiple matches
    exist, the first sorted path is used and the manifest should be inspected.
    """
    prefix = pair["prefix"]
    rel_dir = Path(pair["relative_dir"])

    candidates = []
    for suffix in EXTERNAL_CLEAN_SUFFIXES:
        candidates.append(clean_responses_dir / rel_dir / f"{prefix}{suffix}")
        candidates.append(clean_responses_dir / f"{prefix}{suffix}")

    for candidate in candidates:
        if candidate.exists() and candidate.is_file():
            return candidate

    recursive = []
    for suffix in EXTERNAL_CLEAN_SUFFIXES:
        recursive.extend(clean_responses_dir.rglob(f"{prefix}{suffix}"))

    recursive = sorted(p for p in recursive if p.is_file())
    return recursive[0] if recursive else None


def make_record(
    pair: dict,
    label: int,
    clean_source_text: str,
    response_text: str,
    clean_strategy: str,
    corpus_dir: Path,
    clean_response_path: Path | None = None,
):
    suffix = "hallucination" if label == 1 else "clean"
    pair_group_id = f"{pair['corpus']}::{pair['category']}::{pair['prefix']}"
    rec_id = f"{pair_group_id}::{suffix}"

    clean_file_rel = str(pair["a_path"].relative_to(corpus_dir)).replace("\\", "/")
    hallucination_file_rel = str(pair["b_path"].relative_to(corpus_dir)).replace("\\", "/")
    clean_response_file = None
    if clean_response_path is not None:
        clean_response_file = clean_response_path.as_posix()

    return {
        "id": rec_id,
        "pair_id": rec_id,
        "pair_group_id": pair_group_id,
        "label": int(label),
        "label_name": "hallucination" if label == 1 else "clean",
        "source": clean_source_text,
        "response": response_text,
        "corpus": pair["corpus"],
        "category": pair["category"],
        "relative_dir": pair["relative_dir"],
        "prefix": pair["prefix"],
        "clean_file": clean_file_rel,
        "hallucination_file": hallucination_file_rel,
        "clean_response_file": clean_response_file,
        "clean_pair_strategy": clean_strategy,
        "source_sha256": sha256_text(clean_source_text),
        "response_sha256": sha256_text(response_text),
        "source_chars": len(clean_source_text),
        "response_chars": len(response_text),
        "source_equals_response": bool(clean_source_text == response_text),
    }


def write_jsonl(path: Path, records):
    path.parent.mkdir(parents=True, exist_ok=True)
    n = 0
    with path.open("w", encoding="utf-8") as f:
        for rec in records:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            n += 1
    return n


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--corpus_dir", required=True, help="Path to benchmark_corpus")
    parser.add_argument("--out", default="R0_correlation_audit/data/full_benchmark.jsonl")
    parser.add_argument("--manifest_out", default=None)
    parser.add_argument(
        "--clean_strategy",
        choices=["self", "external", "none"],
        default="self",
        help=(
            "'self' creates clean A->A records; "
            "'external' uses --clean_responses_dir for independent clean responses; "
            "'none' outputs hallucination records only."
        ),
    )
    parser.add_argument(
        "--clean_responses_dir",
        default=None,
        help=(
            "Optional directory with independent clean responses. Required for "
            "--clean_strategy external. Supported names include <prefix>_C_clean.txt, "
            "<prefix>_B_clean.txt, <prefix>_clean_response.txt."
        ),
    )
    parser.add_argument(
        "--allow_missing_external_clean",
        action="store_true",
        help="When using --clean_strategy external, skip pairs missing clean responses instead of failing.",
    )
    parser.add_argument("--limit_pairs", type=int, default=None, help="Optional limit for smoke tests")
    args = parser.parse_args()

    corpus_dir = Path(args.corpus_dir).resolve()
    if not corpus_dir.exists():
        raise SystemExit(f"Corpus dir not found: {corpus_dir}")

    clean_responses_dir = Path(args.clean_responses_dir).resolve() if args.clean_responses_dir else None
    if args.clean_strategy == "external" and clean_responses_dir is None:
        raise SystemExit("--clean_strategy external requires --clean_responses_dir")
    if clean_responses_dir is not None and not clean_responses_dir.exists():
        raise SystemExit(f"Clean responses dir not found: {clean_responses_dir}")

    out_path = Path(args.out)
    manifest_path = Path(args.manifest_out) if args.manifest_out else out_path.with_suffix(".manifest.json")

    pairs = list(discover_complete_pairs(corpus_dir))
    if args.limit_pairs is not None:
        pairs = pairs[: args.limit_pairs]

    records = []
    by_corpus = Counter()
    by_category = Counter()
    missing_external_clean = []
    external_clean_used = 0
    clean_self_used = 0

    for pair in pairs:
        clean_source_text = read_text(pair["a_path"])
        halluc_text = read_text(pair["b_path"])

        by_corpus[pair["corpus"]] += 1
        by_category[f'{pair["corpus"]}/{pair["category"]}'] += 1

        records.append(
            make_record(
                pair=pair,
                label=1,
                clean_source_text=clean_source_text,
                response_text=halluc_text,
                clean_strategy=args.clean_strategy,
                corpus_dir=corpus_dir,
            )
        )

        if args.clean_strategy == "none":
            continue

        if args.clean_strategy == "self":
            clean_self_used += 1
            records.append(
                make_record(
                    pair=pair,
                    label=0,
                    clean_source_text=clean_source_text,
                    response_text=clean_source_text,
                    clean_strategy="self",
                    corpus_dir=corpus_dir,
                )
            )
            continue

        clean_response_path = find_external_clean_response(pair, clean_responses_dir)
        if clean_response_path is None:
            missing_external_clean.append(
                {
                    "pair_group_id": f"{pair['corpus']}::{pair['category']}::{pair['prefix']}",
                    "relative_dir": pair["relative_dir"],
                    "prefix": pair["prefix"],
                }
            )
            if args.allow_missing_external_clean:
                continue
            raise SystemExit(
                "Missing external clean response for "
                f"{pair['relative_dir']}/{pair['prefix']}. "
                "Use --allow_missing_external_clean to skip missing negatives."
            )

        external_clean_text = read_text(clean_response_path)
        external_clean_used += 1
        records.append(
            make_record(
                pair=pair,
                label=0,
                clean_source_text=clean_source_text,
                response_text=external_clean_text,
                clean_strategy="external",
                corpus_dir=corpus_dir,
                clean_response_path=clean_response_path,
            )
        )

    n = write_jsonl(out_path, records)

    labels = Counter(r["label_name"] for r in records)
    source_equals_response_by_label = Counter(
        f'{r["label_name"]}:{r["source_equals_response"]}' for r in records
    )

    manifest = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "corpus_dir": str(corpus_dir),
        "out": str(out_path),
        "clean_strategy": args.clean_strategy,
        "clean_responses_dir": str(clean_responses_dir) if clean_responses_dir else None,
        "complete_ab_pairs": len(pairs),
        "records_written": n,
        "labels": dict(labels),
        "by_corpus_complete_pairs": dict(sorted(by_corpus.items())),
        "by_category_complete_pairs": dict(sorted(by_category.items())),
        "external_clean_used": int(external_clean_used),
        "clean_self_used": int(clean_self_used),
        "missing_external_clean_count": int(len(missing_external_clean)),
        "missing_external_clean_examples": missing_external_clean[:25],
        "source_equals_response_by_label": dict(source_equals_response_by_label),
        "note": (
            "label=1 uses A_clean as source and B_hallucination as response. "
            "label=0 uses either A_clean as both source and response when clean_strategy=self, "
            "or an independent clean response when clean_strategy=external."
        ),
        "clean_self_warning": (
            "clean_strategy=self creates source==response for negative controls. "
            "This is valid for infrastructure smoke testing and baseline control, "
            "but it may inflate F1 and must not be presented as production-grade validation "
            "or final R1 module-selection evidence without stronger independent clean negatives."
        ),
        "external_clean_note": (
            "clean_strategy=external should be preferred for publishable R0/R1 evidence when "
            "independent clean responses are available."
        ),
        "path_privacy_note": (
            "clean_file and hallucination_file are stored as paths relative to corpus_dir. "
            "clean_response_file may be absolute if external clean responses are outside the corpus tree; "
            "remove or relativize it before public dataset release if needed."
        ),
    }
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")

    print("=" * 72)
    print("Benchmark conversion complete")
    print("=" * 72)
    print(f"Complete A/B pairs:        {len(pairs)}")
    print(f"Records written:           {n}")
    print(f"Labels:                    {dict(labels)}")
    print(f"Clean strategy:            {args.clean_strategy}")
    print(f"External clean used:       {external_clean_used}")
    print(f"Clean-self used:           {clean_self_used}")
    print(f"Missing external clean:    {len(missing_external_clean)}")
    print(f"JSONL:                     {out_path}")
    print(f"Manifest:                  {manifest_path}")


if __name__ == "__main__":
    main()
