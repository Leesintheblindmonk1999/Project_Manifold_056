#!/usr/bin/env python
"""R0 Step 1: Run modules in isolation.

Outputs one JSONL per module:
  results/module_scores/train_<module>.jsonl
  results/module_scores/test_<module>.jsonl

Each row includes execution_time_sec for runtime traceability.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from module_registry import get_registry  # noqa: E402


def read_jsonl(path: Path):
    with path.open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def split_prefix(split_path: Path) -> str:
    stem = split_path.stem.lower()
    if "train" in stem:
        return "train"
    if "test" in stem:
        return "test"
    return stem


def run_module_safe(module_fn, source: str, response: str) -> dict:
    started = time.perf_counter()
    try:
        result = module_fn(source, response)
        elapsed = time.perf_counter() - started
        if isinstance(result, dict):
            score = result.get("score")
            evidence = result.get("evidence", {})
        else:
            score, evidence = result
        return {
            "score": float(score),
            "evidence": evidence or {},
            "error": None,
            "execution_time_sec": float(elapsed),
        }
    except Exception as exc:
        elapsed = time.perf_counter() - started
        return {
            "score": None,
            "evidence": {},
            "error": repr(exc),
            "execution_time_sec": float(elapsed),
        }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--split", default="data/splits/train.jsonl")
    parser.add_argument("--out_dir", default="results/module_scores")
    parser.add_argument("--registry", choices=["baseline", "sas"], default="baseline")
    parser.add_argument("--modules", nargs="*", default=None)
    parser.add_argument("--limit", type=int, default=None)
    args = parser.parse_args()

    split_path = Path(args.split)
    if not split_path.exists():
        raise SystemExit(f"Split not found: {split_path}")

    registry = get_registry(args.registry)
    if not registry:
        raise SystemExit(
            f"Registry '{args.registry}' is empty. "
            "Edit scripts/module_registry.py to connect real SAS modules."
        )

    modules = args.modules or sorted(registry.keys())
    missing = [m for m in modules if m not in registry]
    if missing:
        raise SystemExit(f"Unknown modules for registry '{args.registry}': {missing}")

    pairs = read_jsonl(split_path)
    if args.limit:
        pairs = pairs[: args.limit]

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    prefix = split_prefix(split_path)
    run_meta = {
        "started_at": datetime.now(timezone.utc).isoformat(),
        "split": str(split_path),
        "registry": args.registry,
        "modules": modules,
        "n_pairs": len(pairs),
        "module_runtime_sec": {},
    }

    for module_name in modules:
        module_fn = registry[module_name]
        out_path = out_dir / f"{prefix}_{module_name}.jsonl"
        started_module = time.perf_counter()
        ok = 0
        err = 0
        row_times = []

        with out_path.open("w", encoding="utf-8") as f:
            for rec in pairs:
                res = run_module_safe(module_fn, rec.get("source", ""), rec.get("response", ""))
                row_times.append(res["execution_time_sec"])
                if res["error"] is None:
                    ok += 1
                else:
                    err += 1

                row = {
                    "pair_id": rec.get("pair_id") or rec.get("id"),
                    "id": rec.get("id"),
                    "label": int(rec.get("label")),
                    "corpus": rec.get("corpus"),
                    "category": rec.get("category"),
                    "module": module_name,
                    "registry": args.registry,
                    "score": res["score"],
                    "evidence": res["evidence"],
                    "error": res["error"],
                    "execution_time_sec": res["execution_time_sec"],
                }
                f.write(json.dumps(row, ensure_ascii=False) + "\n")

        elapsed_module = time.perf_counter() - started_module
        avg_row_time = sum(row_times) / len(row_times) if row_times else 0.0
        run_meta["module_runtime_sec"][module_name] = {
            "total": float(elapsed_module),
            "mean_per_record": float(avg_row_time),
            "min_per_record": float(min(row_times) if row_times else 0.0),
            "max_per_record": float(max(row_times) if row_times else 0.0),
            "ok": int(ok),
            "err": int(err),
        }
        print(
            f"{module_name}: wrote {out_path} | "
            f"ok={ok} err={err} total={elapsed_module:.2f}s "
            f"mean={avg_row_time:.6f}s"
        )

    run_meta["finished_at"] = datetime.now(timezone.utc).isoformat()
    meta_path = out_dir / f"{prefix}_run_meta.json"
    meta_path.write_text(json.dumps(run_meta, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Run meta: {meta_path}")


if __name__ == "__main__":
    main()
