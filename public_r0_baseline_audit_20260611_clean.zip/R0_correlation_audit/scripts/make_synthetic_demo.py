#!/usr/bin/env python
"""Create a tiny synthetic benchmark for testing the R0 code without real corpus."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="data/demo_benchmark.jsonl")
    parser.add_argument("--n", type=int, default=40)
    args = parser.parse_args()

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)

    records = []
    for i in range(args.n // 2):
        source = f"Paris has the Eiffel Tower. It was completed in 1889. Case {i}."
        response_bad = f"Berlin has the Eiffel Tower. It was completed in 1950. Case {i}."
        response_good = source

        records.append({
            "id": f"demo_{i:04d}_hallucination",
            "pair_id": f"demo_{i:04d}_hallucination",
            "label": 1,
            "source": source,
            "response": response_bad,
            "corpus": "demo",
            "category": "entity_year_shift",
        })
        records.append({
            "id": f"demo_{i:04d}_clean",
            "pair_id": f"demo_{i:04d}_clean",
            "label": 0,
            "source": source,
            "response": response_good,
            "corpus": "demo",
            "category": "clean_self",
        })

    with out.open("w", encoding="utf-8") as f:
        for rec in records:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    print(f"Wrote {len(records)} demo records to {out}")


if __name__ == "__main__":
    main()
