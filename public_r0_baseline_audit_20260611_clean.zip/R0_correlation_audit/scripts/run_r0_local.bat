@echo off
REM Run from R0_correlation_audit/
python scripts\make_synthetic_demo.py --out data\demo_benchmark.jsonl
python scripts\00_create_split.py --benchmark data\demo_benchmark.jsonl --seed 42 --force
python scripts\01_run_isolated.py --split data\splits\train.jsonl --registry baseline
python scripts\01_run_isolated.py --split data\splits\test.jsonl --registry baseline
python scripts\02_correlation_matrix.py --scores_dir results\module_scores
python scripts\03_marginal_contribution.py
python scripts\04_validate_test.py --yes
