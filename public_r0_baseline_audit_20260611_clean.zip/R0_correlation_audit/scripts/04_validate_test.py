#!/usr/bin/env python
"""R0 Step 4: Validate selected tribunal on test split.

This should be run only after module selection is closed.
Supports optional StandardScaler normalization and exports confusion matrix.
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, f1_score, precision_score, recall_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


def load_scores_for_split(scores_dir: Path, split_prefix: str, modules: list) -> pd.DataFrame:
    dfs = []
    for module in modules:
        f = scores_dir / f"{split_prefix}_{module}.jsonl"
        if not f.exists():
            raise RuntimeError(f"Missing score file: {f}")
        records = []
        with f.open(encoding="utf-8") as fh:
            for line in fh:
                row = json.loads(line)
                if row.get("score") is not None:
                    records.append(
                        {
                            "pair_id": row["pair_id"],
                            "label": int(row["label"]),
                            module: float(row["score"]),
                        }
                    )
        dfs.append(pd.DataFrame(records).set_index("pair_id"))

    df = dfs[0]
    for other in dfs[1:]:
        df = df.join(other.drop(columns=["label"], errors="ignore"), how="inner")
    return df.dropna()


def make_model(normalize: bool):
    base = LogisticRegression(max_iter=1000, random_state=42)
    if not normalize:
        return base
    return Pipeline(
        steps=[
            ("scaler", StandardScaler()),
            ("model", base),
        ]
    )


def evaluate(df_train, df_test, modules, normalize: bool):
    model = make_model(normalize)
    x_train = df_train[modules].values
    y_train = df_train["label"].values
    x_test = df_test[modules].values
    y_test = df_test["label"].values

    model.fit(x_train, y_train)
    pred = model.predict(x_test)
    cm = confusion_matrix(y_test, pred, labels=[0, 1])

    return {
        "modules": modules,
        "n_modules": len(modules),
        "normalize": bool(normalize),
        "f1": float(f1_score(y_test, pred, zero_division=0)),
        "precision": float(precision_score(y_test, pred, zero_division=0)),
        "recall": float(recall_score(y_test, pred, zero_division=0)),
        "confusion_matrix": {
            "labels": [0, 1],
            "matrix": cm.tolist(),
            "tn": int(cm[0][0]),
            "fp": int(cm[0][1]),
            "fn": int(cm[1][0]),
            "tp": int(cm[1][1]),
        },
        "classification_report": classification_report(y_test, pred, output_dict=True, zero_division=0),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scores_dir", default="results/module_scores")
    parser.add_argument("--out_dir", default="results")
    parser.add_argument("--normalize", action="store_true", help="Apply StandardScaler before LogisticRegression")
    parser.add_argument(
        "--yes",
        action="store_true",
        help="Confirm that module selection is frozen and test can be read.",
    )
    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    scores_dir = Path(args.scores_dir)
    candidates_file = out_dir / "tribunal_candidates.json"
    if not candidates_file.exists():
        raise RuntimeError("Missing tribunal_candidates.json. Run 03_marginal_contribution.py first.")

    candidates = json.loads(candidates_file.read_text(encoding="utf-8"))
    selected = candidates["selected_modules"]
    all_modules = candidates["all_modules"]

    if not args.yes:
        print("WARNING: this reads the test split. Run only after selection is frozen.")
        confirm = input("Type SI to continue: ")
        if confirm.strip().upper() != "SI":
            print("Cancelled.")
            return

    df_train_all = load_scores_for_split(scores_dir, "train", all_modules)
    df_test_all = load_scores_for_split(scores_dir, "test", all_modules)

    ev_min = evaluate(df_train_all, df_test_all, selected, normalize=args.normalize)
    ev_full = evaluate(df_train_all, df_test_all, all_modules, normalize=args.normalize)

    gap = ev_full["f1"] - ev_min["f1"]

    result = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "selected_modules": selected,
        "all_modules": all_modules,
        "normalize": bool(args.normalize),
        "minimal_tribunal": ev_min,
        "full_pipeline": ev_full,
        "f1_gap_full_minus_minimal": float(gap),
        "significant_cost_gt_0_05": bool(gap > 0.05),
    }

    out_path = out_dir / "test_validation.json"
    out_path.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")

    cm_path = out_dir / "test_confusion_matrix.json"
    cm_path.write_text(
        json.dumps(
            {
                "created_at": result["created_at"],
                "normalize": bool(args.normalize),
                "minimal_tribunal": ev_min["confusion_matrix"],
                "full_pipeline": ev_full["confusion_matrix"],
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    findings_dir = Path(__file__).resolve().parent.parent / "findings"
    findings_dir.mkdir(parents=True, exist_ok=True)
    finding = findings_dir / "FINDING_R0_RESULT.md"
    finding.write_text(
        "# R0 Test Validation Result\n\n"
        f"Generated: {result['created_at']}\n\n"
        f"Selected modules: `{selected}`\n\n"
        f"Normalize: `{bool(args.normalize)}`\n\n"
        f"Minimal tribunal F1: `{ev_min['f1']:.4f}`\n\n"
        f"Full pipeline F1: `{ev_full['f1']:.4f}`\n\n"
        f"F1 gap: `{gap:.4f}`\n\n"
        "## Minimal Tribunal Confusion Matrix\n\n"
        f"`{ev_min['confusion_matrix']}`\n\n"
        "## Full Pipeline Confusion Matrix\n\n"
        f"`{ev_full['confusion_matrix']}`\n\n",
        encoding="utf-8",
    )

    print("=" * 72)
    print("R0 test validation complete")
    print("=" * 72)
    print(f"Normalize:            {bool(args.normalize)}")
    print(f"Minimal tribunal F1: {ev_min['f1']:.4f}")
    print(f"Full pipeline F1:    {ev_full['f1']:.4f}")
    print(f"Gap:                 {gap:.4f}")
    print(f"Output:              {out_path}")
    print(f"Confusion matrix:    {cm_path}")


if __name__ == "__main__":
    main()
