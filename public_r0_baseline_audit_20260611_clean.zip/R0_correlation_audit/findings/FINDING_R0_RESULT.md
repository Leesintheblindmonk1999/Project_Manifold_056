# R0 Test Validation Result

Generated: 2026-06-11T17:22:44.978535+00:00

Selected modules: `['entity_drift']`

Normalize: `False`

Minimal tribunal F1: `0.9993`

Full pipeline F1: `1.0000`

F1 gap: `0.0007`

## Minimal Tribunal Confusion Matrix

`{'labels': [0, 1], 'matrix': [[1500, 0], [2, 1498]], 'tn': 1500, 'fp': 0, 'fn': 2, 'tp': 1498}`

## Full Pipeline Confusion Matrix

`{'labels': [0, 1], 'matrix': [[1500, 0], [0, 1500]], 'tn': 1500, 'fp': 0, 'fn': 0, 'tp': 1500}`

