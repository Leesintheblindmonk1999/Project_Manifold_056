# Changelog

All notable changes to the SAS R0 correlation audit code pack are documented here.

---

## [v0.3.0-multi-audit-hardened] — DeepSeek audit integration

**Status:** Ready for staged R0 execution  
**Benchmark included:** No  
**External audits integrated:** Claude + ChatGPT + DeepSeek

### Added

- `docs/DEEPSEEK_AUDIT_VERDICT.md`
- `--clean_strategy external`
- `--clean_responses_dir`
- `--allow_missing_external_clean`
- per-record `execution_time_sec` in module score JSONL files
- per-module runtime metadata in run metadata
- CV fold values and standard deviations in marginal contribution outputs
- optional `--normalize` validation mode using `StandardScaler`
- test confusion matrix export to `results/test_confusion_matrix.json`
- stronger `GROUND_TRUTH_DEFINITION.md` with external clean negative mode

### Changed

- Clean-self remains available but is explicitly baseline-only.
- Publishable R0/R1 interpretation now requires independent clean negatives or additional validation.
- Validation output includes confusion matrices for minimal tribunal and full pipeline.
- The R0 protocol now distinguishes infrastructure execution from publishable evidence.

### Integrated DeepSeek recommendations

- MEJORA-1: independent clean negatives via `--clean_responses_dir`.
- MEJORA-2: structured runtime traceability.
- MEJORA-3: CV fold scores and standard deviation.
- Optional normalization for LogisticRegression.
- Confusion matrix export.

---

## [v0.2.0-audit-integrated] — External audit integration

**Status:** Ready for local staged testing  
**Benchmark included:** No  
**External audit verdict:** apt for local testing; no security issues; clean-self limitation must be documented.

### Added

- `docs/CLAUDE_AUDIT_VERDICT.md`
- `docs/R0_TEST_PROTOCOL.md`
- `docs/R0_DECISION_CRITERIA.md`
- `docs/GROUND_TRUTH_DEFINITION.md`
- `docs/ISSUES.md`
- audit-integrated clean-self methodological warning
- path privacy note in benchmark conversion manifest
- explicit classification of clean-self as infrastructure baseline only

### Fixed

#### BUG-1 — UndefinedMetricWarning noise

Updated:

```text
R0_correlation_audit/scripts/03_marginal_contribution.py
R0_correlation_audit/scripts/04_validate_test.py
```

Fix:

```text
zero_division=0
```

was added to precision, recall, F1, and classification report scoring where relevant.

#### BUG-2 — Validator findings path

Updated:

```text
R0_correlation_audit/scripts/04_validate_test.py
```

Fix:

```python
findings_dir = Path(__file__).resolve().parent.parent / "findings"
```

This prevents writing findings into the wrong folder when the script is run from a different working directory.

#### BUG-3 — Absolute local paths in JSONL

Updated:

```text
R0_correlation_audit/scripts/benchmark_corpus_to_jsonl.py
```

Fix:

```text
clean_file and hallucination_file are now stored relative to corpus_dir.
```

This prevents accidental publication of local filesystem paths.

### Improved

- Suppressed expected sklearn constant-feature warning inside Mutual Information discretization.
- Added `clean_self_warning` to conversion manifest.
- Added publication restrictions for clean-self R0 results.

---

## [v0.1.0] — Initial code-only scaffold

**Status:** Audited  
**Scope:** R0 correlation audit infrastructure  
**Benchmark included:** No

### Added

- Recursive A/B benchmark converter
- Immutable train/test split
- Isolated module runner
- Baseline heuristic registry
- Correlation matrix generator
- Pearson confidence intervals
- Mutual Information matrix
- Distance Correlation matrix
- Marginal contribution analyzer
- Final held-out test validator
- κD AST equivalence scanner
- R1/R2/R3 research skeletons

---

## Planned [v0.3.0]

- Unit tests
- Windows path smoke test
- Duplicate/leakage detector
- Real SAS module wrappers
- Independent clean negative strategy
- 20-pair and 200-pair staged execution reports
- R0 results report template
